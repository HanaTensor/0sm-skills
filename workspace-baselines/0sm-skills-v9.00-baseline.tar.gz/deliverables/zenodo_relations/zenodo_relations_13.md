# Zenodo Related Works — Paper #13

**Paper #13** — *Unified Spin Dynamics: From Pseudovector Nature to Relativistic Constraints*

DOI: 10.5281/zenodo.17765079 (Submitted January 2025)

> 本リストは Zenodo の「Related works」欄に手作業で登録する relation のガイド。
> forward (本 record #13 に登録) と reverse (相手 record に登録) を対で示す。
> 全 relation は #13 現物 PDF (参考文献 [6], [7]) の検証に基づく。推定なし。

---

## A. Forward relations — register on Paper #13's own Zenodo record

### A-1. Continues

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Continues | Paper #10 | 10.5281/zenodo.17764997 | #13 は #10 の直系後継。#10 の閉形式エネルギー恒等式・Lorentz 収縮と異常磁気モーメントの関係・Zitterbewegung 速度 0.04047c を前段として直接継承し、その上に擬ベクトル性・時間反転・量子もつれの解釈を積み上げる。本文で [6] として繰り返し参照され、bib 掲載あり。 |

### A-2. References

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| References | Paper #1 | 10.5281/zenodo.16759284 | 二核 (kernel A/B = Te1/Te2) 構造・photon sphere・thermal energy gradient という基盤を提供。Appendix VI C は #1 ([7]) からの引用と明記。foundational citation。bib 掲載あり。 |

### A-3. Cites (subsuming relation)

Continues / References の対象が bibliography に掲載されている場合は Cites にも併記する慣例 (relation-types.md)。

| Relation | Target | DOI |
|---|---|---|
| Cites | Paper #10 | 10.5281/zenodo.17764997 |
| Cites | Paper #1 | 10.5281/zenodo.16759284 |

注: #13 の bib にはこの 2 本の Hanamura 論文のみが含まれる ([6]=#10, [7]=#1)。他の参考文献 ([1]-[5], [8]-[23]) は Bell, EPR, Stern-Gerlach, Thomas, Dirac, Hestenes, Fan/Gabrielse 等の標準外部文献であり、Hanamura シリーズ内 relation の対象外。

### A-4. Is part of

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is part of | Paper #1 | 10.5281/zenodo.16759284 | シリーズ membership default (後発論文の標準、relations-strategy.md)。起点論文 #1 を series の親とする。 |

注: reverse の「Has part」は #1 側に登録しない (方針1・過剰回避、relations-strategy.md)。

---

## B. Reverse relations — recommended updates to target papers' Zenodo records

下記は各 forward relation の reverse。相手 record の「Related works」に追加して双方向リンクを完成させる (Web UI 手作業)。

| Target paper | Add relation | Pointing to | DOI to enter |
|---|---|---|---|
| Paper #10 (10.5281/zenodo.17764997) | Is continued by | Paper #13 | 10.5281/zenodo.17765079 |
| Paper #1 (10.5281/zenodo.16759284) | Is referenced by | Paper #13 | 10.5281/zenodo.17765079 |

注:
- Cites の reverse (Is cited by) は登録しない慣例。
- Is part of の reverse (Has part) は #1 側に登録しない (方針1)。

---

## C. Cross-reference note for #14 relation list (correction)

ハンドオフ §3 で「#15相当 = 17765079」とされていた論文は、全論文履歴の確定により **実際は #13** (Unified Spin Dynamics, 17765079) であることが判明した。
- #14 (10.5281/zenodo.17765097) の relation list は「#15相当」References を **#13** に label 修正する必要がある。
- 真の #15 は別論文 "Spin-Induced Inertial Resistance in Electrons" (10.5281/zenodo.17765121, April 2025)。
- #14 (January 2025) と #13 (January 2025) は同月。#14 が #13 を References する向きは #14 PDF の bib で要再確認 (本セッションでは #14 PDF 未取得)。
