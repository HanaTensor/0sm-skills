# Reverse Relations — Pending Batch (一括処理用台帳)

> このファイルは、各論文の forward relation に対応する **reverse relation**(相手=既存論文の Zenodo record に追記する項目)を集約する台帳。
> 目的: 論文を仕上げるたびに #1 等の過去論文エディタを都度開く負担を避け、シリーズの区切りで **一度だけ各 record を開いて一括反映** する。
>
> 運用:
> - 各 `zenodo_relations_<N>.md` は、その論文自身の record に入れる **forward のみ**(最強1種、Cites 自動併記なし)を記載。
> - reverse は本台帳に追記して蓄積。
> - 一括処理時、下表を「Target record ごと」に開いて relation を追加し、済んだ行に [x] を付ける。
>
> relation 型対応: Continues ↔ Is continued by / References ↔ Is referenced by / Is supplement to ↔ Is supplemented by。
> (Cites の reverse=Is cited by、Is part of の reverse=Has part は登録しない慣例・方針1)

---

## 一括処理テーブル（Target record ごとにまとめて開く）

各行: Target record(開く対象) / 追加する relation / 指す先 / 入力 DOI。done 欄は反映後に [x]。

### Target: Paper #1 (10.5281/zenodo.16759284)

| done | Add relation | Pointing to | DOI to enter | Source (forward 元) |
|---|---|---|---|---|
| [ ] | Is referenced by | Paper #13 | 10.5281/zenodo.17765079 | #13 References #1 |
| [ ] | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 | #22 References #1 |

注: #1 の Has part(Is part of の reverse)は方針1により登録しない。

### Target: Paper #7 (10.5281/zenodo.17760132)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 | #22 References #7 |

### Target: Paper #10 (10.5281/zenodo.17764997)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is continued by | Paper #13 | 10.5281/zenodo.17765079 | #13 Continues #10 |
| [ ] | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 | #22 References #10 |

### Target: Paper #11 (10.5281/zenodo.17765017)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 | #22 References #11 |

### Target: Paper #14 (10.5281/zenodo.17765097)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is continued by | Paper #22 | 10.5281/zenodo.17765318 | #22 Continues #14 |

### Target: Paper #18 (10.5281/zenodo.17765200)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is continued by | Paper #24 | 10.5281/zenodo.17765349 | #24 Continues #18 |

### Target: Paper #28 (10.5281/zenodo.18636509)

| done | Add relation | Pointing to | DOI to enter | Source |
|---|---|---|---|---|
| [ ] | Is supplement to | Paper #22 | 10.5281/zenodo.17765318 | #22 Is supplemented by #28 |
| [ ] | Is supplemented by | Paper #27 | 10.5281/zenodo.17765439 | #27 Is supplement to #28 |

注: #28 は #14 に加え #22 も Is supplement to の対象。#28 を作業する際は forward として #22 行も含める(#14→#22→#28 補正フローの完結)。
注: #27 は #28 を Is supplement to で指す(#27 Section 7 inline correction が #28 の先行 acknowledgment)。その reverse として #28 record には Is supplemented by #27 を追加する。#14→#27(inline ack)→#28(formal) の訂正系譜。

---

## 処理済み履歴

(一括反映を実施したら、日付と対象 record をここに記録)

- (未実施)

---

## 元になった forward(参照用サマリ)

| Paper | forward relation(最強1種) | 備考 |
|---|---|---|
| #13 | Continues #10 / References #1 / Is part of #1 | 旧案の Cites #10,#1 併記は新方針で不要 |
| #22 | Continues #14 / References #10,#1,#7,#11 / Is part of #1 / Is supplemented by #28 | 旧案の Cites 5本併記は新方針で不要 |
| #24 | Continues #18 / Cites #14,#22,#23,#10,#19 / Is part of #1 | 新方針適用第1号: 相手1本=1型・重複なし。#1 は Is part of のみ(Cites 併記せず) |
| #27 | Is supplement to #28 / Cites #10,#11,#14 / Is part of #1 | 新方針適用。#14 は inline で部分撤回するが正式 correction は #28 が担うため bib 参照として Cites に留保。#28 を Is supplement to で結ぶ(訂正系譜の対) |

### 新方針(確定・#24 以降適用)

- 相手 1 本につき relation は最も適切な **1 型のみ**。同一相手を複数型に重複登場させない。
- 特に **#1 は Is part of か Cites のどちらか一方**(両方に出さない)。membership 表現としては Is part of を優先。
- その他の相手は、Continues/References/Is supplement to を立てない場合 **Cites にそのまま留保**してよい(Cites 一本で受ける)。
- reverse は Continues / References / Is supplement to の対のみ台帳に積む。Cites の reverse(Is cited by)・Is part of の reverse(Has part)は登録しない。

注: #13・#22 の既存 `zenodo_relations_<N>.md` には Cites 併記が残っている(作成済み成果物)。新方針(Cites 自動併記なし)は **次回作成分から適用**。既存2本は再編集せず、本台帳の forward サマリを正とする運用でよい。
