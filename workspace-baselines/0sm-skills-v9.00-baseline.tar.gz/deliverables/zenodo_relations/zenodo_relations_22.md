# Zenodo Related Works — Paper #22

**Paper #22** — *Gravitational Redshift of Internal Quantum Clocks: A Zitterbewegung-Based Model*

DOI: 10.5281/zenodo.17765318 (Submitted July 2025)

> 本リストは Zenodo「Related works」欄に手作業登録する relation のガイド。
> forward (本 record #22 に登録) と reverse (相手 record に登録) を対で示す。
> 全 forward relation は #22 現物 PDF の bib (参照 [3][4][7][8][15]) の検証に基づく。推定なし。
> #28 / #35 は #22 より後発のため #22 PDF には現れない。#28 は補正論文として
> reverse 方向 (#22 が受ける) のみ立て、#35 は description の Note 言及にとどめる。

---

## A. Forward relations — register on Paper #22's own Zenodo record

### A-1. Continues

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Continues | Paper #14 | 10.5281/zenodo.17765097 | #22 は #14 の直系後継。#14 の一般相対論的内部速度 ve,SR+GR=0.040374c (geodetic precession + curvature-modified 臨界半径) を直接の前段として受け取り、それを重力赤方偏移へ応用する。Methods・Eq.III.2 で繰り返し依拠 ([4])。bib 掲載あり。 |

### A-2. References

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| References | Paper #10 | 10.5281/zenodo.17764997 | 特殊相対論的内部速度 ve,SR=0.040472c の起源。本予言の SR 基準値を提供 ([3])。bib 掲載あり。 |
| References | Paper #1 | 10.5281/zenodo.16759284 | 0-Sphere 起点。二核 + photon shell による内部構造の基盤 ([7])。bib 掲載あり。 |
| References | Paper #7 | 10.5281/zenodo.17760132 | Dirac 正負解を 1 電子内の内部運動 (ZB) として再解釈する基盤。Compton 波長を ZB 振幅とする見方の出典 ([8])。bib 掲載あり。 |
| References | Paper #11 | 10.5281/zenodo.17765017 | proper time・geodesic path・放射的エネルギー輸送を通じた ZB の定式化。本論の proper-time governed clock 描像の前提 ([15])。bib 掲載あり。 |

### A-3. Cites (subsuming relation)

Continues / References の対象が bibliography 掲載のため、全件を Cites にも併記 (relation-types.md)。

| Relation | Target | DOI |
|---|---|---|
| Cites | Paper #14 | 10.5281/zenodo.17765097 |
| Cites | Paper #10 | 10.5281/zenodo.17764997 |
| Cites | Paper #1 | 10.5281/zenodo.16759284 |
| Cites | Paper #7 | 10.5281/zenodo.17760132 |
| Cites | Paper #11 | 10.5281/zenodo.17765017 |

注: #22 の bib に含まれる Hanamura 論文はこの 5 本 ([3]=#10, [4]=#14, [7]=#1, [8]=#7, [15]=#11)。他の参照 ([1][2][5][6][9]-[14][16]-[22]) は Dirac, Compton, Ashby (GPS), Schrödinger, Uhlenbeck-Goudsmit, Thomas, Schwinger, Fan/Gabrielse, Einstein, Birrell-Davies, Hestenes, Barut-Bracken, Everitt (GP-B), Pound-Rebka, Ludlow, Udem, Colella 等の標準外部文献であり、シリーズ内 relation 対象外。

### A-4. Is part of

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is part of | Paper #1 | 10.5281/zenodo.16759284 | シリーズ membership default (relations-strategy.md)。起点 #1 を series の親とする。 |

注: reverse の「Has part」は #1 側に登録しない (方針1)。

### A-5. Is supplemented by (補正論文を受ける)

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is supplemented by | Paper #28 | 10.5281/zenodo.18636509 | #28 (A Supplementary Correction, 2025-09) が #22 の用いた ve,SR+GR=0.040374c と絶対 ZB 周波数を次元整合性の訂正で supersede する。ただし全面廃止でなく部分訂正 (中心予言 Δν/ν≈5.29×10⁻¹⁰ は純 Schwarzschild 結果で無傷) のため Is obsoleted by ではなく Is supplemented by が正確 (#28 型判断、relation-types.md)。#28 は #22 より後発のため #22 PDF bib には現れないが、補正の事実関係は確定済み。 |

注: #35 (Detailed Exposition, 18511664) は #22 description の Note で言及するが、#22 PDF 外かつ補足説明的な後発論文のため、relation には立てず description 言及のみとする (過剰回避)。必要なら将来 #35 側 relation 整備時に References を検討。

---

## B. Reverse relations — recommended updates to target papers' Zenodo records

各 forward relation の reverse を相手 record の「Related works」に追加し双方向リンクを完成 (Web UI 手作業)。

| Target paper | Add relation | Pointing to | DOI to enter |
|---|---|---|---|
| Paper #14 (10.5281/zenodo.17765097) | Is continued by | Paper #22 | 10.5281/zenodo.17765318 |
| Paper #10 (10.5281/zenodo.17764997) | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 |
| Paper #1 (10.5281/zenodo.16759284) | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 |
| Paper #7 (10.5281/zenodo.17760132) | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 |
| Paper #11 (10.5281/zenodo.17765017) | Is referenced by | Paper #22 | 10.5281/zenodo.17765318 |
| Paper #28 (10.5281/zenodo.18636509) | Is supplement to | Paper #22 | 10.5281/zenodo.17765318 |

注:
- Cites の reverse (Is cited by) は登録しない慣例。
- Is part of の reverse (Has part) は #1 側に登録しない (方針1)。
- #28 側 record には #22 を指す「Is supplement to」を追加 (#28 が #22 を補正する forward)。これは #28 既存 relation list (zenodo_relations_28.md) が #14 のみを Is supplement to 対象としていた場合、#22 を追加する必要があることを意味する。#28 relation list 整備時に #22 を Is supplement to 対象へ追加推奨。

---

## C. Cross-reference notes

- **#1 の Is referenced by 集計更新**: 既存 zenodo_relations_01.md の A-1 (Is referenced by 10本: #11/#14/#22/#24/#28/#29/#31/#48/#51/#60) に #22 は既に含まれている。整合済み。
- **#14 の reverse**: #14 は #22 から「Is continued by #22」を受ける。これは #14 完成版 description / relation 整備時に #14 側 record へ追加する項目。
- **#28 の forward 拡張**: 上記 B 注記のとおり、#28 は #14 に加えて #22 も Is supplement to の対象。#28 relation list に #22 行を追加すると、#14→#22→#28 の補正フローが relation 上でも完結する。
