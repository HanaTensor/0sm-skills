# Zenodo Related Works — Paper #27

**Paper #27** — *Challenging the Uncertainty Principle: A Deterministic Interpretation of Measurement and Reality in Quantum Mechanics*

DOI: 10.5281/zenodo.17765439 (Submitted September 2025)

> 本リストは Zenodo「Related works」欄に手作業登録する relation のガイド。
> **新方針 (relation-types.md Section 0)**: 相手 1 本につき relation は最も実態を表す 1 型のみ。重複登場を避ける。
> Cites の自動併記はしない。同一相手を複数型に出さない (特に #1 は Is part of か Cites の一方)。
> 全 forward relation は #27 現物 PDF の bibliography の検証に基づく。推定なし。
> reverse は本リストに再掲せず、一括処理台帳 `reverse_pending.md` に集約。

---

## A. Forward relations — register on Paper #27's own Zenodo record

各相手は下表のいずれか 1 行にのみ登場 (重複なし)。

### A-1. Is supplement to (補正フローの直系、1 本)

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is supplement to | Paper #28 | 10.5281/zenodo.18636509 | #27 Section 7 の inline CORRECTION (2025-09-18 dated) は #14 の臨界半径主張を「no physical basis」と部分撤回し、note 内で「a detailed dimensional analysis and error correction has been submitted as a supplementary paper」と #28 を forward reference する。#27 はこの正式 correction (#28) の先行 acknowledgment として機能するため、両者を補正フローの対として Is supplement to で結ぶ。reverse は #28 への Is supplemented by。 |

### A-2. Cites (bib 掲載の基盤参照、各 1 回のみ)

bibliography に掲載され、#27 の central content を支える Hanamura 論文。Is supplement to 対象 (#28) と重複しない範囲で Cites に留保。

| Relation | Target | DOI | bib | Rationale |
|---|---|---|---|---|
| Cites | Paper #10 | 10.5281/zenodo.17764997 | [1] | bridge identity γ = 1 + a (Eq. 1) の出典。Section 3 で central organizing identity として使用。 |
| Cites | Paper #11 | 10.5281/zenodo.17765017 | [7] | proper time + geodesic radiative energy transfer の前段。Section 9 の internal-time = proper-time identification を支える。 |
| Cites | Paper #14 | 10.5281/zenodo.17765097 | [4] | ZB 速度・臨界半径 framework の出典。Section 4/7/8 の数値基盤 (ただし当該数値は #27 自身の inline correction + #28 で撤回)。**訂正対象だが正式 correction は #28 が担うため、#27 の relation 上は bib 参照として Cites に留保**。 |
| Cites | Paper #6 | 10.5281/zenodo.17759908 | [3] | 0-sphere と電子モデルの対応 (Correspondence Between a 0-Sphere and the Electron Model)。#27 Section 3 の particle-as-spacetime-structure programmatic statement を支える初期 corpus 論文。**#27 PDF bib は viXra:2001.0610 表記だが corpus #6 = Zenodo DOI 17759908 に対応 (公開リストで確定)**。 |
| Cites | Paper #8 | 10.5281/zenodo.17760445 | [13] | 熱振動による電子・陽電子対消滅 (Consideration of electron-positron pair annihilation)。#27 Section 7 の annihilation 言及の出典。**#27 PDF bib は viXra:2107.0029 表記だが corpus #8 = Zenodo DOI 17760445 に対応 (公開リストで確定)**。 |
| Cites | Paper #4 | 10.5281/zenodo.17759699 | [17] | 二重スリット実験の完全コントラスト不可能性 (Perfect Contrast Cannot be Obtained in the Electron Double-Slit Experiment)。#27 の deterministic measurement 解釈を支える初期 corpus 論文。**#27 PDF bib は viXra:1906.0275 表記だが corpus #4 = Zenodo DOI 17759699 に対応 (公開リストで確定)**。 |

注: Eq. 2 (cos⁴+sin⁴+½sin² 恒等式) は #1 由来、bib では [5] に対応。#1 は次節 Is part of に回し Cites には重複させない (新方針)。
注 (2026-06 更新): 旧版で「uncurated 早期 papers (relation 対象外)」とした 3 本は、公開リストにより corpus #6・#8・#4 = Zenodo DOI 確定。viXra 表記を廃し DOI 表記で Cites に格上げ。Zenodo record 側に viXra origin が記載済みのため corpus 内表記は DOI に一本化。

### A-3. Is part of (シリーズ membership、1 本)

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is part of | Paper #1 | 10.5281/zenodo.16759284 | シリーズ membership default。起点 #1 を series の親とする。Eq. 2 energy-conservation 恒等式の出典でもあるが、**#1 は Cites に重複させず Is part of のみ** (新方針)。 |

---

## B. Reverse relations

reverse (相手 record への追記) は本リストに再掲せず、一括処理台帳 `reverse_pending.md` に集約する。
該当 reverse (本リスト forward の対):

- #28 ← **Is supplemented by #27** (Is supplement to の reverse → 台帳に積む)
- #10 / #11 / #14 / #6 / #8 / #4 ← (Cites の reverse「Is cited by」は登録しない慣例 → 台帳記載なし)
- #1 ← (Is part of の reverse「Has part」は方針により登録しない → 台帳記載なし)

→ 実質、台帳に積む reverse は **#28 への Is supplemented by 1 件のみ**。

---

## C. 適用外の参照 (relation 対象外)

#27 bib のうちシリーズ内 relation 対象としないもの:

- **外部標準文献**: [2] Einstein-Podolsky-Rosen 1935、[6] Schrödinger 1930 (Zitterbewegung 初出)、[8] Bohm 1952 (hidden variables)、[9][10] Thomas 1926/1927、[11] Weinberg QFT、[12] Hartle GR、[14] Fan et al. 2023 (electron magnetic moment 測定)、[15] Einstein 1912、[16] Penrose 1971 (combinatorial spacetime)。シリーズ内 relation 対象外。

> 注 (2026-06): 旧版で本節に「uncurated 早期 papers (relation 対象外)」として挙げた 3 本 (viXra:2001.0610 / 2107.0029 / 1906.0275) は、公開リストにより corpus #6 (DOI 17759908) / #8 (DOI 17760445) / #4 (DOI 17759699) と確定。relation 対象外から **A-2 Cites に格上げ済み**。本節には純粋な外部文献のみを残す。
