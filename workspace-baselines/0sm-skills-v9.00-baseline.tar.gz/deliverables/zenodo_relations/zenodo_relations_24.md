# Zenodo Related Works — Paper #24

**Paper #24** — *Thermal Geodesics in the 0-Sphere Model: Extending General Relativity through Internal Thermodynamic Structure*

DOI: 10.5281/zenodo.17765349 (Submitted July 2025)

> 本リストは Zenodo「Related works」欄に手作業登録する relation のガイド。
> **新方針**: 相手 1 本につき relation は最も適切な 1 型のみ(重複登場を避ける)。
> Cites の自動併記はしない。同一相手を複数型に出さない(特に #1 は Is part of か Cites の一方)。
> 全 forward relation は #24 現物 PDF の bib (参照 [6]-[10][18]) の検証に基づく。推定なし。
> reverse(相手 record への追記)は本リストに再掲せず、一括処理台帳 `reverse_pending.md` に集約。

---

## A. Forward relations — register on Paper #24's own Zenodo record

各相手は下表のいずれか 1 行にのみ登場(重複なし)。

### A-1. Continues (直系の前段、1 本)

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Continues | Paper #18 | 10.5281/zenodo.17765200 | #24 の thermal Lagrangian は #18 を直接の前段として継承(§III.A「building on prior work [10]」)。温度依存内部構造・thermal modulation を受け取り、完全な幾何学的枠組みへ発展させる。最強の直系結合。 |

### A-2. Cites (bib 掲載の基盤参照、各 1 回のみ)

bibliography に掲載され、#24 の論証を支える Hanamura 論文。Continues 対象 (#18) と重複しない範囲で Cites に留保。

| Relation | Target | DOI | bib | Rationale |
|---|---|---|---|---|
| Cites | Paper #14 | 10.5281/zenodo.17765097 | [6] | レプトン異常磁気モーメント・ZB 速度の定量結果を提供。 |
| Cites | Paper #22 | 10.5281/zenodo.17765318 | [7] | 内部量子時計の重力赤方偏移。time-dilation 結合の前例。 |
| Cites | Paper #23 | 10.5281/zenodo.17765336 | [8] | background-independent な spacetime 創発。本論の幾何結合の支え。 |
| Cites | Paper #10 | 10.5281/zenodo.17764997 | [9] | エネルギー分布 KA/KB(Eq.II.1)の出典。 |
| Cites | Paper #19 | 10.5281/zenodo.17765238 | [18] | U(1)/SU(2) ゲージの幾何的起源。Table の gauge-origin 言及の出典。 |

注: #24 bib の Hanamura 論文は [6]=#14, [7]=#22, [8]=#23, [9]=#10, [10]=#18, [18]=#19 の 6 本。多くが viXra 表記だが Zenodo DOI に対応。[10]=#18 のみ Continues、残り 5 本を Cites に割り当て、重複なし。他の参照 ([1]-[5][11]-[17][19]-[21]) は Landau-Lifshitz, Wald, Connes, Gerritsma, Fan, MTW, Jarzynski, Rovelli, Dirac, Barut-Bracken, Hestenes, LeBlanc, Weinberg, Wheeler, Amelino-Camelia 等の標準外部文献でシリーズ内 relation 対象外。

### A-3. Is part of (シリーズ membership、1 本)

| Relation | Target | DOI | Rationale |
|---|---|---|---|
| Is part of | Paper #1 | 10.5281/zenodo.16759284 | シリーズ membership default。起点 #1 を series の親とする。**#1 は Cites に重複させず Is part of のみ**(新方針)。 |

注: #1 の reverse「Has part」は方針1により登録しない。

---

## B. Reverse relations

reverse(相手 record への追記)は本リストに再掲せず、一括処理台帳 `reverse_pending.md` に集約済み。
該当 reverse(本リスト forward の対):

- #18 ← Is continued by #24
- #14 / #22 / #23 / #10 / #19 ← (Cites の reverse「Is cited by」は登録しない慣例 → 台帳記載なし)
- #1 ← (Is part of の reverse「Has part」は方針1で登録しない → 台帳記載なし)

→ 実質、台帳に積む reverse は **#18 への Is continued by 1 件のみ**。
