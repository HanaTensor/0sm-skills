# session_deliverables — #63 Reader's Map / #64 Overview 制作回

- `main_63_readers_map.tex` — 正準 **#63**（旧 #66）. Reader's Map: 線積分→共変微分。内部渦/カイラリティで曲率の族を空間束から置換、地平面凍結予言、2経路収束を決定的未解決問題化、A_μ ボトルネック。確定 abstract（軽量・初見向け）、標準 LLM 謝辞。article-shim で 19pp 検証済み。
- `main_64.tex` — 正準 **#64**. Structural Overview（#1–#63 俯瞰、旧 REV-02 通番化）。#63 を B 統合（カタログ・Capstone 節・Open Tasks O16・Established 節・Reading Roadmap・bibitem）。article で 46pp 検証済み。
- `0SM_63_bessatsu_JP.docx` — #63 の日本語別冊（最短要約＋全12節＋三言語辞書）。
- `build_bessatsu.js` — 別冊生成スクリプト（node + docx）。

コーパス側は HANDOFF v8.05 を参照（番号確定・廃棄・validator 0-error 済み）。#63/#64 の frontmatter は `context/papers/063.md` `064.md`。
