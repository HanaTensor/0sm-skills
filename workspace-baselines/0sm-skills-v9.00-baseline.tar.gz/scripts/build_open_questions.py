#!/usr/bin/env python3
"""
build_open_questions.py

Specialized aggregator for open theoretical/programmatic tasks across the
0-Sphere Model paper series.

Differs from build_aggregate.py:
  - Aggregates TWO frontmatter fields with cross-reference:
      * opens_tasks  (per-paper articulated open tasks)
      * closes_tasks (per-paper articulated closure events; injected as
                      forward closure annotations on the corresponding
                      open task entries from earlier papers)
  - Includes a manually-articulated preamble section listing
    series-central programmatic open tasks that span multiple papers
    (forward-chain tasks not expressible in any single paper's frontmatter).
  - Includes a closure events index at the bottom (reverse view).

Output: context/derived/open-questions.md

Usage:
  python build_open_questions.py \\
      --input context/papers \\
      --output context/derived/open-questions.md
"""

import argparse
import re
import sys
from pathlib import Path
from collections import defaultdict

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required. Install with: pip install pyyaml")
    sys.exit(2)


FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


# ---------------------------------------------------------------------------
# Manual preamble: series-central programmatic open tasks + status legend
# ---------------------------------------------------------------------------
# This preamble articulates cross-paper open tasks that cannot be expressed
# in any single paper's frontmatter::opens_tasks (forward chains spanning
# multiple papers, status transitions across the series, etc.).
#
# When series-central tasks evolve (e.g., partial closure achieved in a new
# paper), update this preamble alongside the new paper's curate.
# ---------------------------------------------------------------------------

MANUAL_PREAMBLE = """## シリーズ中核の programmatic open tasks (cross-paper)

個々の paper frontmatter には記述しきれない、**複数 paper を貫く forward chain task** および **シリーズ全体を貫く central programmatic task** をここに articulate する。各 task の現状 closure 状況を維持的に update する。

### 1. Forward chain: Thomas precession → v_ZB → γ_L → 1+a_e

- **由来**: #47 opens_tasks ii「Forward chain Thomas precession → v_ZB (independently of a_e) → γ_L → 1+a_e の central programme task」(Sec VI 「the central open task of the 0-Sphere research programme」)
- **現状**: **OPEN** ─ 現在 v_ZB は #10 で a_e^exp からの inverse calculation で derive、forward derivation (Thomas precession から a_e 参照なしに v_ZB を直接 derive) は未到達
- **Approach 候補** (HANDOFF v7.9 baseline で curated):
  - #48: U(1) fiber bundle topological g=2
  - #50: helical reframe with Wilson lines
  - #58: spin-2 mediator
  - これらは forward chain への各 angle approach、ただし forward derivation 自体は未到達
- **Experimental closure path**: Penning trap precision > 10⁻²² m level (#10 update_history opens_tasks iii)、技術的困難
- **Significance**: シリーズの最重要未解決 task、本 chain の closure は g=2 mechanism の forward derivation を意味する

### 2. ω_µ ↔ Γ^µ_αβ explicit relationship (Internal connection ↔ Christoffel symbols)

- **由来**: #37 opens_tasks (3)「Sec VII explicit open task: 0SM internal connection ω_µ (line-integral 1-form, Eq. IV.1) と GR Christoffel symbols Γ^µ_αβ (spacetime curvature encoding) の explicit mathematical correspondence」
- **現状**: **OPEN (preliminary work setup 段階)**
- **Curatorial path** (本 task は #30 → #34 → #37 → #57-#60 を貫く central programmatic open task):
  - #30 (Trilogy II, From Curvature to Connection): preliminary work setup ─ curvature を accumulated phase histories の consistency condition として framework setup
  - #34 (Geometrical Confinement): gravity emergence founder
  - #37 (mgh reinterpretation): mgh = ℏΔω quantitative identity 経由の reinterpretation
  - #57-#60: Y_ℓ^m imprinting + spin-2 + Coulomb locking + BSBM triangle で段階的 articulation
- **Significance**: シリーズの emergent gravity programme の central derivation target、formal correspondence の completion は未達成

### 3. Full non-Abelian treatment of internal connection ω_µ

- **由来**: #37 opens_tasks (2)「Sec IV.B explicit open task: present work では effective U(1)-like connection として treat、A full non-Abelian treatment of the internal connection will be developed elsewhere」
- **現状**: **段階的 closure 進行中 (full non-Abelian framework completion は未達成)**
- **Closure path**:
  - #38 (Berry phase + topological g=2): SU(2)/Berry phase の formal connection
  - #48 (U(1) fiber bundle + topological g=2): fiber bundle 形式での specific treatment
  - #50 (helical reframe with Wilson lines): Wilson line 形式での non-Abelian articulation
  - #55 (Wilson line as ontological primitive): full ontological commitment
- **Significance**: spinorial structure の geometric foundation の completion target

### 4. 1/r² gravitational scaling derivation

- **由来**: #37 opens_tasks (1)「Sec IX explicit open task: 内部 photon-mediated near-neighbor synchronization から observed 1/r² Newtonian gravitational scaling の microscopic derivation」
- **現状**: **OPEN (#57-#60 chain で partial close、full microscopic derivation は #61 helium-4 closed-shell negative control を含めても完結していない)**
- **Closure path**: #57 (Y_ℓ^m imprinting + directed-path absorption) → #58 (spin-2 rank-2 tensor structure) → #59 (Coulomb locking, bound-state directional emission) → #60 (BSBM triangle, geometric constraint)
- **Significance**: 0SM emergent gravity の core mechanism derivation

### 5. 対消滅 vs Cooper pair の区別理論

- **由来**: #8 opens_tasks 筆頭 (HANDOFF v7.7+ で継続監視)
- **現状**: **OPEN** (理論未完成、HANDOFF v7.7 articulate「Mathematical approach (Thomas 2ωt) ↔ Geometric approach (Riemann bivalence) formal bridge 未到達」)
- **Significance**: 同一電子内 dual kernel mechanism の物理的区別 ─ Cooper pair (separate electrons coupled) vs antiparticle annihilation (kernel A/B internal opposition) の formal distinction

### 6. v_ZB ≈ 0.04047c の独立 experimental verification

- **由来**: #37 opens_tasks (5)「Sec III.2 + Appendix A: v_ZB ≈ 0.04047c は #10 inverse calculation で a_e^exp から derive、independent experimental measurement (g-factor experiments とは independent) は未実施」
- **現状**: **technically-difficult** (current measurement state-of-the-art を超える precision required)
- **User 明示 framing**: 「現在も『生きて』いる２つ目の数値予言」(twin pair = v_ZB SR-only + Δν SR+GR)
- **Candidate experimental strategies**: Penning trap g-2 + attosecond spectroscopy + trapped ion simulations
- **Cross-reference**: predictions.md の v_ZB entry と相互参照

---

## Status legend

`opens_tasks[].status` field は自由記述。以下が頻出 (出現頻度順):

| 典型値 | 意味 |
|---|---|
| `open` | 未解決、closing path 未確定または進行中 |
| `addressed` | partial に取り組まれたが complete closure ではない |
| `partial` / `partially closed` | 部分的に解決、subsequent paper で残り処理予定 |
| `closed` / `fully closed` | 完全に解決済 (closes_tasks で counterpart 確認可能) |
| `answered` | 質問に対する回答が articulate された (closure type の variant) |
| `technically-difficult` | 理論的には articulate 済だが実験的検証が技術的に困難 |
| `refuted` / `withdrawn` | 当該 task の前提が反証された (例: #14 由来 v_e,SR+GR via #28 → #37 Appendix A) |
| `inherited` | 前 paper から継続 articulate された task |
| `deferred` | 明示的に future paper へ委ねられた |

各 task entry の `status` field は自由記述のため、上記 keyword の前後に paper-specific articulation が付随することが多い (例:「partial closure in #48 → conceptual closure in #50 → final closure in #53」)。closure 履歴は status field 内に inline で articulate される convention。

---

## opens_tasks aggregate (paper 順)

以下、各 paper の `frontmatter::opens_tasks` を paper 番号順に集約。各 task に対して、後続 paper の `closes_tasks` で counterpart record がある場合は **▸ Closure** annotation で前向き trace 可能にする。

"""


CLOSURE_EVENTS_HEADER = """

---

## Closure events index (closes_tasks 由来、逆引き view)

各 paper の `frontmatter::closes_tasks` を paper 番号順に集約。`paper N closes paper M's task X` の形式で、open task の forward closure trace を提供する。

"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def extract_frontmatter(filepath):
    text = filepath.read_text(encoding="utf-8")
    m = FRONTMATTER_RE.match(text)
    if not m:
        return None
    return yaml.safe_load(m.group(1))


def render_open_task(item, closure_annotations):
    """Render a single opens_tasks entry, with optional closure annotations.

    item: dict with keys id / description / status
    closure_annotations: list of strings like '▸ Closure: #48 (partial), #50 (full)'
    """
    if not isinstance(item, dict):
        return f"  - {item}"

    tid = item.get("id", "")
    desc = item.get("description", str(item))
    status = item.get("status", "")

    prefix = f"**({tid})** " if tid else ""
    lines = [f"  - {prefix}{desc}"]
    if status:
        lines.append(f"    - **Status**: {status}")
    for ann in closure_annotations:
        lines.append(f"    - {ann}")
    return "\n".join(lines)


def render_closure_event(closer_paper_num, item):
    """Render a single closes_tasks entry."""
    if not isinstance(item, dict):
        return f"  - {item}"
    target = item.get("paper", "?")
    task_id = item.get("task_id", "")
    task = item.get("task", item.get("description", ""))
    quality = item.get("closure_quality", "")
    note = item.get("note", "")

    head = f"  - **#{closer_paper_num} → closes #{target}"
    if task_id:
        head += f" task ({task_id})"
    head += "**"
    if quality:
        head += f" — *{quality}*"
    head += f": {task}"

    if note:
        # Truncate very long notes for readability
        note_str = note if len(note) < 400 else note[:400] + "..."
        head += f"\n    - Note: {note_str}"
    return head


def build_closure_index(papers):
    """Build {(opener_paper, task_id): [closure_annotation_strings]} map.

    closes_tasks entries reference an opener_paper by `paper` field,
    optionally referencing a specific task by `task_id`.
    """
    index = defaultdict(list)
    for p in papers:
        closer_num = p.get("number")
        ct = p.get("closes_tasks") or []
        for item in ct:
            if not isinstance(item, dict):
                continue
            target = item.get("paper")
            task_id = item.get("task_id", "")
            quality = item.get("closure_quality", "")
            quality_str = f" ({quality})" if quality else ""
            ann = f"▸ **Closure**: #{closer_num}{quality_str}"
            index[(target, task_id)].append(ann)
            # Also register without task_id for general paper-level closure
            if task_id:
                index[(target, None)].append(ann)
    return index


def render_aggregate(papers):
    out = []
    out.append("<!-- AUTO-GENERATED. Do not edit body sections directly. -->")
    out.append("<!-- Source: context/papers/*.md frontmatter::opens_tasks + closes_tasks -->")
    out.append("<!-- Generated by: scripts/build_open_questions.py -->")
    out.append("<!-- Manual preamble lives in scripts/build_open_questions.py::MANUAL_PREAMBLE -->")
    out.append("")
    out.append("# 未解決問題全索引（時系列）")
    out.append("")
    out.append("> Fields: `opens_tasks` (primary) + `closes_tasks` (cross-reference)")
    out.append("> Auto-aggregated chronologically from all papers, with manual preamble for series-central programmatic tasks.")
    out.append("")
    out.append("---")
    out.append("")

    # Manual preamble
    out.append(MANUAL_PREAMBLE)

    # Build closure cross-reference index
    closure_index = build_closure_index(papers)

    # Body: opens_tasks aggregate, paper-by-paper
    sorted_papers = sorted(papers, key=lambda x: x.get("number", 999))
    found_opens = 0
    for p in sorted_papers:
        opens = p.get("opens_tasks") or []
        if not opens:
            continue
        n = p.get("number")
        date = p.get("date", "")
        title = p.get("title", "")
        title_short = title[:65] + ("..." if len(title) > 65 else "")
        out.append(f"### #{n} — {title_short}")
        if date:
            out.append(f"*{date}*")
        out.append("")
        for item in opens:
            tid = item.get("id", "") if isinstance(item, dict) else ""
            # Look up forward closure annotations
            ann = closure_index.get((n, tid), []) + closure_index.get((n, ""), [])
            # De-duplicate while preserving order
            seen = set()
            ann_unique = []
            for a in ann:
                if a not in seen:
                    seen.add(a)
                    ann_unique.append(a)
            out.append(render_open_task(item, ann_unique))
            found_opens += 1
        out.append("")

    # Closure events index (reverse view)
    out.append(CLOSURE_EVENTS_HEADER)
    found_closes = 0
    for p in sorted_papers:
        closes = p.get("closes_tasks") or []
        if not closes:
            continue
        n = p.get("number")
        title = p.get("title", "")
        title_short = title[:65] + ("..." if len(title) > 65 else "")
        out.append(f"### #{n} — {title_short}")
        out.append("")
        for item in closes:
            out.append(render_closure_event(n, item))
            found_closes += 1
        out.append("")

    # Stats footer
    out.append("---")
    out.append("")
    papers_with_opens = sum(1 for p in sorted_papers if p.get("opens_tasks"))
    papers_with_closes = sum(1 for p in sorted_papers if p.get("closes_tasks"))
    out.append(
        f"**Total**: {found_opens} open tasks across {papers_with_opens} papers; "
        f"{found_closes} closure events across {papers_with_closes} papers; "
        f"{len(sorted_papers)} papers scanned."
    )
    out.append("")

    return "\n".join(out) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="context/papers")
    parser.add_argument("--output", default="context/derived/open-questions.md")
    args = parser.parse_args()

    papers_dir = Path(args.input)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not papers_dir.is_dir():
        print(f"ERROR: {papers_dir} not found")
        sys.exit(1)

    papers = []
    for p in sorted(papers_dir.glob("*.md")):
        if not p.stem.isdigit():
            continue
        fm = extract_frontmatter(p)
        if fm:
            papers.append(fm)

    content = render_aggregate(papers)
    output_path.write_text(content, encoding="utf-8")

    papers_with_opens = sum(1 for p in papers if p.get("opens_tasks"))
    papers_with_closes = sum(1 for p in papers if p.get("closes_tasks"))
    print(
        f"Generated {output_path} "
        f"(opens_tasks: {papers_with_opens} papers, "
        f"closes_tasks: {papers_with_closes} papers)"
    )


if __name__ == "__main__":
    main()
