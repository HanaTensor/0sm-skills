#!/usr/bin/env bash
# build_all.sh — validator 2本 → derived/ 全再生成 の一括実行
# curate / frontmatter 変更後は必ずこれを実行する。
# 注意: first-occurrences.md の source field は `concepts_first`（`first_occurrences` ではない）。
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== validators =="
python3 scripts/validate_frontmatter.py
python3 scripts/validate_conceptual_moves.py

echo "== derived/ regenerate =="
python3 scripts/build_index.py
python3 scripts/build_aggregate.py --input context/papers --field analogies_first \
  --output context/derived/analogies.md --title "アナロジー初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field equations_first \
  --output context/derived/equations.md --title "方程式初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field concepts_first \
  --output context/derived/first-occurrences.md --title "シリーズ初出 articulations 索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field predictions \
  --output context/derived/predictions.md --title "実験予測索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field corrections_made \
  --output context/derived/corrections.md --title "訂正履歴索引（時系列）"
python3 scripts/build_open_questions.py
python3 scripts/build_origins.py
python3 scripts/build_keywords.py

echo "== done (all clear) =="
