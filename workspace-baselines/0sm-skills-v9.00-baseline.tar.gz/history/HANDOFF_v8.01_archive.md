# 0-Sphere Skill Curation — 引き継ぎ v8.01

**作成日**: 2026-05-30 (Opus 4.8)
**メジャー改版の理由**: #60 までの Zenodo 公開完了に伴い、「#50番台を週1本で積み上げる」フェーズ (v7.X) を終了。本 v8.01 は「#60 までは確定・凍結、#61 以降を Opus 4.8 でクリーンに壁練し直す」新フェーズの起点。v7.X の transition narrative 積層 (1806行) は本版に持ち込まない (歴史は Zenodo 公開レコード + workspace baseline の各 papers/*.md frontmatter + 過去チャットに保全済み、別アーカイブ不要)。

---

## 0. 最初に読む — このセッションでまず参照するもの

1. **`context/doi-canonical.md`** — DOI 正典リスト兼チェック機能。過去論文を読み込む際は**常にこれを正典として DOI を照合**する。新規論文の相互参照は canonical (最新版) を引く。#60以前の公開済み cross-ref に旧 DOI があっても**留置** (触らない)。
2. **`context/papers/*.md`** — 個別論文ダイジェスト (#001〜#065、#16欠番)。#1〜#60 は確定、#61〜#65 は draft。
3. 恒久的なユーザー指示 (核心という語の回避、京セラ・稲盛非言及、論文LaTeX段落改行禁止、日本語返答時の英単語混入回避 等) は **memory が保持**。本 HANDOFF には再録しない。

## 1. 現在の状態 (v8.01)

- **公開済み**: #1〜#60 (#16 永久欠番)。Zenodo 確定・凍結。
- **未公開ドラフト**: #61 (He-4)、#62 (proton)、#63 (neutron)、#64 (gravity/Snell-Fermat)、#65 (g-2 三スケール)。
- **workspace baseline**: context/papers (62 digests: #1-#61 既存 + #62-#65 を v8.01 で新規追加)、context/topics、context/queries、context/threads、derived/、scripts/。
- **個別ダイジェストの粒度**: #1〜#61 は full curate。**#62〜#65 は中粒度 (識別情報・relation graph・主要 equations/concepts・open tasks・本日訂正履歴) で登録、topics 分類や thread 帰属など精査層は壁練フェーズに defer** と各 note に明記。

## 2. 本日 (v8.01 移行) 確定した訂正

- **#65 `hanamura55`**: DOI 18511664 → **19800797** (18511664 は #35 の DOI との取り違え。#55 自身の tex ヘッダー + 公開リスト + baseline で三重確認)。訂正版 tex 出力済み。
- **#64 `hanamura22`**: DOI 欠落補完 (**17765318**) + タイトルを公開版 #22 正式名に統一。訂正版 tex 出力済み。
- **#64 `hanamura05` → `hanamura11`**: 実体は #11 (DOI 17765017)。本文「Paper #5」表記6箇所含めて #11 に統一 (User 判断「実体どおり #11 が正」)。
- **DOI 正典リスト #38**: 18637487 → **18718174** (#37 との重複解消、User 提供の正 DOI)。
- **留置 (v1/v2 相違、対応不要)**: #30 (#54 が v1 18135855 を引く / canonical v2 18819682)、#51 (#55 が v1 19489126 / canonical v2 20388056)。いずれも公開済みのため触らない。

## 3. #61 以降の現況マップ (壁練フェーズの対象)

- **#61 He-4 two-electron algebraic cancellation** — 壁打ち継続中。二チャネル分離 (GW-emission 閉 / source-of-gravity 開)。#57-#60 重依存。Open Problem A-D。本稿 #65 が #61 を参照するため #61 確定後に #65 公開 (並行熟成)。
- **#62 γ-equation → proton** — Zenodo 水準到達。336 MeV kernel rest mass を parameter-free 導出。#63 と companion (#62 先・#63 後、順序固定)。公開前に `HanamuraPaperB` 参照タイトル整合確認 (#63 を neutron 専用のままにするか baryon 一般に広げるか User 判断要)。
- **#63 γ-equation → neutron** — 322.5 MeV、**13.4 MeV proton-neutron kernel 差** (proton kernel が重い、観測と符号逆・約10倍)。γ = 1+|a| で負号障害を解消。
- **#64 gravity as thermal-path optimization** — Snell-Fermat 極値。structural proposal。本日 bibliography 訂正済み。
- **#65 g-2 three-scale frame-independent invariant** — #47-style clarification note。REVTeX 完成稿。B-非依存性は「consistent (not 必然)」に留置 (modest articulation)。

**ハドロン系譜の前進方向 (memory 参照)**: 13.4 MeV 差の物理解釈 (エントロピー方向性 / 束縛反ニュートリノ Lissajous frozen 状態 / 方向依存 chemistry equation)、SU(3) 八重項・十重項拡張、quark pair/frozen-kind 分解 (同フレーバー対=振動 kind 2、異フレーバー単独=frozen kind 1) の全バリオンへの適用。

## 4. 運用方針 (v8.01)

- **本数ノルマ撤廃、質優先**。週1本ペースは v7.35 で見送り確定 (規律の対象を「本数」から「前進」へ)。退職近接を踏まえ「60+本を整合した堅牢な体系として残す」段階。
- **クリーン壁練**: 過去の解釈の積層を引きずらず、必要な論文を都度読み直して網羅的に再検討。Opus 4.8 で新知見の余地を残す。
- **modest articulation discipline 継続**: pattern candidate は著者の明示確認まで modest 段階に留置。unification 主張は consistent / necessary を峻別。
- **DOI チェックは毎回 `doi-canonical.md` 参照**。

## 5. 次セッション entry point 候補

- #62 公開準備 (PaperB 参照タイトル整合 + #63 完成度確認 → #62 単独 or #62→#63 連続公開判断)。
- #61 壁打ち継続 (He-4 二チャネル、#65 と並行)。
- ハドロン系譜前進 (#62/#63 の先: SU(3) 拡張、13.4 MeV 差の物理解釈)。
- #65 公開 (#61 確定後、参照 DOI 化 + companion guide 作成要否)。
- いずれも質優先、本数ノルマなし。
