# 0-Sphere Skill Curation — 引き継ぎ v8.05

**作成日**: 2026-06 (本セッション)
**前版**: v8.04（本文書の下部に historical record として保全）。v8.01–v8.03 は各 archive ファイル。
**本版の主眼**: post-v8.04 **番号確定 renumbering** とコーパス整合。Reader's Map / Structural Overview の通番組み込み、廃棄ドラフトの除去。

## v8.05 確定番号（正準）

| # | 内容 | DOI | status |
|---|---|---|---|
| 59 | Proton-Trapped Electron: Spin-2 Gravitational Radiation | 19932907 | 公開 |
| 60 | Berry–Synge–Bonnet–Myers Triangle | 19932922 | 公開 |
| **61** | γ-Equation Applied to the Proton (336 MeV) | **19934138** | 公開 |
| **62** | The Bridge Equation γ=1+a from First Principles | **20091680** | 公開 |
| **63** | From Line Integral to Covariant Derivative: A Reader's Map（旧 #66 改番） | TBD | draft |
| **64** | The 0-Sphere Model: A Structural Overview（#1–#63 俯瞰、旧 REV-02 通番化） | TBD | draft |

**廃棄（番号なし・没）**: He-4 二電子相殺 / γ→中性子 / Snell-Fermat 重力 / AMM 不変量 g-2（旧 baseline の 061/063/064/065）。「旧版 #65 以降への繰り下げ不要」（User 確定）。

## v8.04 → v8.05 実施内容

1. **番号不整合の発見と是正**: 旧 baseline は陽子=#62/20091680・He-4=#61/19934138 と誤記。公開 zenodo リスト基準（陽子=#61/19934138・Bridge Eq=#62/20091680）に統一（User 確定: 「#62=Bridge Equation 20091680 available」）。
2. **廃棄**: 旧 061(He-4)/063(中性子)/064(Snell-Fermat)/065(AMM) の各ドラフト frontmatter を削除。
3. **改番**: 旧 062(陽子) → **061.md**（number 61、DOI 19934138 へ訂正、status published、companion(中性子) 除去）。
4. **新規作成**: **062.md**（Bridge Eq、type:research）/ **063.md**（Reader's Map、type:synthesis、former_number 66）/ **064.md**（Structural Overview、type:synthesis、companion_to 63）。threads/topics は壁練 defer 方式（drafts 慣例）。
5. **既存バグ修正**: 027.md の `supplements: 28`（int）→ `[28]`。これが旧 baseline で validate_frontmatter を TypeError 停止させていた。
6. **双方向リンク整合**: 旧 #61(He-4) が登録されていた 8 topics（berry-phases/emergent-spacetime/gravity-mediation/helicity-chirality/line-integrals/synge-world-function/weak-equivalence-principle/zitterbewegung）の applies_to から #61 を除去。
7. **doi-canonical.md** を上記正準へ更新（#1〜#64、廃棄 note 追記）。
8. **derived/ 全再生成**（index/analogies/equations/first-occurrences/predictions/corrections/open-questions、coverage #1–#64）。
9. **validator 全 clear**: `OK: 63 paper(s), 30 topic file(s)` + `✓ All paper references resolve`。

## 本セッションの paper 成果物（tar の `session_deliverables/` 同梱）
- `main_63_readers_map.tex`（#63 Reader's Map、内部渦・地平面凍結・2経路収束・A_μボトルネック、確定 abstract、標準 LLM 謝辞）
- `main_64.tex`（#64 Overview、#1–#63 俯瞰、#63 を B 統合）
- `0SM_63_bessatsu_JP.docx`（#63 日本語別冊）＋ `build_bessatsu.js`

## 次セッションの壁練 TODO
- #62/#63/#64 の topics/threads 双方向リンク確立（現在 `[]` defer）。
- #62 Bridge Eq の full curate（.tex 入手時に equations_first/relations 精密化）。
- #63/#64 の Zenodo 寄託後に DOI を doi-canonical と各 frontmatter へ反映。

---

# 0-Sphere Skill Curation — 引き継ぎ v8.04

**作成日**: 2026-06-01 (Opus 4.8)
**前版**: v8.03 (2026-06-01、`HANDOFF_v8.03_archive.md` に保全)。さらに前の v8.02 は `HANDOFF_v8.02_archive.md`、v8.01 は `HANDOFF_v8.01_archive.md` に保全。
**本版の主眼**: (1) **`skill_snapshot/` の除去** (§5.2、baseline スリム化・skill↔handoff 連携の整理)、(2) **zip 同梱方針の確定** (§8、baseline tar.gz のみ・ドラフト tex は壁練時のみ個別添付)。

> **本 tar は完全スナップショット (フルバックアップ)**。差分チェーンではなく、この 1 本で過去の全状態を引き継げる。v8.03→v8.04 は skill_snapshot を外し baseline をスリム化した版 (deliverables・papers・derived の実体は不変)。v8.01〜v8.03 の確定事項 (アーカイブ設計 §1・lead_tag 体系 §2・relation 冗長回避 §3・viXra→DOI §3.5・#27 deliverable §4) はすべて本版に保持済み・引き続き有効。
>
> **版管理の原則 (User 確定 2026-06)**: 各 v8_NN tar は単独で全状態を含む完全スナップショットとする。差分パックは作らない (原本依存と全差分保管の二重負担を避ける)。最新 tar 1 本だけで全引き継ぎが完結する状態を維持する。

---

## 0. 最初に読む

1. **`context/doi-canonical.md`** — DOI 正典。読み込み時は常にこれで照合。#60 以前の公開済み cross-ref に旧 DOI があっても留置。#16 永久欠番。**末尾に viXra→DOI 表記統一規約あり (§3.5 と対応)**。
2. **`context/papers/*.md`** — 個別論文ダイジェスト (#1〜#65、#16欠番)。#1〜#60 公開確定、#61〜 draft。**`lead_tag` / `is_foundational` フィールドが分類の正典**。
3. **規約の正典は skill `0sm-zenodo-upload`** (lead_tag 定義・執筆標準・relation 型・テンプレート)。baseline はそのコピーを持たない (§5.2)。skill が会話に load されていれば SKILL.md / references/*.md を直接参照。load されていなければ規約参照系の作業 (description/relation 生成) の前に skill を有効化する。
4. 恒久的ユーザー指示 (「核心」回避、京セラ・稲盛非言及、LaTeX 段落改行禁止、日本語返答時の英単語混入回避、SUS304 既定、VS-80 非言及、viXra→DOI 表記統一、zip 同梱方針 等) は **memory が保持**。本 HANDOFF には再録しない。
5. **アーカイブ設計 (§1)・lead_tag 体系 (§2)・relation 冗長回避 (§3)・viXra→DOI 表記統一 (§3.5) を必ず把握。**
6. **`deliverables/`** — 完成済み zenodo description/relation。#13/#22/#24/#27 の 4 本 (§4 の表参照)。

---

## 1. アーカイブ設計の確定 (v8.02 の中心的成果)

### 1.1 役割分担 (single source of truth)

| 領域 | 所在 | 性質 |
|---|---|---|
| 可変コンテキスト (壁練の構想・棄却案・未発表草稿 #61〜・検討中 relation・thread 試行錯誤) | **workspace (tar) = 正典** | 完全保持・間引かない |
| 不変の規約 (lead_tag 8分類定義・写像規則、relation 冗長回避、冒頭タグ規約、Distilled/混成執筆標準) | **skill** | 規約のみ・データ実体を持たない |
| 公開済み論文の確定データ (DOI/title/date/分類/relation) | **workspace frontmatter を正典**、skill は参照規則だけ | 二重管理しない |

### 1.2 確定した運用原則

- **転写には情報が落ちる** (意図的削除・パース取りこぼし・要約劣化の3経路)。ゆえに workspace を間引いて skill に移し替えない。**workspace = 完全な正典**を維持。
- **紛失リスクは GitHub 保管で解決** (転写でなく多重バックアップで)。GitHub なら版管理付き・サイズ無制限・一括改訂容易 (python スクリプト + validator 同梱)。
- **skill には中身の劣化コピーを置かない**。索引等「損失が痛くない派生物」のみ可。論文の中身本体 (要約・concepts 詳細・curate コメント) は workspace 正典に残す。
- **PDF 原本**は Claude が原文細部を確認したいときだけ都度アップロード。通常は `papers/0XX.md` ダイジェストで足りる。

### 1.3 境界線

**Zenodo 公開済み (#1〜#60、DOI 確定・凍結) か否か**で区切る。公開済み → workspace frontmatter を正典参照 (skill にコピーしない)。未公開 (#61〜) → workspace に残し handoff v8_XX で引き継ぐ (tar 方式は「練りに練った」資産として継続)。

### 1.4 GitHub 化の推奨 (未実施・次アクション候補)

workspace tar を GitHub repo に push → 紛失リスク解消 + 版管理。public repo の raw URL なら Claude が web_fetch で直接読める (raw.githubusercontent.com / github.com は許可ドメイン)。private なら従来どおり tar アップロード。

---

## 2. lead_tag 体系の確定 (v8.02)

### 2.1 8分類 (skill description-html.md Section 2.5 に定義)

description 冒頭に独立段落 `<p>[#N Tag]&nbsp;</p>` として付与 (導入文に続けない・`&nbsp;` 必須)。

| Tag | 性格 |
|---|---|
| Foundational | 存在論的前提・方法論・枠組み自体を据える (個別現象でなく formalism) |
| Essential | 骨格をなす基盤論文 (中核概念・恒等式・予言本体) |
| Application | 既存結果を現象・観測量へ応用、検証可能予言 |
| Supplement | 既存論文の補足・拡張 (訂正でない追補) |
| Correction | 既存論文の誤り訂正 (部分訂正) |
| Structural | 論理構造・前提・適用範囲の画定 |
| Synthesis | 複数論文の統合・総括 |
| Conceptual | 解釈・概念の明確化が主眼 |

### 2.2 写像規則 (frontmatter → lead_tag)

- `is_foundational: true` → Foundational
- `type: correction` → Correction
- `type: note/supplement/clarification` + `subtype: structural(-proposal)` → Structural
- `type: supplement/clarification` + `subtype: conceptual(-and-mathematical)` → Conceptual (or Supplement)
- `type: research` + `is_foundational: false`: 観測量/予言応用 → Application / 概念整理 → Conceptual / 通常 → Essential

`lead_tag` / `lead_tag_confidence` は全 paper に導入済み (confirmed=確定 / default=暫定・現物未読)。

### 2.3 Foundational 9本 (v8.02 確定)

**#1, #3, #7, #10, #13, #17, #19, #20, #24**。

v8.01 までは 7/8 本。本版で **#24 (Thermal Geodesics) を追加** (User 判断 2026-05-31)。#24 = thermal geodesic formalism の founder = 枠組み自体を据える。`024.md` を is_foundational false→true、lead_tag Essential→Foundational、confidence default→confirmed に更新済み。

---

## 3. relation 冗長回避の確定 (v8.02、skill relation-types.md Section 0)

**冗長回避の本質 = 「同じ相手が複数の relation 型で重複登場するのを避ける」。**

- 相手 1 本につき relation 1 型のみ。
- Cites の自動併記をしない (Continues/References があれば足りる)。
- #1 (起点) は Is part of か Cites の一方のみ (membership なら Is part of 優先)。
- Continues/References/Is supplement to を立てない相手は Cites に留保可。
- reverse は Continues/References/Is supplement to の対のみ台帳 (`deliverables/zenodo_relations/reverse_pending.md`) に積む。Cites の reverse (Is cited by)・Is part of の reverse (Has part) は登録しない。
- 適用開始 = #24 以降。#13/#22 の既存成果物は旧方式 (Cites 併記) 残置・再編集しない。

---

## 3.5 viXra→DOI 表記統一の確定 (v8.02+、2026-06 確定)

**論文間の相互参照 (back-ref) は今後すべて Zenodo DOI 表記に統一する。viXra 表記は廃止。**

確定理由: Zenodo record 側に origin として viXra リンクが記載済みのため、corpus 内では DOI 表記に一本化すれば十分 (User 確定 2026-06)。

運用:

- frontmatter の relation/references、relation 成果物、description のいずれでも、Hanamura 論文の参照は `10.5281/zenodo.NNNNNNNN` 形式で記す。論文現物 (PDF bib) が viXra 表記でも、corpus 内表記は DOI に直す。
- corpus 全体の見直し機会には `grep -rn viXra context/papers/` で残存箇所を洗い出し、一括で DOI 表記へ揃える。
- 確定済み参照点 (#27 改訂で viXra→DOI 化した 3 本、doi-canonical と一致):
  - #4 = 10.5281/zenodo.17759699 (Perfect Contrast, 双スリット。旧 viXra:1906.0275)
  - #6 = 10.5281/zenodo.17759908 (0-Sphere/電子モデル対応。旧 viXra:2001.0610)
  - #8 = 10.5281/zenodo.17760445 (電子・陽電子対消滅, 熱振動。旧 viXra:2107.0029)
- 副次効果: 「uncurated 早期 papers / series 番号未確定」として relation 対象外にしていた論文も、corpus 番号 + DOI が確定すれば Cites 等に格上げする (#27 で #4/#6/#8 を §C「対象外」→ A-2 Cites に格上げ済み)。

---

## 4. zenodo description/relation 作業の進捗

### 4.1 執筆標準 (確定)

- **第1段落 = lead tag 独立段落 + 導入 (OpenAIRE 転写対象)**: Plain text / HTML entity のみ・MathJax なし・生 Unicode 禁止。
- **第2段落以降 = Distilled 構成 + MathJax**: `— What This Paper Establishes —` 等。Zenodo MathJax で `\(...\)` `\[...\]` render。
- 検証: LaTeX delimiter(lead に不在)/生非ASCII(全体不在)/HTML allowlist/STALE ID/DOI 照合/math delimiter 均衡。preview は KaTeX inline (`/home/claude/work/katex_inline.css`、woff2 base64 inline)。

### 4.2 完了済み成果物 (`deliverables/`)

| Paper | lead_tag | desc | rel | 備考 |
|---|---|---|---|---|
| #13 | Foundational | 790語 | ✓ | Continues #10 / References #1 / Is part of #1。17765079=#13 確定 (「#15相当」誤り訂正)。真#15=17765121 |
| #22 | Application | 混成1191語 | ✓ | Continues #14 / References #10,#1,#7,#11 / Is part of #1 / Is supplemented by #28。混成方式 第1号 |
| #24 | Foundational | 混成898語 | ✓ | Continues #18 / Cites #14,#22,#23,#10,#19 / Is part of #1。relation 冗長回避 第1号 |
| #27 | Conceptual | 標準6section | ✓ | Is supplement to #28 / Cites #10,#11,#14,#6,#8,#4 / Is part of #1。v8.03 で新規完成。旧 desc (Supplement・3段落・規約違反) を全面改訂。#14→#27(inline ack)→#28(formal) 訂正系譜を明示。初期 corpus #4/#6/#8 を viXra→DOI 化し §C「対象外」→Cites 格上げ (表記統一第1号) |

前セッション完了分 (旧 handoff): #1,#6,#7,#10,#11,#14,#28,#60 description。#1,#6,#7,#10,#11,#14,#28 relation (旧方式含む・再編集しない)。

### 4.3 reverse_pending.md

`deliverables/zenodo_relations/reverse_pending.md`。過去論文 record を都度開かず区切りで一括反映する台帳。pending: #1/#7/#10/#11/#14/#18/#28。**v8.03 で #28←Is supplemented by #27 を追加** (台帳に積む reverse は #28 への Is supplemented by が #22/#27 の 2 件に)。#27 の Cites (#10/#11/#14/#6/#8/#4) は Cites reverse 不登録の慣例により台帳追加なし。

### 4.4 重要な確定・訂正

- **17765079 = #13** (「#15相当」誤り)。真の #15 = 17765121。
- **#28 は #14・#22・#27 から Is supplemented by を受ける** (#14→#22→#28 補正フロー + #14→#27 inline ack→#28 formal)。#28 relation 整備時に #22・#27 両行追加推奨。
- #35 (18511664) は #22 description の Note 言及のみ (relation 立てない)。#55 旧取り違え番号と同値だが #35 自身の正規 DOI、別物。
- **初期 corpus 3 本の DOI 確定** (v8.03、§3.5): #4=17759699 (旧 viXra:1906.0275)、#6=17759908 (旧 2001.0610)、#8=17760445 (旧 2107.0029)。#27 references[] と Cites に DOI 表記で収載済み。

---

## 5. skill 改訂済み (v8.02 セッション)

- `0sm-zenodo-upload/references/relation-types.md`: Section 0 新設 (冗長回避)。旧 2.1 subsuming に廃止注記。
- `0sm-zenodo-upload/references/description-html.md`: Section 2.5 新設 (冒頭タグ独立段落 + 8分類 + 選択指針)。
- `0sm-zenodo-upload/SKILL.md` §4.1: **auto-gen 写像規則を新方針に更新**。相手1本=1型、優先順位 (Is supplement to > Continues > References > Cites) で複数配列を1型に畳む。複数 continues は「最も直接の前段1本」を Continues とし残りは Cites。#1 は Is part of のみ。
- `0sm-zenodo-upload/references/relations-strategy.md`: 冒頭に新方針の上書き注記 (旧 Cites 和集合・multi-relation declare を廃止、正典は relation-types.md §0 と SKILL.md §4.1)。
- バックアップ: `/home/claude/work/skill_backup/`。**skill 配下書き込みの次回永続性は未検証** — 次回確認要。

### 5.2 skill_snapshot 除去と skill↔handoff 連携 (v8.04 確定)

**v8.02 で新設した `skill_snapshot/` を v8.04 で baseline から除去した。** 理由:

- v8.02 §1.1 の原則「skill には中身の劣化コピーを置かない / 転写には情報が落ちる」に snapshot 自身が違反していた。
- 実害: snapshot は実 skill 7 ファイル中 4 ファイルのみ保持 (workflow.md / readme-template.md / latex-standards.md が欠落)、かつ 4 ファイルとも実 skill と版ずれ (古いコピー)。保全の用をなしていなかった。

**確定した連携方式 (ポインタ参照)**:

- **規約の正典 = skill `0sm-zenodo-upload` 本体のみ**。baseline はコピーを持たず、HANDOFF §0-3 がポインタで参照する。
- skill の永続化は **GitHub 依存にしない** (User 方針、2026-06)。理由: 過去に git 連携で raw ファイル読み込みが古いキャッシュしか取れず失敗 (memory #10 の jsDelivr エッジキャッシュ問題と同系)。
- **skill 更新フロー**: Claude が更新版を作成 → User が手動で同名アップロードして上書き (同一 skill 名なら更新される)。
- 規約参照系の作業 (description/relation 生成) を始める前に、skill が会話に load されているか確認。load されていなければ有効化してから着手。

> baseline スリム化: 132 → 128 ファイル (skill_snapshot 4 ファイル・約 2470 行除去)。deliverables / papers / derived の実体は一切不変。

### 5.1 今後のフロー (v8.02 確定)

今後の description/relation 生成は **skill 本来の workspace 駆動 auto-gen フロー**を使う (PDF 手書きでなく)。手順: (1) tar 展開 → `papers/0XX.md` frontmatter 入手、(2) frontmatter の relation graph / concepts_first / analogies_first / lead_tag を正として生成、(3) PDF は曖昧点・正確な数値文言の確認時のみ補助的にアップロード。relation は §4.1 の写像規則で frontmatter から 1型に畳む。

> 注: 今回の #22/#24 は PDF 手書きで作成したため、frontmatter の relation graph (#24 は continues:[10,18,22,23]) と私の手書き結果に差がある。新フロー初回時に #22/#24 を frontmatter 駆動で再照合すると基準が揃う (任意)。

---

## 6. 次セッション entry point 候補

**zenodo desc/rel 系**: 残り公開済み論文 (#17/#19/#20/#23/#25/#26/#29〜#60) の改訂。**#27 は v8.03 で完了** (Conceptual)。役割順推奨 (Foundational ハブ → Application/予言 → 通常 → Structural/note)。PDF/TeX 都度アップロード・現物検証。reverse_pending の一括反映。

**表記統一の corpus 一括適用 (§3.5)**: 今回 #27 が引く #4/#6/#8 のみ DOI 化したが、他論文 frontmatter に viXra 表記の back-ref が残存する可能性。`grep -rn viXra context/papers/` で洗い出し一括で DOI 表記へ揃える。#4/#6/#8 の DOI が参照点。

**壁練系 (v8.01 継続)**: #62 公開準備 (PaperB タイトル整合 + #63 完成度)。#61 He-4 壁打ち (二チャネル、#65 並行)。ハドロン系譜前進 (SU(3) 拡張、13.4 MeV 差の物理解釈)。#65 公開 (#61 確定後)。

**アーカイブ実装**: workspace tar の GitHub 化 (§1.4)。skill 配下書き込み永続性検証 (§5)。

---

## 7. 運用方針 (v8.01 継続)

- 本数ノルマ撤廃・質優先。「60+本を整合した堅牢な体系として残す」段階。
- クリーン壁練 (過去解釈の積層を引きずらない、都度読み直し)。
- modest articulation discipline (pattern candidate は著者確認まで modest 留置。unification は consistent/necessary 峻別)。
- DOI チェックは毎回 doi-canonical.md。
- 現物主義 (relation 型・参照関係を推定で埋めない。PDF/TeX を読んでから作る)。

---

## 8. handoff zip 同梱方針 (v8.04 確定、2026-06)

- **節目で v8_NN を切るとき**: `0sm-skills-v8_NN-baseline.tar.gz` のみを zip 同梱する。ドラフト tex (#64 `__64_main.tex`、#65 `g2_threescale_main.tex` 等) は **同梱しない**。理由: 壁練で草稿が更新されるとスナップショットは即陳腐化するため。
- **#64/#65 を壁練する回・会話途中で新規チャットへ移行する回**: そのとき扱っている最新 `main.tex` を baseline と同時添付する (移行時は最新草稿が baseline 未取り込みのことがあるため)。
- 平常運転 (公開済み論文の desc/rel 改訂、viXra→DOI 一括、#61 He-4 等) は baseline tar.gz 一本で足りる (#64/#65 ダイジェストは `papers/064.md` `065.md` にあり、概要把握はダイジェストで十分。tex 本体は数式文言・本文細部の直接編集時のみ)。
- zip ダウンロード時の挙動: Mac の Safari 設定により zip が自動解凍されフォルダで残ることがある (baseline tar.gz は中で tar.gz のまま)。GitHub 等へ「中身が見える形」で置くなら別途 tar.gz を展開する。差分追跡不要・可搬性優先なら tar.gz のまま保管でよい。
