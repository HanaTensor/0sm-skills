# 0-Sphere Model Workspace — ナビゲーションハブ

> **このファイルが唯一の入口。** どの作業でも最初にここを読み、下の「タスク別読み込み順」に従う。
> 現在状態（論文数・正準番号・未処理事項）は `context/state.md`。履歴は `history/`（通常セッションでは読まない）。

## 構成（何がどこにあるか）

```
README.md            ← 本ファイル（入口・ナビゲーション）
context/
├── state.md         ← 現在状態（正準スナップショット・未処理TODO）— 毎セッション必読
├── doi-canonical.md ← DOI 正典（照合は常にこれ）
├── series-units.md  ← 構造単位台帳（三部作・カルテット・companion 対）
├── papers/          ← 論文個票 63本（#1–#64、#16 永久欠番）= データ正典
├── topics/          ← 19 topics × layer files（0sm / textbook 二層）
├── queries/         ← クエリ層（横断 articulation・書き換え自由）
└── derived/         ← 自動生成インデックス（手編集禁止・build_all.sh で再生成）
    ├── index.md             全論文表・関係グラフ・topic coverage
    ├── keywords.md          キーワード逆引き（統制語彙・スレッド・タイトル語）
    ├── origins.md           起点索引（論文別: 初出考察 + 下流伝播リバースリンク）
    ├── first-occurrences.md 概念初出（concepts_first 集約・時系列）
    ├── analogies.md / equations.md / predictions.md / corrections.md
    ├── open-questions.md    未解決問題台帳（opens/closes 集約）
    └── conceptual-moves.md  概念的移動（※手動 curate、自動生成でない）
scripts/             ← validator 2本 + build 4本 + build_all.sh（一括再生成）
deliverables/        ← Zenodo description / relation 完成品
history/             ← HANDOFF 歴代アーカイブ（経緯の記録。通常は読まない）
session_deliverables/← 直近セッションの論文成果物（tex / docx）
```

## タスク別読み込み順

| やること | 読む順 |
|---|---|
| 壁練（構想議論） | `state.md` → repo の `wall-practice-index.md`（発火チェーン・open questions・語彙表）→ 必要論文の `papers/NNN.md` → 原文は repo `tex-sources/NN/main.tex` |
| 新規論文 curate | `state.md` → `doi-canonical.md` → skill `0sm-corpus-curate` の手順 → 完了後 `scripts/build_all.sh` |
| 「#N は何の起点?」「#N の下流は?」 | `derived/origins.md` の #N セクション（1箇所で完結） |
| キーワードから論文を探す | `derived/keywords.md` → ヒットした `papers/NNN.md` |
| 三部作・シリーズ単位の把握 | `context/series-units.md` |
| 未解決問題を攻める | `derived/open-questions.md` + `state.md` の TODO |
| Zenodo 寄託準備 | skill `0sm-zenodo-upload`（規約の正典はスキル側） |
| DOI・番号の確認 | `doi-canonical.md`（他ファイルと齟齬があればこちらが正） |

## 検索レシピ（keywords.md で見つからないとき）

```bash
# 概念・語句の全文検索（個票は日英混在。英語術語は原語で引く）
grep -rn "Wilson line" context/papers/ | head
grep -rln "トーション\|torsion" context/papers/
# スレッドから: C-13 を invoke する論文
grep -l "^  - C-13" context/papers/*.md
# topic から: applies_to は topics/*/0sm.md、逆引き表は derived/index.md 末尾
# 式・記号: derived/equations.md を先に、なければ papers/ を grep
```

## 設計原則（変更しない）

- **workspace = 完全な正典**（個票の記述は間引かない。転写には情報が落ちる）
- **規約はスキル、データは workspace**（skill に劣化コピーを置かない・二重管理しない）
- **derived/ は手編集禁止**（conceptual-moves.md のみ手動 curate の例外）
- **採番史の非保持**（旧番号・改番経緯は記録しない。現行番号のみ）
- **参照表記は Zenodo DOI に統一**（viXra 表記は使わない）
- **履歴は history/ へ**（現在状態は state.md に一元化。HANDOFF に積層させない）
- 節目のスナップショットは `0sm-skills-vN.NN-baseline.tar.gz` 1本で完結（差分パックは作らない）

## 再生成（curate 後は必ず）

```bash
bash scripts/build_all.sh   # validator 2本 → derived/ 全再生成 → 0-error 確認
```
