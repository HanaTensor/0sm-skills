# 現在状態 (state) — v9.00

> **役割**: 「いま何がどうなっているか」だけを持つ。経緯・作業ログは `history/` へ（ここには書かない）。
> 更新規則: curate / 壁練の確定事項が出るたびに該当行を**上書き**する（追記で積層させない）。

**最終更新**: 2026-07-10（v9.00 再構築セッション）

## コーパス正準

- **63 論文、#1–#64（#16 永久欠番）**。#1–#64 すべて Zenodo 公開済み。
- DOI 正典: `context/doi-canonical.md`（齟齬時は常にこちらが正）。
- 直近公開: #63 = 10.5281/zenodo.20767589（2026-06-20, Reader's Map）／ #64 = 10.5281/zenodo.20820646（2026-06-27, Square Root of the Hyperspherical Laplacian）。

## ⚠️ 要整合（次回 curate セッションの最優先）

1. **`papers/064.md` が実公開論文と不一致**。Zenodo 実データの #64 =「The Square Root of the Hyperspherical Laplacian: A Geometric Foundation for Spin Two-Valuedness on S³」(20820646) だが、個票 064.md は旧ドラフト「Structural Overview」のまま。→ #64 実論文（PDF/tex + zenodo_relations.txt）で full curate し差し替える。Structural Overview ドラフトの扱い（番号付与 or 保留）は User 確定待ち。
2. **#63 の full curate 未了**: 個票 063.md は draft 時点の digest。公開版 (20767589) の relations / concepts_first を現物で確定する。
3. #62 Bridge Eq の equations_first / relations 精密化（.tex 現物で）。
4. #62/#63/#64 の topics / threads 双方向リンク確立（現在 defer `[]`）。

## バリデータ状態

`OK: 63 paper(s), 30 topic file(s)` + `✓ All paper references resolve`（v9.00 再構築後に全クリア確認済み）。
再生成は `bash scripts/build_all.sh` 一発。

## Zenodo description / relation 進捗

- 完成済み: #13 / #22 / #24 / #27（`deliverables/`）。旧セッション分: #1, #6, #7, #10, #11, #14, #28, #60 description（relation は旧方式含む・再編集しない）。
- 未着手: #17 / #19 / #20 / #23 / #25 / #26 / #29–#59 / #61–#64。推奨順: Foundational ハブ → Application/予言 → 通常 → Structural/note。
- reverse 反映待ち台帳: `deliverables/zenodo_relations/reverse_pending.md`（#1/#7/#10/#11/#14/#18/#28。#28 への Is supplemented by は #22/#27 の2件）。

## 壁練の主要 open questions（座標。詳細は derived/open-questions.md と repo wall-practice-index.md）

- #62 速度レベル比残差（2^(−1/4) vs 1/√2）
- #63 の3問題: A_μ の実体／Ω_T の rank-2 性／2経路収束と torsion 残差
- #64 平方根分岐の並行性・Wick 回転橋
- 中性子 13.4 MeV 差の物理解釈（ハドロン系譜 SU(3) 拡張）
- 安定性の起源3難点（非対称二振動子の束縛・ω₁/ω₂↔a の橋・#9 整合）
- 検証予言: 地平面凍結 Ω_T∝v_ZB²→0／Δν/ν≈5.29×10⁻¹⁰／ZB≈0.04c／可視性限界

## 運用中の確定原則（恒久）

- 本数ノルマ撤廃・質優先。クリーン壁練（過去解釈の積層を引きずらない）。
- modest articulation discipline（pattern candidate は User gate 通過まで modest 留置）。
- 現物主義（relation・参照関係を推定で埋めない。PDF/TeX を読んでから作る）。
- 採番史の非保持／viXra→DOI 表記統一／恒久的ユーザー指示は memory 準拠（ここに再録しない）。
- skill 更新フロー: Claude が改訂版作成 → User が同名アップロードで上書き（GitHub 依存にしない）。

## 外部リソース

- GitHub: `HanaTensor/0sm-skills` — 一次資料 `tex-sources/NN/`、baseline tar `workspace-baselines/`、壁練入口 `wall-practice-index.md`、公開 DOI 表 `index.md`。
- Zenodo community: https://zenodo.org/communities/satoshi-hanamura-papers
