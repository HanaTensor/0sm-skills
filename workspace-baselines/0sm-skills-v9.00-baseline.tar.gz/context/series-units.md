# 構造単位台帳 (series units)

> **手動 curate**（auto-generated ではない）。複数論文がひとつの構造単位（三部作・companion 対・テーマ系列）を
> なす場合の正典台帳。単位の存在根拠は各 `papers/NNN.md` の frontmatter（companion_to / trilogy_role / relation コメント）。
> 新単位の追加は curate セッションで frontmatter に根拠を書いた上でここに登録する。
>
> 最終更新: 2026-07-10 (v9.00)

## 命名つき系列 (named series)

| 単位 | 構成 | 役割分担 | 補遺・随伴 |
|---|---|---|---|
| **Line Integral Trilogy（線積分三部作）** | #29 → #30 → #31 | Part I #29: thermal geodesic 上の spinorial phase accumulation の幾何学的基礎（founder）／ Part II #30: Einstein 方程式を「集約された線積分への global consistency condition」として再解釈／ Part III #31: AB 効果・Berry 位相・Wilson loop を line-integral-of-connection の単一原理へ統合（completion） | supplements: #40, #41, #43, #45（三部作への補遺群）。下流の主要応用: #32 (真空エネルギー), #33 (閉じ込め), #37 (重力 PE), #54 (Maxwell 導出) |
| **Foundational 9** | #1, #3, #7, #10, #13, #17, #19, #20, #24 | 系列全体が前提する中核機構を据える基盤論文集合（lead_tag: Foundational）。#24 は thermal geodesic formalism の founder として 2026-05-31 に追加確定 | — |
| **重力媒介クインテット** | #49 → #50 → #51 → #52 ＋ #53 | #49: photon-sphere fragmentation = 重力媒介／#50: スカラー振動からの回転創発／#51: helical 軌道・固定端点線積分・計量創発／#52: WEP の幾何学的起源（λ_C 相殺定理）／#53: 4本への conceptual & mathematical supplement（総括） | 下流: #57–#60（spin-2 系列・BSBM Triangle） |
| **Spin-2 重力放射系列** | #57 → #58 → #59 | #57: 球面調和インプリンティング（重力結合の微視機構）／#58: 重力メディエータの spin-2 構造／#59: 陽子捕縛電子 = spin-2 重力放射の生成体 | いずれも Structural Proposal。#52/#57/#58 への supplement 連鎖 |
| **γ・橋渡し系列（ハドロン拡張）** | #61 → #62 | #61: γ-Equation の陽子適用（parameter-free 336 MeV）／#62: Bridge Equation γ=1+a の第一原理導出（表現双対性・RMS 因子） | 上流: #10 (bridge eq 初出), #21, #47, #48。open: 中性子 13.4 MeV 差 |

## Companion 対 (frontmatter `companion_to` 正典)

| 対 | 関係の性格 |
|---|---|
| #20 ↔ #25 | programmatic statement (#20) と philosophical foundation (#25) の対 |
| #32 ↔ #33 | integral-ontology の bilateral articulation（vacuum energy 溶解 / rest mass 閉じ込め） |
| #33 ↔ #34 | title 共有の structural sibling（#34 は bibliography で #33 を引かない・implicit 継承） |
| #4 ↔ #38 | 二重スリット可視性限界 Pvis<1 の端緒 (2019) と systematic 完成 (2026)。7年跨ぎの不可分対（User explicit） |
| #40 ↔ #41 | subtitle-parallel companion・相互引用なし（同一テーマへの parallel carriers） |
| #36 ↔ #42 | title-prefix-parallel companion・formal citation あり（非摂動性 supplement 系列） |
| #49 ↔ #50 | fragmentation 機構とその回転創発の対 |
| #54 ↔ #55 | Maxwell 導出と Open Wilson Line の4機能（相互 companion） |
| #63 ↔ #64 | ⚠️ 064.md の個票が旧ドラフト由来のため、実公開 #64 (Hyperspherical Laplacian) との companion 関係は #64 curate 時に再確定する（`state.md` 要整合 1 参照） |

## テーマ系列（壁練の発火チェーン。repo `wall-practice-index.md` と同期）

| テーマ | チェーン（太字 = 現到達点） |
|---|---|
| 熱力学・E₀恒等式 | #1 → #18 → #22 → #33 → **#46** |
| スピン・二値性 | #2, #3 → #13, #19 → #26 → #38 → #48 → #50 → **#64** |
| AMM・γ・橋渡し | #10 → #21 → #47 → #48 → #61 → **#62** |
| 線積分存在論・Wilson線 | #29, #31 → #40, #41 → #45 → #54 → #55 → #56 → **#63** |
| 重力媒介・spin-2 | #34, #35 → #49 → #57 → #58 → #59 → #60 → **#63** |
| 計量創発・Synge | #23, #24 → #30 → #51 → #52 → #53 → #60 → **#63** |
| ゲージ U(1)/SU(2) | #17 → #19 → #26 → #48 → #55 → **#64** |
| 干渉・決定論 | #4 → #5 → #27 → **#38** |
| 真空エネルギー・Λ | #32 → #39 → **#46** |
| 非摂動性・方法論 | #36 → #42 → **#56** |
| トーション | #43 → #45 → **#63** |
| ニュートリノ・安定性（次期） | **#9** |
