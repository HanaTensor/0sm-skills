# Zenodo Description HTML Standard (revised for workspace integration)

> Skill B の zenodo_description.html 標準 reference。Original `description-html.md` (HanaTensor/0sm-skills repository) の content を preserve、Key Contributions / Series Position の workspace 駆動 auto-extract guidance を追加。

---

## 1. 目的と背景

Zenodo Description 欄 (record 詳細ページ表示部分) で、以下を提供する標準 HTML フォーマット:

- 論文の核心概念の要約 (本論文単独で読者が grasp できる)
- 主要数式 (Core Equations) の提示
- Key Contributions list (4-6 items)
- シリーズ位置づけ (continues/supplements/requires papers)
- 主要参照テーブル (references full DOI links)
- Series Context (固定文 + Hanamura Zenodo search link)

## 2. Zenodo の HTML 制限と表示制約

### 2.1 許可されているタグ (Zenodo HTML allowlist)

```
a, abbr, acronym, b, blockquote, br, code, caption, div, em, i,
li, ol, p, pre, span, strike, strong, sub, table, tbody, thead,
th, td, tr, u, ul
```

**重要 制限**:
- `<sup>` は **不可** (上付き文字は Unicode 文字または `<sub>` 代替を使用)
- `style` 属性は **削除される** (CSS 効かない)
- `class` 属性は ignore される (CSS class 効かない)
- `id` 属性は ignore される (anchor link 効かない)
- `<script>` は当然不可
- `<img>` は不可 (Zenodo 内 image hosting 別途必要)

### 2.2 表示制約への対応

#### 2.2.1 数式表示

LaTeX rendering は Zenodo Description で動作しない。数式は:

```
✅ Unicode 文字使用:
   ω₀, v_ZB, c, λ_C, ℏ, ∫, ∮, ∂, ∇, π, θ, φ
   K_int(A,B) = exp(i ω₀ L_int / v_ZB)

❌ LaTeX:
   $\omega_0, v_{ZB}, c, \lambda_C, \hbar, \int, \oint$
```

Subscripts: Unicode subscript characters (`₀ ₁ ₂ ...`) または `_N` notation。
Superscripts: Unicode superscript characters (`⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹`) または **Unicode のみ** (`<sup>` 不可)。

#### 2.2.2 強調 (Bold/Italic)

```html
<b>Bold text</b>          ← 推奨 (CSS-independent)
<strong>Strong text</strong> ← 同等 (semantic stronger)
<i>Italic text</i>          ← 推奨
<em>Emphasized text</em>    ← 同等 (semantic emphasis)
```

`<b>` と `<strong>`、`<i>` と `<em>` は Zenodo description では visual 効果同じ。Semantic distinction 維持のため `<strong>` (importance) と `<em>` (emphasis) を使用、純粋 visual styling は `<b>` / `<i>`。

#### 2.2.3 リスト

```html
<ul>
  <li>項目 1</li>
  <li>項目 2</li>
</ul>

<ol>
  <li>順番付き項目 1</li>
  <li>順番付き項目 2</li>
</ol>
```

ネスト (nested lists) も対応:

```html
<ul>
  <li>Top-level item
    <ul>
      <li>Sub-item</li>
    </ul>
  </li>
</ul>
```

#### 2.2.4 表 (Table)

```html
<table>
  <thead>
    <tr><th>列 1</th><th>列 2</th></tr>
  </thead>
  <tbody>
    <tr><td>値 1</td><td>値 2</td></tr>
  </tbody>
</table>
```

`<caption>` も使用可能 (table の上または下に配置):

```html
<table>
  <caption><b>Table 1.</b> 主要参照テーブル</caption>
  <thead>...</thead>
  <tbody>...</tbody>
</table>
```

#### 2.2.5 リンク

```html
<a href="https://doi.org/10.5281/zenodo.NNNNNNNN">DOI: 10.5281/zenodo.NNNNNNNN</a>
```

Zenodo search link で Hanamura papers 一覧:

```html
<a href="https://zenodo.org/search?q=metadata.creators.person_or_org.name%3A%22Hanamura%2C+Satoshi%22">Zenodo search: Hanamura, Satoshi</a>
```

URL encoding 必要 (`%22` = `"`, `%3A` = `:`, `+` = space)。

## 3. Description HTML テンプレート (標準 6 sections)

```html
<!-- ========== Section 1: 導入段落 ========== -->
<p>
[1-2 sentences: paper の central thesis を natural language で要約]
</p>

<!-- ========== Section 2: Core Equations ========== -->
<p><b>— Core Equations —</b></p>

<p>
<b>[Equation Name 1]:</b><br>
[Equation in Unicode]
</p>

<p>
<b>[Equation Name 2]:</b><br>
[Equation in Unicode]
</p>

<!-- ========== Section 3: Key Contributions ========== -->
<p><b>— Key Contributions —</b></p>

<ul>
<li><b>[Contribution title]:</b> [1-2 sentence description]</li>
<li><b>[Contribution title]:</b> [1-2 sentence description]</li>
<li><b>[Contribution title]:</b> [1-2 sentence description]</li>
<li><b>[Contribution title]:</b> [1-2 sentence description]</li>
</ul>

<!-- ========== Section 4: シリーズ位置 ========== -->
<p><b>— Series Position —</b></p>

<p>
This [type] continues the [thread] programme established in
<a href="[continues[0] DOI URL]">Paper #X</a> and
<a href="[continues[1] DOI URL]">Paper #Y</a>,
and supplements
<a href="[supplements[0] DOI URL]">Paper #Z</a>.
[Optional 1-2 sentence elaboration]
</p>

<!-- ========== Section 5: 主要参照テーブル ========== -->
<p><b>— References (Hanamura papers) —</b></p>

<table>
<thead>
<tr><th>#</th><th>Title (abbreviated)</th><th>DOI</th></tr>
</thead>
<tbody>
<tr>
  <td>X</td>
  <td>[Abbreviated title]</td>
  <td><a href="[DOI URL]">10.5281/zenodo.NNNNNNNN</a></td>
</tr>
[... 全 references entries]
</tbody>
</table>

<!-- ========== Section 6: Series Context (固定文) ========== -->
<p><b>— Series Context —</b></p>

<p>
The 0-Sphere Model is an ongoing research programme (2018–present) that derives
spin, anomalous magnetic moment, Zitterbewegung, and emergent spacetime from the
geometry and thermodynamics of a two-kernel electron model.
All papers in the series are archived on Zenodo:
</p>

<p>
<a href="https://zenodo.org/search?q=metadata.creators.person_or_org.name%3A%22Hanamura%2C+Satoshi%22">Zenodo search: Hanamura, Satoshi</a>
</p>
```

## 4. Section-by-section workspace 駆動 auto-extract guidance

### 4.1 Section 1: 導入段落 (1-2 sentences)

**Source**: PDF abstract または `papers/0XX.md` body の `## Curatorial summary` section

**Guidance**:
- 1-2 sentences (concise, no padding)
- Paper の central thesis を natural language で要約
- 数式不使用 (Section 2 で Core Equations を提示するため)
- Reader 単独で paper の "what is this about?" を grasp できる

**Examples**:

#### #45 (Open-Path Spinorial Transport):

```html
<p>
This structural clarification note examines the question of whether the 0-Sphere
Model's geometric SU(2) structure logically requires Cartan torsion. We demonstrate
that the standard SU(2) holonomy framework — with non-Abelian curvature alone — is
fully sufficient to accommodate all observed structural features, recasting torsion
as an open conjecture rather than a logical necessity.
</p>
```

#### #57 (Spherical Harmonic Imprinting):

```html
<p>
This paper establishes the microscopic mechanism by which spherical harmonics
Y_ℓ^m are imprinted onto the photon-sphere ejection surface (θ = π/2) at the
moment of geometric escape, providing the foundational mechanism for the
gravitational coupling sequence #57-#61.
</p>
```

### 4.2 Section 2: Core Equations (2-4 equations)

**Source**: `papers/0XX.md` frontmatter `equations_first` 配列

**Guidance**:
- 2-4 central equations (paper の central thesis を最も articulate)
- Each equation:
  - `<b>[Equation Name]:</b>` で labelling
  - `<br>` 改行後に Unicode 表記
- Subscripts: `₀ ₁ ₂` Unicode characters
- Superscripts: Unicode (`⁰ ¹ ² ³ ⁴`) — `<sup>` 不可

**Auto-extract from frontmatter**:

```yaml
# papers/0XX.md
equations_first:
  - "K_int(A,B) = exp(i ω₀ L_int / v_ZB), two-layer kernel structure (Eq. II.2-II.3)"
  - "U_{A→B} · U_{B→A} = -1 ∈ SU(2), round-trip relation"
  - "[A_µ, A_ν] - ∂_µ A_ν + ∂_ν A_µ = -F_µν, gauge curvature (standard non-Abelian)"
```

→ HTML render:

```html
<p>
<b>Two-layer kernel structure:</b><br>
K_int(A,B) = exp(i ω₀ L_int / v_ZB)
</p>

<p>
<b>SU(2) round-trip relation:</b><br>
U_{A→B} · U_{B→A} = -1 ∈ SU(2)
</p>

<p>
<b>Gauge curvature (standard non-Abelian):</b><br>
[A_µ, A_ν] - ∂_µ A_ν + ∂_ν A_µ = -F_µν
</p>
```

#### Selection criteria (which 2-4 equations)

- Paper の central thesis を最も明示
- Reader が equation 単独で paper の core を grasp できる
- 過度に technical な derivation 中間式は避ける (final form を提示)

### 4.3 Section 3: Key Contributions (4-6 items)

**Source**: `papers/0XX.md` frontmatter `concepts_first` + `equations_first` + `analogies_first`

**Guidance**:
- 4-6 items (4 が default、複雑な paper では 6 まで)
- Each item:
  - `<b>[Contribution title]:</b>` (8-15 words label)
  - 1-2 sentence description (60-150 characters body)
- Selection priority: paper の central thesis を最も positive contribution する items

**Auto-extract from frontmatter**:

```yaml
# papers/0XX.md (例 #45)
concepts_first:
  - "**Three candidate mechanisms for torsion**: (i) Compton-scale-geometry-induced curvature dual..."
  - "**Spacetime-vs-internal-gauge dichotomy**: Sec VI.A での Phase functional ∆φ(A,B) two-reading..."
  - "**Holonomy-sufficiency thesis**: Sec V + VI の triple-articulation で torsion を logical necessity..."
  - "**Pedagogical-appendices-systematic-deployment**: App A (SU(2)/4π primer) + App B + App C..."

equations_first:
  - "Two-layer kernel structure (Eq. II.2-II.3)"

analogies_first:
  - {name: "phase-matching reinterpretation", note: "..."}
  - {name: "Wilson-vs-open-path", note: "..."}
```

→ HTML render (4 items selected):

```html
<ul>
<li><b>Three candidate mechanisms for torsion:</b> The paper enumerates and analyzes three logically distinct mechanisms (Compton-scale curvature, internal-gauge, hybrid) that could give rise to torsion, demonstrating that none is logically forced.</li>

<li><b>Spacetime-vs-internal-gauge dichotomy:</b> Sec VI.A clarifies that the phase functional ∆φ(A,B) admits two distinct interpretations — spacetime-curvature-mediated vs internal-gauge-mediated — with profoundly different empirical consequences.</li>

<li><b>Holonomy-sufficiency thesis:</b> The standard SU(2) holonomy framework, equipped with non-Abelian curvature alone, is shown to fully accommodate the observed 4π periodicity and ordered-path asymmetry, recasting torsion as an open conjecture.</li>

<li><b>Pedagogical-appendices systematic deployment:</b> Three substantial appendices (App A: SU(2)/4π primer; App B: connection/curvature/torsion primer with comparison table; App C: Wilson loops vs open-path) provide self-contained mathematical foundations for non-specialist readers.</li>
</ul>
```

#### Title formatting

- 8-15 words (title length sweet spot)
- Sentence-case capitalization (first word + proper nouns capitalized)
- Hyphenation acceptable (compound terms): "Spacetime-vs-internal-gauge dichotomy"
- 末尾 colon `:` (separator from description)

#### Description formatting

- 60-150 characters (1-2 sentences)
- Specific (not generic "establishes framework")
- Reader-grasp test: contribution 単体で reader が "what does this contribute?" を understand できる

### 4.4 Section 4: Series Position

**Source**: `papers/0XX.md` frontmatter `relation.continues` + `relation.supplements`

**Guidance**:
- 1 paragraph (3-5 sentences)
- continues + supplements の primary papers DOI links
- thread name の articulation (e.g., "open-path spinorial transport programme", "line-integral ontology")

**Auto-extract from frontmatter**:

```yaml
# papers/0XX.md
relation:
  continues: [29, 31, 40]
  supplements: [33, 35, 38, 40]
```

→ HTML render:

```html
<p>
This structural clarification note continues the open-path spinorial transport
programme established in
<a href="https://doi.org/10.5281/zenodo.<#29 DOI>">Paper #29</a> and the
line-integral ontology of
<a href="https://doi.org/10.5281/zenodo.<#31 DOI>">Paper #31</a>.
It supplements the geometric SU(2) framework of
<a href="https://doi.org/10.5281/zenodo.<#33 DOI>">Paper #33</a>,
the detailed exposition of
<a href="https://doi.org/10.5281/zenodo.<#35 DOI>">Paper #35</a>,
the two-kernel structure of
<a href="https://doi.org/10.5281/zenodo.<#38 DOI>">Paper #38</a>, and
the derivative-order-mismatch analysis of
<a href="https://doi.org/10.5281/zenodo.<#40 DOI>">Paper #40</a>.
</p>
```

#### Thread name articulation

- continues field の primary thread を identify (Skill A `references/threads-and-topics.md` 参照)
- thread name は paper-internal で使用される framing を respect (e.g., "open-path spinorial transport programme" not "thread C-29 Berry phase")

### 4.5 Section 5: 主要参照テーブル

**Source**: `papers/0XX.md` frontmatter `relation.references` (and optionally `relation.requires` if foundational)

**Guidance**:
- Table format (`<table>` with `<thead>` + `<tbody>`)
- Columns: Paper number / Abbreviated title / DOI link
- references 全 entries を listing (foundational papers は **bold** で highlight)

**Auto-extract from frontmatter**:

```yaml
# papers/0XX.md
relation:
  references: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41]
```

→ Each paper #N について `papers/0NN.md` frontmatter から:
- title (abbreviated to fit table column)
- doi
- is_foundational (foundational papers の bold marking)

→ HTML render:

```html
<table>
<thead>
<tr><th>#</th><th>Title (abbreviated)</th><th>DOI</th></tr>
</thead>
<tbody>
<tr>
  <td>10</td>
  <td>Redefining Electron Spin and AMM</td>
  <td><a href="https://doi.org/10.5281/zenodo.<#10 DOI>">10.5281/zenodo.<#10 DOI ID></a></td>
</tr>
<tr>
  <td>13</td>
  <td>Unified Spin Dynamics</td>
  <td><a href="https://doi.org/10.5281/zenodo.<#13 DOI>">10.5281/zenodo.<#13 DOI ID></a></td>
</tr>
<tr>
  <td>17</td>
  <td>From Clock Synchronization to Electromagnetism: U(1) Gauge</td>
  <td><a href="https://doi.org/10.5281/zenodo.<#17 DOI>">10.5281/zenodo.<#17 DOI ID></a></td>
</tr>
[... 各 reference entry]
<tr>
  <td><b>30</b></td>
  <td><b>From Curvature to Connection (foundational)</b></td>
  <td><a href="https://doi.org/10.5281/zenodo.<#30 DOI>">10.5281/zenodo.<#30 DOI ID></a></td>
</tr>
[...]
</tbody>
</table>
```

#### Title abbreviation guidance

Full titles を 30-50 characters に abbreviate:
- Subtitle 削除 (例: "From Curvature to Connection: A Reformulation of..." → "From Curvature to Connection")
- Long noun phrases truncate (例: "Spinorial Phase Accumulation along Thermal Geodesics in the 0-Sphere Model" → "Spinorial Phase Accumulation along Thermal Geodesics" → "Spinorial Phase Accum. along Thermal Geodesics")
- Series-foundational paper には "(foundational)" suffix

### 4.6 Section 6: Series Context (固定文)

**Source**: 固定 template (paper-independent)

**HTML**:

```html
<p><b>— Series Context —</b></p>

<p>
The 0-Sphere Model is an ongoing research programme (2018–present) that derives
spin, anomalous magnetic moment, Zitterbewegung, and emergent spacetime from the
geometry and thermodynamics of a two-kernel electron model.
All papers in the series are archived on Zenodo:
</p>

<p>
<a href="https://zenodo.org/search?q=metadata.creators.person_or_org.name%3A%22Hanamura%2C+Satoshi%22">Zenodo search: Hanamura, Satoshi</a>
</p>
```

固定 template の variation は **不要**。Future paper でも 同 template 使用。

### 4.7 必須 sections の順序

```
1. 導入段落
2. Core Equations
3. Key Contributions
4. Series Position
5. 主要参照テーブル
6. Series Context
```

順序固定 (paper-specific reordering 不可)。

### 4.8 任意 sections (paper-specific)

paper の central thesis に応じて以下を Section 2-3 の間または Section 4-5 の間に挿入:

#### Optional Section: "Open Questions" (#45 case)

```html
<p><b>— Open Questions —</b></p>

<ul>
<li><b>Directed-arc-length conjecture:</b> [description]</li>
<li><b>Cartan cancellation question:</b> [description]</li>
</ul>
```

`papers/0XX.md` frontmatter `opens_tasks` (status: open) から auto-extract。

#### Optional Section: "Methodological honesty" (#44, #45 case)

```html
<p><b>— Methodological Stance —</b></p>

<p>
[Methodological-honesty articulation paragraph from paper]
</p>
```

paper-internal の methodological-honesty section から抽出。

#### Optional Section: "Empirical Predictions" (#22, #28 case)

```html
<p><b>— Empirical Predictions —</b></p>

<ul>
<li><b>[Prediction]:</b> [status: unmeasured / partial / confirmed / etc.]</li>
</ul>
```

`papers/0XX.md` frontmatter `predictions` 配列から。

## 5. Series Context (Section 6) 固定 template 詳細

```html
<p>
The 0-Sphere Model is an ongoing research programme (2018–present) that derives
spin, anomalous magnetic moment, Zitterbewegung, and emergent spacetime from the
geometry and thermodynamics of a two-kernel electron model.
All papers in the series are archived on Zenodo:
</p>

<p>
<a href="https://zenodo.org/search?q=metadata.creators.person_or_org.name%3A%22Hanamura%2C+Satoshi%22">Zenodo search: Hanamura, Satoshi</a>
</p>
```

### 5.1 固定 template の rationale

- Series identity の uniform articulation (全 papers で同じ description)
- Reader が Hanamura corpus 全体を Zenodo 上で discoverable (search link)
- 「2018–present」 = ongoing research programme signal

### 5.2 Future evolution (任意)

将来的に series が milestone を迎えた場合 (例: 100 papers, 特定 unification milestone) には固定 template を update 候補。本 skill 第 1 版では preserve。

## 6. HTML タグ検証 (mandatory before output)

### 6.1 Python validator script

```python
from html.parser import HTMLParser

class ZenodoDescriptionValidator(HTMLParser):
    """Validate description HTML against Zenodo allowed tags."""
    
    ALLOWED_TAGS = {
        'a', 'abbr', 'acronym', 'b', 'blockquote', 'br', 'code', 'caption',
        'div', 'em', 'i', 'li', 'ol', 'p', 'pre', 'span', 'strike', 'strong',
        'sub', 'table', 'tbody', 'thead', 'th', 'td', 'tr', 'u', 'ul'
    }
    
    def __init__(self):
        super().__init__()
        self.errors = []
        self.line = 1
        
    def handle_starttag(self, tag, attrs):
        if tag not in self.ALLOWED_TAGS:
            self.errors.append(f"Disallowed tag <{tag}> at line {self.lineno}")
        # Check style/class/id attributes (will be stripped by Zenodo)
        for attr_name, attr_value in attrs:
            if attr_name in ('style', 'class', 'id'):
                self.errors.append(
                    f"Attribute '{attr_name}' on <{tag}> at line {self.lineno} "
                    f"will be stripped by Zenodo"
                )
    
    def validate(self, html_content):
        self.feed(html_content)
        if self.errors:
            print(f"VALIDATION FAILED: {len(self.errors)} errors")
            for err in self.errors:
                print(f"  {err}")
            return False
        else:
            print("VALIDATION OK: All tags within Zenodo allowlist")
            return True


# Usage:
with open('zenodo_description.html') as f:
    html_content = f.read()

validator = ZenodoDescriptionValidator()
validator.validate(html_content)
```

### 6.2 Validator execution (Step 3.5 mandatory)

```bash
python3 description_validator.py
```

Expected output (all-clear):

```
VALIDATION OK: All tags within Zenodo allowlist
```

エラー発生時は HTML を修正、validator 0-error まで iterate。

### 6.3 Common errors and fixes

#### Error 1: `<sup>` usage

```
Disallowed tag <sup> at line N
```

**Fix**: Unicode superscript characters (`⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹`) または `<sub>` 代替使用。

```html
❌ Before:
   E = mc<sup>2</sup>

✅ After:
   E = mc²
```

#### Error 2: `style` attribute

```
Attribute 'style' on <p> at line N will be stripped by Zenodo
```

**Fix**: `style` attribute を削除。CSS による styling 不可。

```html
❌ Before:
   <p style="color: red;">Important note</p>

✅ After:
   <p><b>Important note</b></p>
```

#### Error 3: `<img>` usage

```
Disallowed tag <img> at line N
```

**Fix**: Image を Description 内に直接 embed 不可。Zenodo archive 内 file として upload + 本文内 reference のみ。

#### Error 4: `<h1>`-`<h6>` usage

```
Disallowed tag <h2> at line N
```

**Fix**: `<p><b>...</b></p>` で見出し代用。

```html
❌ Before:
   <h2>Key Contributions</h2>

✅ After:
   <p><b>— Key Contributions —</b></p>
```

## 7. Workspace integration patterns (NEW section)

### 7.1 Auto-extract workflow summary

```
papers/0XX.md frontmatter:
  ├── title         → (used in Section 5 main reference)
  ├── doi           → (not used in Description, used in readme.txt + relations.txt)
  ├── relation.continues → Section 4 Series Position primary papers
  ├── relation.supplements → Section 4 Series Position supplemented papers
  ├── relation.references → Section 5 主要参照テーブル
  ├── concepts_first    → Section 3 Key Contributions
  ├── equations_first   → Section 2 Core Equations + Section 3 Key Contributions (一部)
  ├── analogies_first   → Section 3 Key Contributions (一部, namely 'analogical articulations')
  └── opens_tasks (status: open) → Optional Section "Open Questions"

PDF (paper):
  ├── Abstract       → Section 1 導入段落 (1-2 sentences 要約)
  └── Methodological-honesty section (if exists) → Optional Section "Methodological Stance"
```

### 7.2 Manual curation requirements

以下は manual curation 必要 (workspace 駆動 auto-extract が困難):

- Section 1 導入段落 (1-2 sentences の要約は judgment 必要)
- Section 2 Core Equations の選択 (どの 2-4 equations を select するか judgment)
- Section 3 Key Contributions の selection (どの 4-6 items を select するか judgment)
- Section 4 Series Position の thread name articulation (paper-internal framing respect)
- Section 5 主要参照テーブル の title abbreviation (30-50 chars 内 fit する short forms)
- Optional sections の inclusion judgment (paper-specific)

### 7.3 Workspace ↔ Description bidirectional consistency

Description HTML 生成後、Workspace との bidirectional consistency check:

- Description Section 4 Series Position で言及される papers が `papers/0XX.md` frontmatter relation field と一致
- Description Section 3 Key Contributions が `papers/0XX.md` frontmatter `concepts_first` / `equations_first` / `analogies_first` items の subset
- Description Section 5 主要参照テーブル の paper numbers が `relation.references` 配列と一致

不一致発見時は **workspace 側を source of truth** として Description を update (workspace ↔ Description の uni-directional update flow、workspace 駆動 mode 維持)。

## 8. 出力 file naming + placement

```
/mnt/user-data/outputs/zenodo_description_<paper-number>.html
```

例:
- `/mnt/user-data/outputs/zenodo_description_45.html`
- `/mnt/user-data/outputs/zenodo_description_57.html`

UTF-8 / 行幅自由 (HTML readability 優先) / `<sup>` 不可 / `style` / `class` / `id` 属性なし。

## 9. References

- `references/workflow.md` Step 3.5: zenodo_description.html generation workflow position
- `references/relations-strategy.md`: Section 4 Series Position の continues / supplements 言及 (本 file Section 4 と consistent)
- `references/relation-types.md`: Section 5 主要参照テーブル の references field 解釈 (本 file Section 4.5 と consistent)
- Skill A `references/frontmatter-schema.md`: Workspace `papers/0XX.md` frontmatter schema (concepts_first / equations_first / analogies_first source-of-truth)
- Skill A `references/curatorial-disciplines.md`: Section 6 AI-collaboration acknowledgment lineage (Description には include しない、readme.txt + paper-internal で扱う)
