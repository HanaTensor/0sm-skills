# Relations Strategy (heavily revised, workspace-driven primary mode)

> Skill B の relations 戦略 reference。Original `relations-strategy.md` (HanaTensor/0sm-skills repository) の content を **heavily revised**: workspace 駆動 auto-generation を **primary mode** に articulate、manual探索 (LLM crawling 等) を **fallback mode** に position。Author の curate 済 corpus が前提の operational efficiency 最大化。

---

## 1. 戦略の核心 (revised)

### 1.1 旧 strategy (LLM crawling 中心)

Original `relations-strategy.md` の戦略 articulation は:

> 「論文と論文の関係性は、author の手動入力に依存せず、LLM が論文全文の意味的な内容を解析することで判断する」

これは workspace が存在しない (または curate 不十分) な状況で前提とされた。LLM crawling は意味解析を毎回やり直す高コスト process。

### 1.2 新 strategy (workspace-driven primary mode)

**本 skill の前提**: paper は **`0sm-corpus-curate` skill で curate 済み** = `papers/0XX.md` frontmatter で relations が **既 explicit articulated**。

新戦略:

> 「workspace 駆動 auto-generation を primary mode、manual探索 (LLM crawling) を fallback mode とする」

```
Primary mode (workspace 駆動):
  papers/0XX.md frontmatter
    ├── relation.supplements
    ├── relation.continues
    ├── relation.requires
    └── relation.references
         ↓ direct mapping (確定 deterministic)
  zenodo_relations.txt sections [2]/[3]/[4]/[5]
                        + rationale comments from frontmatter
                        + Multi-Relation Assignments
                        + Reverse Relations (auto-derived)

Fallback mode (manual探索):
  papers/0XX.md が未 curate / partial curate の場合のみ
   → Section 5 「Manual探索フローチャート」 に従う
```

Workspace 駆動 mode は:
- 80%+ of relations content が deterministic auto-generation 可能
- Manual additions: bibitem rationale 各 entry の prose content + multi-relation 正当化 + 特殊 case (forward references 等) + non-Hanamura standard refs note
- Curatorial signal の **single source of truth** が `papers/0XX.md` frontmatter であることを保証

## 2. zenodo_relations.txt 構造 (revised, 6 sections)

### 2.1 標準 6 sections + 拡張 sections

```
[Summary]                              ← 各 section の counts + multi-relation count + reverse-relation paper count
[1] Cites                              ← 全 bibitem cite 統合
[2] Is supplement to                   ← supplements 配列から
[3] Continues                          ← continues 配列から
[4] References                         ← references 配列から
[5] Requires                           ← requires 配列から
[6] Is part of                         ← derivation rule (immediate predecessor or sequence-foundational)

[Multi-Relation Assignments]           ← 同 paper が 2+ relation types に登場する case
[Reverse Relations -- Recommended Updates to Target Papers]
                                       ← 各 forward relation の reverse 推奨を auto-derive
```

### 2.2 Section ordering

`[Summary]` → `[1]` → `[2]` → `[3]` → `[4]` → `[5]` → `[6]` → `[Multi-Relation Assignments]` → `[Reverse Relations]`。

各 section の前後に空行 + `==============================================================================` 78 文字 separator。

### 2.3 文字エンコーディング + 行幅

UTF-8、行幅 80-100 文字程度。section boundary は明示的 (separator 78 文字)、subsection (`[1.X]` 等) は不要。

## 3. Workspace 駆動 auto-generation 規約 (primary mode 詳細)

### 3.1 papers/0XX.md frontmatter からの mapping

```yaml
# In papers/0XX.md:
relation:
  supplements: [33, 35, 38, 40]   # → zenodo_relations [2] Is supplement to
  continues: [29, 31, 40]         # → zenodo_relations [3] Continues
  requires: [29, 31, 33, 35, 38, 40]   # → zenodo_relations [5] Requires
  references: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41]   # → zenodo_relations [4] References
```

### 3.2 [Summary] section auto-generation

```python
# Pseudo-code
fm = read_paper_frontmatter('papers/0XX.md')
all_cites = set()
for field in ['supplements', 'continues', 'requires', 'references']:
    if fm['relation'].get(field):
        all_cites.update(fm['relation'][field])

# Multi-relation: papers が 2+ relation fields に登場
multi_relation_count = count_papers_in_multiple_relations(fm)

# Reverse relations: 各 target paper が 1+ reverse relations 推奨される
reverse_relation_papers = set()
for field in ['supplements', 'continues', 'requires', 'references']:
    if fm['relation'].get(field):
        reverse_relation_papers.update(fm['relation'][field])

print(f"""
[Summary]
  Cites              : {len(all_cites)} entries (Hanamura papers + non-Hanamura standard refs)
  Is supplement to   : {len(fm['relation']['supplements'] or [])} entries
  Continues          : {len(fm['relation']['continues'] or [])} entries
  References         : {len(fm['relation']['references'] or [])} entries
  Requires           : {len(fm['relation']['requires'] or [])} entries
  Is part of         : 1 entry
  
  Multi-relation DOIs: {multi_relation_count}
  Reverse-relation papers: {len(reverse_relation_papers)}
""")
```

### 3.3 [1] Cites section auto-generation

#### 3.3.1 Hanamura papers (workspace 由来)

```
[1] Cites

The following Hanamura papers are formally cited in the bibliography of this work:

1. DOI: <DOI of paper #X1>
   Paper #X1 — <title from papers/0X1.md>
   <date from papers/0X1.md> | <type/subtype>
   Role: <auto-derived from which relation field(s) include #X1>
   - Is supplement to (Section 2)        [if #X1 in supplements]
   - Continues (Section 3)               [if #X1 in continues]
   - Requires (Section 5)                [if #X1 in requires]
   - References (Section 4)              [if #X1 in references AND not above]

2. DOI: <DOI of paper #X2>
   ...
```

`Role:` line は **multi-relation visualization** として機能。同 paper が 2+ relation fields にあれば role line に複数 entries。

#### 3.3.2 Non-Hanamura standard refs

```
The bibliography also contains the following non-Zenodo standard references:

  - <ref author> et al., <year>, <publication> [if applicable]
  - <textbook author>, <year>, <book title> [if applicable]
  - ...

These references are not Zenodo records and therefore are not enumerated as
[1] Cites Zenodo entries; they appear in the bibliography for academic context only.
```

例 (#45 case):
- Nakahara, M., 2003, "Geometry, Topology and Physics" (textbook)
- Misner, Thorne, Wheeler, 1973, "Gravitation" (textbook)
- Hehl, F.W. et al., 1976, "General relativity with spin and torsion: Foundations and prospects" (Reviews of Modern Physics)

#### 3.3.3 [1] Cites section の closing note

```
Total Zenodo (Hanamura) cites: <N>
Total non-Zenodo refs: <M>
```

### 3.4 [2] Is supplement to section auto-generation

`papers/0XX.md` frontmatter `relation.supplements` 配列から:

```
[2] Is supplement to

This paper's <subtitle context derived from frontmatter title> signals
that it supplements the geometric / structural / etc. results established
in the following <N> papers:

1. DOI: <papers/0X1.md doi>
   Paper #X1 — <papers/0X1.md title>
   <papers/0X1.md date>
   
   Reason: <rationale paragraph from papers/0XX.md frontmatter relation.supplements
            comment, OR auto-derived from #XX abstract + #X1 abstract intersection>

2. DOI: <papers/0X2.md doi>
   ...
```

#### Rationale auto-extract

frontmatter の supplements field comment から:

```yaml
relation:
  supplements: [33, 35, 38, 40]   # 4 papers への explicit supplement (zenodo_relations [2]):
                                    # (1) #33 Geometrical Confinement establishes geometric SU(2) framework, ...
                                    # (2) #35 Detailed Exposition unfolds geometric structure, ...
                                    # (3) #38 Two-Kernel SU(2) Structure provides 2-kernel formal articulation, ...
                                    # (4) #40 Derivative-Order-Mismatch ...
```

→ 各 entry の rationale paragraph を auto-extract、each as 2-3 sentence prose。

#### Multi-relation case

#40 が `supplements + continues` 双方にある case (#45 v7.25 dual-relation precedent):

```
4. DOI: 10.5281/zenodo.18736670
   Paper #40 — Derivative-Order-Mismatch...
   2026-02-23
   
   Reason: Paper #40 establishes the derivative-order-mismatch as a
   structural feature of the 0-Sphere Model. This work continues that
   programme (see [3] Continues) AND supplements it with a torsion-status
   analysis (this entry). The dual-relation captures both functional roles:
   thematic-extension (supplement) and sequential-continuation (continue).
   
   See [Multi-Relation Assignments] section for cross-reference.
```

#### supplements: null case

```
[2] Is supplement to

None applicable.

This paper is a stand-alone <type> as declared in its title and abstract.
It does not supplement any prior paper in the explicit zenodo_relations
sense. (Note: Section 4 References lists papers cited for thematic context.)
```

### 3.5 [3] Continues section auto-generation

`relation.continues` 配列から同様の structure。Triple-continuation case (#45 三重 continuation 第 1 instance v7.25 precedent):

```
[3] Continues

Paper #45 represents a continuation of three distinct programme threads:
- Open-path spinorial transport (Paper #29)
- Line-integral ontology (Paper #31)
- Derivative-order-mismatch analysis (Paper #40)

This is the first instance of triple-continuation in the series, reflecting
the paper's role as a structural clarification note that synthesizes
multiple existing programme threads.

1. DOI: <#29 DOI>
   Paper #29 — Trilogy I: Spinorial Phase Accumulation along Thermal Geodesics
   <date>
   
   Reason: <rationale paragraph from frontmatter continues comment>

2. DOI: <#31 DOI>
   ...

3. DOI: <#40 DOI>
   Paper #40 — Derivative-Order-Mismatch ...
   <date>
   
   Reason: ... (See also [2] Is supplement to entry for #40 — dual-relation)
```

### 3.6 [4] References section auto-generation

`relation.references` 配列から:

```
[4] References

The following papers are cited in the bibliography for thematic context
or as background; they are not declared as supplements / continuations /
requirements per [2]/[3]/[5]:

1. DOI: <ref paper DOI>
   Paper #N — <title>
   <date>
   
   Note: <auto-derived role description from bibitem cite context>

2. ...
```

#### Foundational papers indication

`is_foundational: true` の references は special highlighting:

```
3. DOI: <#1 DOI>
   Paper #1 — Two Perfect Black Bodies, Information Loss, and the Generalized
              Second Law: A Unified Framework for Mass-Energy Equivalence
   2018
   
   Foundational paper of the 0-Sphere Model series.
   
   Note: Cited as foundational reference for E_0 Hamiltonian + photon-sphere
         identity, providing the energy formula context for this paper's
         spinorial transport analysis.
```

#### Forward references (#57 → #58/#59/#60 v7.26 NEW pattern (b))

```
8. DOI: <#58 DOI>
   Paper #58 — Spin-2 Structure ... [forward reference, future paper]
   <date if known, else "anticipated">
   
   Note: FORWARD REFERENCE — companion paper of the #57-#61 sequence
         (5-paper-coordinated-release foundational-mechanism). Supplies
         deferred items: <specific deferred topics from #57 frontmatter>.
```

Forward reference 数が 3+ の場合、subsection で grouping:

```
[4] References (continued — Forward references)

The following <N> forward references constitute the companion-paper sequence
of #57-#61, where #57 (this paper) is the foundational-mechanism paper and
#58-#60 supply deferred analyses:

  - #58 (anticipated): Spin-2 structure of π-period rotation
  - #59 (anticipated): Bound-state condition
  - #60 (anticipated): Berry-Synge-Bonnet-Myers triangle

This is the first instance of forward-companion-bibliographic-reference
pattern in the series (HANDOFF v7.26 NEW pattern).
```

### 3.7 [5] Requires section auto-generation

`relation.requires` 配列から:

```
[5] Requires

The following <N> papers are logical prerequisites for this paper. Reading
them prior to engaging with this work is recommended for full understanding
of the framework.

1. DOI: <#X1 DOI>
   Paper #X1 — <title>
   <date>
   
   Required for: <specific framework / equation / concept that #X1 establishes
                  and this paper presupposes>

2. ...
```

#### Broad-prerequisite-base character

`requires` 配列が 6+ entries の case (例: #45 で 6 papers, #57 で 8 papers max):

```
Note (Broad prerequisite base):

This paper has a broader prerequisite base than typical, reflecting its
character as a structural clarification note that synthesizes multiple
established frameworks. The <N> required papers span the geometric SU(2)
framework, line-integral ontology, derivative-order-mismatch analysis,
and two-kernel structure.

For new readers: We recommend reading them in numerical order
(<paper number list, sorted ascending>) as their content builds
incrementally on prior establishments.
```

### 3.8 [6] Is part of section auto-generation

**Workspace schema gap** (HANDOFF v7.26 NEW pattern (d) — workspace 内に `is_part_of` field 直接なし) のため derivation rule:

```
[6] Is part of

DOI: <derivation result DOI>

Derivation rule:
  Default: Paper #1 (founding paper, シリーズ membership signal)
  Special case: Sequence-foundational paper → immediate predecessor in sequence

This paper's "is part of" target is derived as <#X — title>, where:
- For series-membership signal: Paper #1 establishes the 0-Sphere Model series
- For sequence-foundational papers (e.g., #57 in the #57-#61 sequence):
  immediate predecessor in numerical order
```

#### Derivation examples

| Paper | Is part of derivation | Rationale |
|---|---|---|
| #45 | #1 | Default series-membership signal (no specific sequence) |
| #57 | #56 | Sequence-foundational paper, immediate predecessor (#56 is the immediate prior paper that establishes the framework boundary) |
| Future papers in #57-#61 sequence | #57 | All defer to #57 as foundational mechanism paper |

#### Quadruple-relation case (#56 in #57, v7.26 precedent)

```
[6] Is part of

DOI: 10.5281/zenodo.<#56 DOI>
Paper #56 — Framework Boundary
<date>

Note: This is a quadruple-relation single-target case (HANDOFF v7.26 NEW pattern):
      Paper #56 appears in:
        - [1] Cites (general bibitem citation)
        - [3] Continues (sequential continuation)
        - [5] Requires (logical prerequisite)
        - [6] Is part of (sequence membership)
      
      See [Multi-Relation Assignments] section for cross-reference.
```

### 3.9 [Multi-Relation Assignments] section auto-generation

frontmatter で同 paper が複数 relation fields に登場する case を enumerate:

```python
# Pseudo-code
multi_relation_papers = {}
for field in ['supplements', 'continues', 'requires', 'references']:
    if fm['relation'].get(field):
        for paper_num in fm['relation'][field]:
            if paper_num not in multi_relation_papers:
                multi_relation_papers[paper_num] = []
            multi_relation_papers[paper_num].append(field)

# Filter to 2+
multi_relation_papers = {k: v for k, v in multi_relation_papers.items() if len(v) >= 2}
```

```
[Multi-Relation Assignments]

The following <N> Hanamura papers appear in multiple relation types
(same DOI, multiple categories). Each multi-relation declaration is
intentional, reflecting the distinct semantic roles each relation field
captures (HANDOFF v7.25 / v7.26 multi-relation discipline).

#X1 (DOI <doi>): <field1> + <field2> [+ <field3> ...]
  Roles:
    - <field1>: <semantic role description>
    - <field2>: <semantic role description>
    [...]

#X2 (DOI <doi>): <field1> + <field2>
  Roles:
    - ...
```

#### Examples

(#45 case, v7.25 dual-relation 第 1 instance):

```
#40 (DOI 10.5281/zenodo.18736670):
  Is supplement to + Continues + Requires
  
  Roles:
    - Is supplement to: This paper supplements #40's derivative-order-mismatch
                        analysis with a torsion-status clarification (thematic
                        extension role)
    - Continues:        This paper continues the derivative-order-mismatch
                        programme thread (sequential continuation role)
    - Requires:         #40's framework is a logical prerequisite for this
                        paper's analysis (logical-prerequisite role)
```

(#57 case, v7.26 quadruple-relation 第 1 instance):

```
#56 (DOI <#56 DOI>):
  Cites + Continues + Is part of + Requires
  
  Roles:
    - Cites:           Standard bibitem citation (subsumes Continues + Is part of + Requires per workspace discipline)
    - Continues:       Sequential continuation of framework-boundary thread
    - Is part of:      Sequence membership (#57 is part of #56-anchored framework)
    - Requires:        Logical prerequisite for understanding microscopic mechanism
```

### 3.10 [Reverse Relations -- Recommended Updates to Target Papers] section auto-generation

各 forward relation の reverse 推奨を auto-derive:

```python
# Pseudo-code
reverse_relations = {}
forward_to_reverse = {
    'supplements': 'Is supplemented by',
    'continues': 'Is continued by',
    'requires': 'Is required by',
    'references': 'Is referenced by',
    'is_part_of': 'Has part',
}

for field, reverse_label in forward_to_reverse.items():
    if fm['relation'].get(field):
        for paper_num in fm['relation'][field]:
            if paper_num not in reverse_relations:
                reverse_relations[paper_num] = []
            reverse_relations[paper_num].append(reverse_label)
```

```
[Reverse Relations -- Recommended Updates to Target Papers]

The following reverse relations should be added to the Zenodo records of
the listed papers, pointing back to <本論文 DOI> (Paper #<XX> -- <本論文 title>).

These updates are Zenodo Web UI 手作業範囲, not part of this skill's
deliverable file output.

------------------------------------------------------------
Recommended updates (<N> papers):

#X1 (Paper "<title>", DOI <DOI>):
  Add: Is supplemented by | <本論文 DOI>
  
#X2 (Paper "<title>", DOI <DOI>):
  Add: Is continued by | <本論文 DOI>
       Is required by  | <本論文 DOI>
  
#X3 ...

------------------------------------------------------------
Forward-companion reverse relations (anticipated, after #YY upload):

#YY (Paper "<title>", anticipated DOI):
  Add (after upload): Continues | <本論文 DOI>

------------------------------------------------------------
```

### 3.11 [Multi-Relation 正当化] note (各 multi-relation case)

各 multi-relation entry に正当化 note を **explicit articulate**:

```
Multi-relation rationale (HANDOFF v7.25 dual-relation / v7.26 quadruple-relation
discipline):

Multiple-relation declarations for a single target paper are supported as
distinct semantic roles:

  - "Is supplement to": thematic-extension role (this paper extends the
                        target's analysis)
  - "Continues":        sequential-continuation role (this paper articulates
                        the next question after the target)
  - "Requires":         logical-prerequisite role (this paper presupposes
                        the target's framework)
  - "References":       bibitem citation (this paper cites the target in
                        bibliography, but not as supplement/continue/require)
  - "Is part of":       sequence-membership role (this paper is in a
                        coordinated-release sequence with the target as
                        anchor)

These roles are independent and information-loss-free. The same target paper
can be declared in 2+ relations without contradiction.
```

## 4. Bibitem rationale 各 entry の prose content (manual curation requirement)

Workspace 駆動 auto-generation は以下を auto-fill するが、**manual prose curation** が必要な部分:

### 4.1 Auto-derivable items

- Paper number / title / date / DOI (from `papers/0YY.md` frontmatter)
- Relation field membership (supplements / continues / requires / references)
- Multi-relation enumeration
- Reverse relations recommendations

### 4.2 Manual prose curation requirements

各 entry の rationale paragraph (2-3 sentences):
- Why this specific paper appears in this relation field
- What specific framework / equation / concept it provides
- How this paper extends / continues / presupposes that

これらは frontmatter `relation.<field>` の comment block から auto-extract 可能 (`papers/0XX.md` curate 時 articulate されている)。Comment が absent な場合は manual draft 必要。

### 4.3 Manual prose curation guidance

Each entry rationale should be:
- 2-3 sentences (concise, no padding)
- Specific (not generic "establishes framework")
- Workspace-internal-consistent (rationale matches `papers/0XX.md` analysis)

例:

❌ Generic:
> "Paper #33 establishes a related framework that this paper builds upon."

✅ Specific:
> "Paper #33 establishes the geometric SU(2) framework with the hemispheric
> transport law, providing the foundational geometric structure that this paper's
> Sec III open-path framework operates within. The torsion-status analysis in
> Sec V directly addresses the residual question raised in #33's framework."

## 5. Manual探索 fallback mode (paper が未 curate / partial curate の場合のみ)

**条件**: `papers/0XX.md` が未 curate / partial curate の場合のみ本 fallback mode を使用。Workspace 駆動 mode が default。

### 5.1 Fallback mode 適用 trigger

- `ls context/papers/0XX.md` が file not found
- `papers/0XX.md` の `relation:` field が `null` のみ / partially populated
- User explicit "manual探索 mode で進めて" 指示

### 5.2 Fallback mode workflow (original strategy preserved)

#### Step F1: Paper の核心命題 + 立場を 1 文で要約

```
例: 「光子球軌道の閉軌道として粒子的世界線を記述するモデル」
```

#### Step F2: bibitem rationale を 1 件ずつ作成 (manual prose draft)

各引用文献 (Hanamura papers) について、本論文との関係を 1 文で記述。

#### Step F3: relation 自動分類フローチャート (manual)

```
論文 P_i は本論文 P の引用文献である
↓
P_i の論文全体は、本論文 P の主張・前提・概念 (フレームワーク全体) と論理的にどの程度近接しているか?
├── 「同じ命題群を共有する supplement / structural extension」 と LLM が判断
│         → Is supplement to (#36, #38, #39, #41, #42 で初確認, 多くの supplement papers が該当)
├── 「概念 / 系統 / 流れを継ぐ続編 (sequential continuation)」 と LLM が判断
│         → Continues (#34, #41 で使用, sequential 系統論文が該当)
├── 「結果 / 形式 / 概念体系を **論理的前提** として **必須に依存している**」 と LLM が判断
│         → Requires
└── 「結果や形式を引用するが論理的依存はない」 と LLM が判断
          → References
```

#### Step F4: Multi-relation / Reverse Relations を最終追記

#### Step F5: workspace integration suggestion

Fallback mode で生成した relations を `papers/0XX.md` frontmatter に back-port + workspace を更新する suggestion を User に提示 (Skill A invocation で正式 curate)。

### 5.3 Fallback mode の limitation

Fallback mode は:
- Per-invocation で同じ analysis を yarinaosu (= compute cost 累積)
- LLM 解析の non-determinism (毎回 result 微異)
- Workspace との bidirectional consistency なし

→ **paper を curate (Skill A invocation) して workspace 駆動 mode に移行することを推奨**。

## 6. 整形 + 文字エンコーディング ルール

### 6.1 整形 ルール

- 1 件ごとに `1.` `2.` で番号付け (subsection within `[1]`-`[5]` Cites/Supplement/Continues/References/Requires)
- DOI は単独行で記載 (`DOI: 10.5281/...`)
- Reason / Note は 1-3 文以内、可能なら 1 文
- 末尾に 1 行空行

### 6.2 文字エンコーディング

UTF-8。ただし relations.txt は Zenodo Web UI への copy-paste も想定するため:
- 日本語使用は最小限
- 数式 / 物理量は ASCII 表現 (e.g., `g-2`, `mu_B`, `v_ZB ~ 0.04c`)
- 特殊記号 (≈, ≠, →) は ASCII 代替推奨 (`~`, `!=`, `-->`)

### 6.3 Section separator

```
[Section name]

(content)

==============================================================================

[Next section]
```

`=` 78 文字 separator + 前後空行。

## 7. Workspace 駆動 vs Manual 比較

| Aspect | Workspace 駆動 (primary) | Manual探索 (fallback) |
|---|---|---|
| Prerequisite | papers/0XX.md curate 済み | None |
| Time cost | Low (auto-generate from frontmatter) | High (LLM crawling + manual analysis) |
| Determinism | Deterministic (workspace = single truth) | Non-deterministic (LLM analysis varies) |
| Bidirectional consistency | Yes (workspace ↔ relations.txt) | No (output 単方向) |
| Multi-relation handling | Native (frontmatter で encoded) | Manual articulation required |
| Forward references | Native (frontmatter で encoded with notes) | Difficult (forward DOI が yet-未公開) |
| Maintenance | Update workspace → re-generate | Re-analyze each invocation |

**結論**: paper が curate 済みであれば **必ず workspace 駆動 mode を使用**。

## 8. References

- `references/workflow.md` Step 3: zenodo_relations.txt generation workflow position
- `references/relation-types.md`: Zenodo 33 relation types reference (本 file [1]-[6] section の sub-types)
- `references/readme-template.md` Section 3.5: readme.txt RELATION TO PREVIOUS WORK section auto-extract (本 file workspace 駆動 mode と consistent)
- Skill A `references/frontmatter-schema.md`: workspace `papers/0XX.md` frontmatter relation field schema
- Skill A `references/curatorial-disciplines.md` Section 4: Multi-relation declarations discipline (v7.25 / v7.26 precedent)
