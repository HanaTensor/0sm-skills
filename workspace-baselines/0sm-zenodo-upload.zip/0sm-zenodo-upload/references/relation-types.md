# Zenodo Relation Types Reference (with workspace mapping)

> Skill B の Zenodo 33 relation types 完全 reference + workspace mapping section。Original `relation-types.md` (HanaTensor/0sm-skills repository) の content を preserve、workspace mapping section を追加して `papers/0XX.md` frontmatter との対応を明示。

---

## 1. Zenodo Relation Types 一覧

Zenodo の Related identifiers field で選択可能な relation types。0SM workspace で使用される relation types (★) と参考用 (○) を区別:

### 1.1 Core relations (本 corpus で頻用)

| Zenodo relation type | 本 skill での扱い | Workspace mapping |
|---|---|---|
| **Cites** ★ | [1] Cites | 全 bibitem (supplements ∪ continues ∪ requires ∪ references) |
| **Is supplement to** ★ | [2] Is supplement to | `relation.supplements` |
| **Continues** ★ | [3] Continues | `relation.continues` |
| **References** ★ | [4] References | `relation.references` |
| **Requires** ★ | [5] Requires | `relation.requires` |
| **Is part of** ★ | [6] Is part of | (workspace schema gap, derivation rule per `relations-strategy.md`) |

### 1.2 Reverse relations (本 corpus で reverse-update 推奨)

| Forward relation | Reverse relation | Reverse update target |
|---|---|---|
| Cites | Is cited by | (uncommon for reverse update) |
| Is supplement to | Is supplemented by | target paper |
| Continues | Is continued by | target paper |
| References | Is referenced by | (less common) |
| Requires | Is required by | target paper |
| Is part of | Has part | target paper |

### 1.3 Other relation types (本 corpus 未使用、参考)

| Zenodo relation type | Description | 0SM corpus 適用例 |
|---|---|---|
| Is new version of ○ | Same content, revised version | DOI v1 → v2 case (#30 v7.21 precedent, ただし workspace 内では canonical DOI 統一済) |
| Is previous version of ○ | Reverse of "Is new version of" | Reverse of above |
| Is derived from ○ | Derived/transformed work | Not used in 0SM |
| Is source of ○ | Reverse of "Is derived from" | Not used in 0SM |
| Is identical to ○ | Same item, multiple identifiers | Not used in 0SM |
| Is variant form of ○ | Variant version (e.g., translation) | Not used in 0SM |
| Is original form of ○ | Reverse of "Is variant form of" | Not used in 0SM |
| Is documented by ○ | Documented elsewhere | Not used in 0SM |
| Documents ○ | Reverse of "Is documented by" | Not used in 0SM |
| Is compiled by ○ | Compiled from sources | Not used in 0SM |
| Compiles ○ | Reverse of "Is compiled by" | Not used in 0SM |
| Is published in ○ | Published in journal/proc | Not used in 0SM (Zenodo native) |
| Has version ○ | Has versions (DOI versioning) | (Zenodo auto-handles) |
| Is version of ○ | Is version of (Zenodo versioning) | (Zenodo auto-handles) |
| Reviews ○ | Reviews/critiques | Not used in 0SM |
| Is reviewed by ○ | Reverse of "Reviews" | Not used in 0SM |
| Obsoletes ○ | Renders obsolete | Not used in 0SM |
| Is obsoleted by ○ | Reverse of "Obsoletes" | Not used in 0SM |
| Describes ○ | Describes another resource | Not used in 0SM |
| Is described by ○ | Reverse of "Describes" | Not used in 0SM |

## 2. Detailed semantic distinction (Core relations)

### 2.1 Cites

**Definition (Zenodo)**: The cited resource is referenced in the citing resource's bibliography.

**Workspace usage**:
- 全 bibitem cite の **statistical aggregation** として function
- supplements + continues + requires + references の和集合
- non-Hanamura standard refs (textbooks, journal papers) は別途 note paragraph で言及 (Zenodo records ではないため [1] Cites bullet items には含めない)

**Multi-relation rationale**: Cites は **subsuming relation** = supplements / continues / requires / references いずれかに登場する Hanamura paper は必ず Cites にも登場 (重複 declaration、information loss なし)。

**例**:
```
[1] Cites
1. <DOI of #29> — Trilogy I  (Continues + Requires + Is part of も同 paper を declare)
2. <DOI of #31> — Trilogy III  (Continues + Requires も同 paper を declare)
3. <DOI of #33> — Geometrical Confinement  (Is supplement to + Requires も同 paper を declare)
...
```

### 2.2 Is supplement to

**Definition (Zenodo)**: A supplement adds to or extends another work (typically not the primary publication).

**Workspace usage**:
- paper が **既存 paper の analysis を thematic に extend** する場合
- typical signal: subtitle に "A Supplement on X", "Supplementary Note on Y" 等
- abstract / intro section で explicit「supplement」 framing

**Multi-relation cases**:
- supplement + continue dual-relation (#40 in #45 v7.25 precedent): paper が target を **thematic extension** + **sequential continuation** 双方の roles で位置づけ

**Reverse update**: target paper の Zenodo record で「Is supplemented by」 を Web UI で追加 (本 skill recommended-update list に含まれる)。

### 2.3 Continues

**Definition (Zenodo)**: The cited resource is continued by the citing resource (e.g., Volume 2 continues Volume 1).

**Workspace usage**:
- paper が **既存 paper の next-question を articulate** する場合
- thread continuation (e.g., Trilogy I → II → III pattern, #29-#31 sequential continuation)
- typical signal: paper-internal で「extends the programme of」「following [paper #X], we now」 framing

**Triple-continuation case (#45 v7.25 precedent)**:
- paper #45 は #29 (open-path), #31 (line-integral), #40 (derivative-order-mismatch) 三 threads を simultaneously continue
- HANDOFF v7.25 第 1 instance triple-continuation pattern

**Multi-paper continuation pattern note**:
- 通常 single-paper continuation (Volume 2 continues Volume 1) だが、0SM corpus では multi-paper thread synthesis case で multiple-target continuation がある
- Zenodo は relation entries 複数登録対応のため、すべてを Continues に登録可能

**Reverse update**: target paper の Zenodo record で「Is continued by」 を Web UI で追加。

### 2.4 References

**Definition (Zenodo)**: Generic citation/reference to another resource.

**Workspace usage**:
- bibitem cite **だが** supplements / continues / requires いずれにも該当しない Hanamura paper
- **thematic** reference (background context, foundational citation) のみ

**Workspace ルール**:
- supplements / continues / requires に既登録なら **References には登録しない** (重複 avoidance)
- bibitem cite で他 categories に該当しない paper のみ References

**Foundational papers indication**:
- `is_foundational: true` の paper が References に登場する場合、entry 内で foundational signal を明示 (e.g., "Foundational paper of the 0-Sphere Model series")

**Forward references** (#57 → #58/#59/#60 v7.26 precedent):
- 本 paper が **後続 paper を bibitem cite** する case (publication date が forward)
- References field に登録 + entry 内で「FORWARD REFERENCE」 note + companion-paper-of-sequence framing

### 2.5 Requires

**Definition (Zenodo)**: The citing resource requires the cited resource for full understanding.

**Workspace usage**:
- paper が **target の framework を logical prerequisite** として presuppose する場合
- **理解必須** = target を読まなければ本 paper の central argument が follow できない

**vs References**:
- References: bibitem cite だが logical dependency なし (background context only)
- Requires: logical dependency あり (本 paper の central argument が target framework に依存)

**Broad-prerequisite-base character** (#45 で 6 papers, #57 で 8 papers max):
- structural clarification notes / foundational mechanism papers は broader prerequisite base 持つ傾向
- [5] Requires section で broad-prerequisite-base note articulate 必要

**Reverse update**: target paper の Zenodo record で「Is required by」 を Web UI で追加 (curatorial signal: target paper の framework が後続 paper に再使用される signal)。

### 2.6 Is part of

**Definition (Zenodo)**: The cited resource is the larger work that includes the citing resource (e.g., book chapter is part of book).

**Workspace usage**:
- paper が **larger sequence / collection** の一部として位置づけ
- typical signal: シリーズ membership signal (paper #1 を anchor とする default)
- special case: sequence-foundational paper では immediate predecessor を declare (#57 → #56 v7.26 case)

**Workspace schema gap (HANDOFF v7.26 NEW pattern (d))**:
- workspace `papers/0XX.md` frontmatter に直接 `is_part_of` field なし
- derivation rule: default = #1 (founding paper), special = sequence predecessor
- `relations-strategy.md` Section 3.8 で derivation rule articulated

**Quadruple-relation case (#56 in #57 v7.26 precedent)**:
- #57 zenodo_relations で #56 が Cites + Continues + Is part of + Requires 4 relations 同時 declare
- Workspace 内では Continues + Requires 2 fields で indirect capture (Is part of は derivation rule で別途 generate)

**Reverse update**: target paper の Zenodo record で「Has part」 を Web UI で追加。

## 3. Workspace mapping summary

### 3.1 papers/0XX.md frontmatter → zenodo_relations.txt

| frontmatter field | zenodo_relations.txt section | Notes |
|---|---|---|
| `relation.supplements` | [2] Is supplement to | Direct mapping |
| `relation.continues` | [3] Continues | Direct mapping |
| `relation.references` | [4] References | Direct mapping (bibitem cite minus 他 categories) |
| `relation.requires` | [5] Requires | Direct mapping |
| (derivation rule) | [6] Is part of | Default = #1, special = sequence predecessor |
| (Union of above) | [1] Cites | supplements ∪ continues ∪ requires ∪ references |
| (Multi-relation detection) | [Multi-Relation Assignments] | papers が 2+ relation fields に登場する case |
| (Forward relation reverse) | [Reverse Relations] | Web UI 手作業範囲 reminder |

### 3.2 関連 relation types (本 corpus 未使用、参考)

| Zenodo relation type | 適用候補 case |
|---|---|
| Is new version of | DOI v1 → v2 revision (#30 v7.21 case で言及、現状 workspace canonical 統一) |
| Reviews | (将来的に paper が 既存 paper を critically review する case で適用候補) |
| Documents | (将来的に paper が 既存 paper を document する case で適用候補) |
| Describes | (将来的に paper が 既存 phenomenon を describe する case で適用候補) |

これらは現 0SM corpus では未使用、HANDOFF v7.X 範囲で出現すれば本 file に追加 articulate。

## 4. Decision tree for new bibitem cite

paper drafting 中に新 bibitem cite が登場した場合、どの relation field に登録するかの decision tree:

```
新 bibitem cite (Hanamura paper #X)
↓
Q1: 本 paper は #X を 「supplement する」 と explicit articulate?
   (subtitle "Supplement on", abstract "supplements", etc.)
├── YES → relation.supplements に登録
└── NO ↓
   Q2: 本 paper は #X を 「continue する」 と articulate?
       (sequential thread continuation, "extends the programme of #X")
   ├── YES → relation.continues に登録
   └── NO ↓
      Q3: 本 paper の central argument は #X の framework を 「論理的前提として必要」?
      ├── YES → relation.requires に登録
      └── NO → relation.references に登録 (bibitem cite のみ)

Q4: 本 paper は #X と複数 roles を持つ?
   (例: thematic extension + sequential continuation 両方)
└── 該当なら multi-relation declaration (例: supplements + continues 双方に登録)

Q5: 本 paper の publication date が #X publication date より earlier?
   (#X が forward reference)
└── YES → relation.references に登録 + forward-reference note
```

### 4.1 Decision examples

#### Example 1: #45 で #40 (derivative-order-mismatch)

```
Q1: 「#45 は #40 を supplement する?」
    → YES (Sec V で torsion-status analysis として #40 framework を extend)
    → supplements に登録
Q2: 「#45 は #40 を continue する?」
    → YES (derivative-order-mismatch programme thread を continue)
    → continues にも登録
Q3: 「#45 の central argument は #40 framework を必要とする?」
    → YES (torsion analysis は #40 framework presupposition)
    → requires にも登録

→ Multi-relation: supplements + continues + requires (triple)
```

#### Example 2: #57 で #56 (Framework Boundary)

```
Q1: 「#57 は #56 を supplement する?」
    → NO (#57 は foundational mechanism paper, not supplement)
Q2: 「#57 は #56 を continue する?」
    → YES (sequential continuation in framework programme)
    → continues に登録
Q3: 「#57 の central argument は #56 framework を必要とする?」
    → YES (framework-boundary establishment は #57 mechanism の prerequisite)
    → requires にも登録
Q4: 「#57 は #56 と sequence membership 持つ?」
    → YES (#57 は #56-anchored framework の foundational mechanism)
    → Is part of (derivation rule で別途 generate)

→ Multi-relation: Cites + Continues + Is part of + Requires (quadruple)
```

#### Example 3: #57 で #58 (forward reference)

```
Q5: 「#57 publication date が #58 publication date より earlier?」
    → YES (#57 published 2026-04, #58 anticipated 2026-05+)
Q1-Q3: (forward reference の context で apply される)
    → references に登録 + forward-reference note + companion-paper-of-sequence framing
```

## 5. Zenodo Web UI input considerations

zenodo_relations.txt は **Zenodo Web UI への copy-paste 想定** (Skill B output)。Zenodo Related identifiers field の input format:

### 5.1 Web UI field structure

```
Related identifiers:
  + Add identifier
    Identifier: <DOI or URL>
    Relation:   <dropdown: Cites / Is supplement to / Continues / etc.>
    Resource type: <dropdown: Other / Publication / Dataset / Software / etc.>
```

各 entry は別個の add operation。bulk-import 機能なし (Web UI 手作業)。

### 5.2 zenodo_relations.txt vs Web UI mapping

zenodo_relations.txt の各 entry は以下を Web UI に入力する information として function:

```
zenodo_relations.txt:
  [2] Is supplement to
  1. DOI: 10.5281/zenodo.18495487
     Paper #33 — Geometrical Confinement...
     Reason: ...

→ Web UI 入力:
  Identifier: 10.5281/zenodo.18495487
  Relation: Is supplement to
  Resource type: Other
```

`Reason:` paragraph は Zenodo Web UI には input されない (Workspace 内 curatorial record として function のみ)。

### 5.3 Resource type の選択

Zenodo Related identifiers の Resource type dropdown:
- **Other** ★ (本 0SM corpus の default、preprint/working paper として)
- Publication
- Dataset
- Software
- Image
- Video/Audio
- Workflow
- Lesson
- ...

0SM papers は全て **Other** を select (Zenodo native preprint character)。

### 5.4 Zenodo API operation

Zenodo REST API での bulk-import:
- POST /api/deposit/depositions/{id}/relations endpoint
- JSON body で multiple relations 同時 send 可能
- 本 skill scope 外 (手作業 vs API operation は User decision)

API automation を実装する場合、`zenodo_relations.txt` の各 entry を JSON にパースする変換 script が future work 候補。

## 6. References

- `references/workflow.md` Step 3: zenodo_relations.txt generation workflow (本 file relation-type 選択基準を実 generation で適用)
- `references/relations-strategy.md`: Workspace 駆動 auto-generation primary mode (本 file の Decision tree を workspace 内 frontmatter 解釈で適用)
- Skill A `references/frontmatter-schema.md`: Workspace `papers/0XX.md` frontmatter relation field schema (本 file Section 3.1 mapping の source-of-truth)
- Skill A `references/curatorial-disciplines.md` Section 4: Multi-relation declarations discipline (本 file Section 2 multi-relation handling と consistent)
