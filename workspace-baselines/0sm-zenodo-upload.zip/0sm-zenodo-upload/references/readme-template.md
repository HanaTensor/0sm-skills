# readme.txt Template (revised for workspace integration)

> Skill B の readme.txt テンプレート + workspace integration notes。Original `readme-template.md` (HanaTensor/0sm-skills repository) の content を preserve、workspace 駆動 auto-extract sections (RELATION TO PREVIOUS WORK, KEY RESULTS) で revisions 追加。

---

## 1. Template overview

readme.txt は Zenodo archive 同梱用文書 (PDF や main.tex 同梱の archive 内 readme)。Sections:

```
1. Title block
2. CONTENTS (file listing)
3. COMPILATION INSTRUCTIONS
4. ABSTRACT (paper の plain text abstract)
5. RELATION TO PREVIOUS WORK (★ workspace 駆動 auto-extract)
6. KEY RESULTS (★ workspace 駆動 auto-extract)
7. DOCUMENT STRUCTURE (paper section structure)
8. LICENSE AND CITATION
9. CONTACT INFORMATION
10. REVISION HISTORY
11. ACKNOWLEDGMENTS (★ readme.txt vs paper-internal mixed-form coexistence pattern)
12. TECHNICAL NOTES
13. OVERLEAF PROJECT SETTINGS (RECOMMENDED)
14. END OF README
```

★ marker は workspace 駆動 sections (Section 5/6/11)。

## 2. Template body

```text
================================================================================
[FULL TITLE OF THE PAPER]
================================================================================

Author: Satoshi Hanamura
Email: hana.tensor@gmail.com
Date: [Month Day, Year]

================================================================================
CONTENTS
================================================================================

This archive contains the LaTeX source file for the [document type description]:

1. main.tex
   - Main LaTeX source file ([brief description])
   - Document class: [article, 12pt, letterpaper] OR [REVTeX 4-2 (APS/PRB reprint format)]
   - Compiler: pdfLaTeX
   - TeX Live version: 2025

[IF TIKZ FILES INCLUDED:]
2. fig_*.tikz
   - TikZ figure source files

================================================================================
COMPILATION INSTRUCTIONS
================================================================================

Requirements:
- TeX Live 2025 (or compatible distribution)
- pdfLaTeX compiler
- Required LaTeX packages (included in standard TeX distributions):
  [LIST ALL PACKAGES FROM \usepackage IN main.tex]

Compilation commands:
  pdflatex main.tex
  pdflatex main.tex

Note: Two compilation passes are required for proper cross-references,
      equations, and hyperlinks.

Alternatively, use Overleaf with the following settings:
  - Main document: main.tex
  - Compiler: pdfLaTeX
  - TeX Live version: 2025
  - Compile mode: Normal
  - Stop on first error: ON (recommended)
  - Autocompile: ON (optional)

================================================================================
ABSTRACT
================================================================================

[RESEARCH SUMMARY FROM THE PAPER - plain text version, no LaTeX markup.
 Replace special characters:
   alpha    for  α
   beta     for  β
   gamma    for  γ
   delta    for  δ
   theta    for  θ
   lambda   for  λ
   mu       for  μ
   nu       for  ν
   pi       for  π
   sigma    for  σ
   tau      for  τ
   omega    for  ω
   Omega    for  Ω
   approximately  for  ≈
   ~        for  ~
   hbar     for  ℏ
   Use _N (subscript), ^N (superscript), --> (right arrow), etc.
 Keep to 1-2 paragraphs summarizing core contribution.]

Key topics include:
- [TOPIC 1]
- [TOPIC 2]
- [TOPIC 3]
- [...]

================================================================================
RELATION TO PREVIOUS WORK
================================================================================

★ Workspace 駆動 auto-extract section ★

This [document type] builds upon and clarifies concepts from:

Primary references:
1. "[Full Title]" (Zenodo [Year])
   DOI: 10.5281/zenodo.[ID]

2. "[Full Title]" (Zenodo [Year])
   DOI: 10.5281/zenodo.[ID]

[IF APPLICABLE - foundational papers from references with is_foundational: true:]
Foundational framework ([framework description]):
3. "[Full Title]" (Zenodo [Year])
   DOI: 10.5281/zenodo.[ID]

[BRIEF STATEMENT OF HOW THIS DOCUMENT RELATES TO PREVIOUS WORK]

================================================================================
KEY RESULTS
================================================================================

★ Workspace 駆動 auto-extract section ★

What the model CAN derive:
- [RESULT 1 from concepts_first or equations_first]
- [RESULT 2]
- [...]

What the model CANNOT currently derive:
- [LIMITATION 1 from opens_tasks (open status) or methodological-honesty articulation]
- [LIMITATION 2]
- [...]

[CONCLUDING STATEMENT ON SCOPE AND INTEGRITY]

================================================================================
DOCUMENT STRUCTURE
================================================================================

[LIST ALL SECTIONS AND SUBSECTIONS:]

Section 1: [Title]
  - [Brief description]

Section 2: [Title]
  2.1 [Subsection Title]
  2.2 [Subsection Title]
  [...]

[...]

Appendices:
  - [List non-numbered sections: Glossary, Acknowledgments, Bibliography, Appendices A/B/C, etc.]

================================================================================
LICENSE AND CITATION
================================================================================

This work is distributed under the Creative Commons Attribution 4.0
International License (CC BY 4.0).

Recommended citation format:
  Satoshi Hanamura,
  "[FULL TITLE],"
  Zenodo ([Year]).
  https://doi.org/10.5281/zenodo.[ID]

================================================================================
CONTACT INFORMATION
================================================================================

For questions, comments, or correspondence regarding this document:
  Email: hana.tensor@gmail.com

================================================================================
REVISION HISTORY
================================================================================

Version 1.0 ([Month Day, Year])
  - Initial release [brief description of content]
  [LIST KEY FEATURES/CONTRIBUTIONS]

================================================================================
ACKNOWLEDGMENTS
================================================================================

★ readme.txt vs paper-internal mixed-form coexistence pattern (HANDOFF v7.19/v7.24/v7.25) ★

The author acknowledges the use of large language models (LLMs) in a limited
supportive role for textual organization during document preparation.
All physical interpretations, methodological judgments, and philosophical
commitments remain the responsibility of the author.

The scientific content, conceptual framework, and theoretical interpretations
presented in this document were conceived and developed by the author, who
assumes full responsibility for all claims and interpretations herein.

This research received no specific grant from funding agencies in the public,
commercial, or not-for-profit sectors.

================================================================================
TECHNICAL NOTES
================================================================================

File format: LaTeX source (.tex)
Document class: [article, 12pt, letterpaper] OR [REVTeX 4-2 (APS/PRB reprint)]
Page layout: [2.5cm margins (all sides)] OR [REVTeX default]
Line spacing: [1.5 (onehalfspacing)] OR [REVTeX default]
Font: [Computer Modern (LaTeX default)]

Tables:
  [LIST ALL TABLES WITH NUMBERS AND DESCRIPTIONS, e.g.,
   - Table 1: Three candidate mechanisms for torsion (Section V)
   - Table 2: Spacetime vs. internal gauge connection comparison (Section VI.A)
   - Table 3: Classification of geometric structures by curvature/torsion (Appendix B)]

Cross-references:
  - Section labels for internal navigation
  - Equation numbering with \label and \ref
  - Hyperlinked bibliography and DOI links

Compilation:
  - First pass: resolves most content
  - Second pass: resolves all cross-references and hyperlinks

================================================================================
OVERLEAF PROJECT SETTINGS (RECOMMENDED)
================================================================================

If uploading to Overleaf, use these project settings:

Compiler Settings:
  Main document:       main.tex
  Compiler:            pdfLaTeX
  TeX Live version:    2025
  Compile mode:        Normal

Error Handling:
  Stop on first error: ON (recommended for debugging)
  Autocompile:         ON (optional, for real-time preview)

The document has been tested and compiles successfully with these settings.

================================================================================
END OF README
================================================================================
```

## 3. Section-by-section auto-extract guidance (workspace 駆動)

### 3.1 Title block (Section 1)

| Placeholder | Source |
|---|---|
| `[FULL TITLE OF THE PAPER]` | `papers/0XX.md` frontmatter `title:` field (subtitle 含む完全タイトル) |
| `[Month Day, Year]` | `papers/0XX.md` frontmatter `date:` field を natural form 化 (e.g., 2026-03-11 → "March 11, 2026") |

### 3.2 CONTENTS (Section 2)

| Placeholder | Source |
|---|---|
| `[document type description]` | `papers/0XX.md` frontmatter `type:` + `subtype:` から (e.g., "structural clarification note", "supplementary note", "research paper") |
| `[brief description]` | paper-specific (full manuscript with N appendices, etc.) |
| Document class | main.tex の `\documentclass[...]{...}` から確認 |

### 3.3 COMPILATION INSTRUCTIONS (Section 3)

main.tex から `\usepackage{...}` をすべて grep + 整理:

```bash
grep -E '^\\usepackage' main.tex | sed 's/\\usepackage[^{]*{//; s/}.*//' | tr ',' '\n' | sort -u
```

例 (#45 case): graphicx, bm, physics, hyperref, caption, microtype, ragged2e, booktabs, amsthm, tikz (with arrows.meta, calc, positioning)

### 3.4 ABSTRACT (Section 4)

PDF の abstract section を plain text 化:

#### Special character replacement table

| Unicode | ASCII replacement |
|---|---|
| α | alpha |
| β | beta |
| γ | gamma |
| δ | delta |
| ε | epsilon |
| ζ | zeta |
| η | eta |
| θ | theta |
| ι | iota |
| κ | kappa |
| λ | lambda |
| μ | mu |
| ν | nu |
| ξ | xi |
| π | pi |
| ρ | rho |
| σ | sigma |
| τ | tau |
| υ | upsilon |
| φ | phi |
| χ | chi |
| ψ | psi |
| ω | omega |
| Ω | Omega |
| Δ | Delta |
| Σ | Sigma |
| Π | Pi |
| Λ | Lambda |
| Φ | Phi |
| Ψ | Psi |
| ℏ | hbar |
| ≈ | approximately (or ~) |
| ≠ | != |
| ≤ | <= |
| ≥ | >= |
| → | --> |
| ⇒ | ==> |
| ∂ | d/d (partial) |
| ∫ | integral |
| ∮ | closed integral (oint) |
| ∇ | nabla |
| ∞ | infinity |

Subscripts → `_N` (e.g., v_ZB), Superscripts → `^N` (e.g., c^2)。

Length: 1-2 paragraphs (PDF abstract 全文より shorter な要約も可)。

#### Key topics list

paper の central topics 4-8 items を bullet list で記述。`papers/0XX.md` frontmatter `topics_invoked` (central + substantive のみ) を参照。

### 3.5 RELATION TO PREVIOUS WORK (Section 5) ★ workspace 駆動

`papers/0XX.md` frontmatter `relation:` field から auto-extract:

#### Primary references (continues + requires から)

```
Primary references:
1. "<continues[0] paper title>" (Zenodo <year>)
   DOI: 10.5281/zenodo.<continues[0] DOI ID>

2. "<continues[1] paper title>" (Zenodo <year>)
   DOI: 10.5281/zenodo.<continues[1] DOI ID>

[continues 配列を全 listing、必要に応じて requires も merge]
```

`<continues[i] paper title>` は対応する `papers/0YY.md` frontmatter `title:` field から取得。`<year>` は `date:` field の年部分。

#### Foundational framework (references with is_foundational: true から)

```
Foundational framework (<framework description>):
N. "<foundational paper title>" (Zenodo <year>)
   DOI: 10.5281/zenodo.<DOI ID>
```

`is_foundational: true` の references は foundational papers (典型的に #1, #29-#31 Trilogy 等) を強調。

#### Brief statement

paper の relations 全体を 1-2 sentence で要約:

```
This <type> <verb: builds upon, supplements, clarifies, extends> the
<thread name> programme established in Papers #<X> and #<Y>, and clarifies
<specific question> by <specific approach>.
```

例 (#45 case):

```
This structural clarification note examines the torsion question that arises
from the geometric structures established in Papers #33 (Geometrical Confinement),
#35 (Detailed Exposition), #38 (Two-Kernel SU(2) Structure), and #40 (Derivative-
Order-Mismatch). It continues the open-path spinorial transport framework of
Paper #29 and the line-integral ontology of Paper #31.
```

### 3.6 KEY RESULTS (Section 6) ★ workspace 駆動

`papers/0XX.md` frontmatter から auto-extract:

#### "What the model CAN derive" (concepts_first / equations_first から)

```
What the model CAN derive:
- <concept_first[0] articulation>
- <concept_first[1] articulation>
- <equations_first[0] equation + brief context>
- ...
```

選択 priority: paper の central thesis に最も positive contribution する items 4-8 を select。

#### "What the model CANNOT currently derive" (opens_tasks / methodological-honesty から)

```
What the model CANNOT currently derive:
- <opens_tasks[i] description if status: "open">
- <methodological-honesty articulation from paper-internal Sec or concepts_first>
- ...
```

selection criteria:
- `opens_tasks` で `status: "open"` の items
- Methodological-honesty pattern articulations (e.g., #44 で principled-vs-practical-distinction、#45 で open-conjecture-explicit-articulation)
- paper-internal で「remains unresolved」「open question」 等の framing

#### Concluding statement on scope and integrity

```
The mathematical structure presented here demonstrates the existence of a
<framework type> that <achievement>, but does not establish <limitation>.
This scope distinction is maintained throughout to preserve the integrity
of both the structural argument and the empirical predictions.
```

例 (#45 case):

```
The mathematical structure presented here demonstrates that the 0-Sphere
Model's spinorial structure is fully consistent with standard SU(2) holonomy
theory, but does not establish that torsion is logically necessary. This
scope distinction is maintained throughout to preserve the integrity of both
the geometric clarification and the open conjecture (directed-arc-length).
```

### 3.7 DOCUMENT STRUCTURE (Section 7)

PDF section structure を natural language で:

```
Section 1: Introduction
  - Background and motivation
  - Outline of the analysis

Section 2: <Title>
  2.1 <Subsection>
  2.2 <Subsection>

Section 3: <Title>
  ...

Appendices:
  - Appendix A: <name>
  - Appendix B: <name>
  - Acknowledgments
  - Bibliography (N entries)
```

### 3.8 LICENSE AND CITATION (Section 8)

固定 (CC BY 4.0)。Citation format placeholder 部分を fill-in:

```
Recommended citation format:
  Satoshi Hanamura,
  "<full title>",
  Zenodo (<year>).
  https://doi.org/10.5281/zenodo.<DOI ID>
```

### 3.9 CONTACT INFORMATION (Section 9)

固定 (`hana.tensor@gmail.com`)。

### 3.10 REVISION HISTORY (Section 10)

```
Version 1.0 (<Month Day, Year>)
  - Initial release of <document type description>
  - <key feature 1>
  - <key feature 2>
  - ...
```

paper の central contributions を 3-5 bullet items で listing。

### 3.11 ACKNOWLEDGMENTS (Section 11) ★ readme.txt vs paper-internal mixed-form coexistence

**重要 (HANDOFF v7.19 / v7.24 / v7.25 mixed-form coexistence pattern)**:

readme.txt の Acknowledgments は **standardized #36 phrasing** を使用 (template default):

```
The author acknowledges the use of large language models (LLMs) in a limited
supportive role for textual organization during document preparation.
All physical interpretations, methodological judgments, and philosophical
commitments remain the responsibility of the author.
```

一方 paper-internal Acknowledgments は **paper-specific variant** を維持 (e.g., #45 で "interactive conversational tool" variant)。両 forms ともに保持、distinct wording を respect:

| Form | readme.txt | paper-internal |
|---|---|---|
| **Function** | external archive metadata, standardized | paper-specific content-tailored |
| **Phrasing** | #36 phrasing (standardized prior phrasing instance) | NEW variant (paper-specific) |
| **HANDOFF v7.X precedent** | #44 + #45 双方が #36 phrasing (sustained-operation 第 1 instance) | #44 QFT-verification / #45 "interactive conversational tool" |

readme.txt template の standardized form は preserve、paper-internal の variant は paper drafting で specific articulate。

### 3.12 TECHNICAL NOTES (Section 12)

main.tex から auto-extract:

#### File format / Document class

```
File format: LaTeX source (.tex)
Document class: <REVTeX 4-2 (APS/PRB reprint)> OR <article, 12pt, letterpaper>
```

#### Tables

main.tex の `\caption{...}` から table 一覧:

```bash
grep -E '\\caption\{' main.tex | sed 's/.*\\caption{//; s/}.*//'
```

例 (#45 case):

```
Tables:
  - Table 1: Candidate mechanisms for torsion in the 0-Sphere model (Section V)
  - Table 2: The two interpretations of ∆φ(A,B) and their consequences (Section VI.A)
  - Table 3: Classification of geometric structures by curvature and torsion (Appendix B)
```

#### Cross-references

```
Cross-references:
  - Section labels for internal navigation (\label / \ref)
  - Equation numbering with \label and \ref
  - Hyperlinked bibliography and DOI links (\href)
```

#### Compilation

```
Compilation:
  - First pass: resolves most content
  - Second pass: resolves all cross-references and hyperlinks
```

### 3.13 OVERLEAF PROJECT SETTINGS (Section 13)

固定 (上記 template 参照)。

### 3.14 END OF README (Section 14)

固定 separator。

## 4. 作成時の注意事項

1. **文字エンコーディング**: UTF-8。本文中では特殊文字を避け ASCII 表現を使用 (Section 3.4 abstract 特殊文字 replacement table 参照)
2. **行幅**: 80 文字程度で折り返し (可読性確保)
3. **Section 区切り**: `=` 80 文字のライン
4. **パッケージリスト**: main.tex の `\usepackage` 行から自動抽出
5. **テーブルリスト**: main.tex の `\caption` から自動抽出
6. **参照リスト**: workspace `papers/0XX.md` frontmatter `relation:` から auto-extract (本 file Section 3.5 参照)

## 5. Workspace integration patterns (NEW section)

### 5.1 Auto-extract workflow

```
papers/0XX.md frontmatter:
  ├── title         → template Title block
  ├── date          → template Date
  ├── doi           → template Citation DOI / Section 8
  ├── type+subtype  → template document type description
  ├── relation:
  │   ├── continues + requires  → Section 5 Primary references
  │   ├── references (foundational papers)  → Section 5 Foundational framework
  │   └── (rationale comments)  → Section 5 Brief statement
  ├── concepts_first  → Section 6 "What model CAN derive"
  ├── equations_first → Section 6 "What model CAN derive"
  ├── opens_tasks    → Section 6 "What model CANNOT currently derive"
  └── topics_invoked → Section 4 Key topics list

PDF (paper):
  ├── Abstract       → Section 4 ABSTRACT (plain text 化)
  ├── Section structure → Section 7 DOCUMENT STRUCTURE
  ├── \caption → Section 12 Tables
  └── \usepackage → Section 3 COMPILATION INSTRUCTIONS
```

### 5.2 Manual-curation requirements

以下は manual curation 必要 (auto-extract 困難):

- Section 4 Abstract の natural language 要約 (PDF abstract が長すぎる場合 1-2 paragraphs に要約)
- Section 5 Brief statement (relations 全体を 1-2 sentence で要約)
- Section 6 Concluding statement on scope and integrity
- Section 10 Revision History の central contributions bullet list
- Section 11 Acknowledgments (paper-internal variant が異なる場合 readme.txt は #36 phrasing 標準形使用)
- Section 12 Tables description (table の brief description)

### 5.3 Output

```
/mnt/user-data/outputs/readme_<paper-number>.txt
```

UTF-8 / 行幅 80 文字 / `=` 80 文字 separator。

## 6. References

- `references/workflow.md` Step 2: readme.txt creation workflow position
- `references/latex-standards.md`: main.tex から package list / table list 抽出
- `references/relations-strategy.md`: workspace `papers/0XX.md` relations の auto-extract 規約
- Skill A `references/frontmatter-schema.md`: workspace frontmatter schema (cross-reference)
