# LaTeX main.tex Standards (revised for workspace integration)

> Skill B の main.tex cleanup 規約 + 比較テーブル標準。Original `latex-standards.md` (HanaTensor/0sm-skills repository) の content を mostly preserve、minor revisions for workspace integration。

---

## 1. コメント規約

### 1.1 Section direct (`\section`) 直前

```latex
% ========================================
% Section N: [Section Title in English]
% ========================================
\section{...}
```

`=` 40 characters の long border line で section block を visually separate。Title は **英語** のみ (日本語コメント禁止 per Section 2.1)。

### 1.2 非番号 section (`\section*`) 直前

```latex
% ========================================
% [Name] (e.g., Glossary, Acknowledgments, Bibliography)
% ========================================
\section*{...}
```

Glossary / Acknowledgments / Bibliography 等の非番号 sections も同 standard。

### 1.3 Subsection (`\subsection`) 直前

```latex
% ----------------------------------------
% Subsection N.M: [Subsection Title]
% ----------------------------------------
\subsection{...}
```

`-` 40 characters の medium border line で subsection を visually separate (section level border `=` よりも light)。

### 1.4 Subsubsection (`\subsubsection`) 直前

```latex
% ----------------------------------------
% Subsubsection N.M.K: [Subsubsection Title]
% ----------------------------------------
\subsubsection{...}
```

Subsection と同じ `-` border (visual hierarchy 維持のため、必要に応じて line length を調整可)。

### 1.5 Table (`\begin{table}`) 直前

```latex
% ----------------------------------------
% Table N: [Table Description]
% ----------------------------------------
\begin{table}[...]
```

Tables は subsection level の `-` border を使用。

### 1.6 Document structure 区切り (preamble standard)

```latex
% ========================================
% Document Class and Package Setup
% ========================================
\documentclass[reprint, ...]{revtex4-2}   % または \documentclass[12pt]{article}
\usepackage{...}
...

% ========================================
% Page Layout Configuration
% ========================================
\geometry{...}
\setlength{\parindent}{...}
...

% ========================================
% Section Title Formatting
% ========================================
\titleformat{\section}{...}{...}{...}{...}
...

% ========================================
% Document Begin
% ========================================
\begin{document}

% ========================================
% Title, Author, and Date
% ========================================
\title{...}
\author{Satoshi Hanamura}
\affiliation{...}
\date{<明示日付, e.g., March 11, 2026>}

% ========================================
% Table of Contents
% ========================================
\tableofcontents

% ========================================
% Research Summary
% ========================================
\begin{abstract}
...
\end{abstract}

% ========================================
% End of Document
% ========================================
\end{document}
```

各 preamble block を `=` border で visually separate。Document body 内 (sections / subsections / tables) は section/subsection level border を使用。

## 2. 禁止事項

### 2.1 日本語コメントの全削除

```latex
% (削除前) これは日本語コメント
% (削除後)  ← この行ごと削除する

% This is an English comment        ← 残す
```

`%` に続く日本語テキスト (Hiragana, Katakana, Kanji) を含むコメント行は **すべて削除**。文字コード判定: `[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]` 範囲のいずれかが含まれる場合 = 日本語コメント。

### 2.2 コメントアウト行の削除

```latex
%\date{\today}                      ← 削除 (使用していないコメントアウト行)
%\maketitle                         ← 削除
% \tableofcontents                  ← 削除 (前後 spaceがあっても同様)

\date{March 11, 2026}               ← 残す (active 行)
```

`%` で始まる「コメントアウトされた LaTeX command」 行は **すべて削除**。残すと cleanup の意図が unclear になる。

### 2.3 空コメントの禁止

```latex
%                                   ← 削除 (empty comment, ノイズ)

% (空行で代替)
```

`%` のみの行 (空コメント) は不要。空行で代替 (LaTeX は 空行で paragraph break)。

### 2.4 TODO / FIXME コメント残存禁止 (任意)

```latex
% TODO: rewrite this section        ← submit 前に削除 / 解決
% FIXME: equation 5 may be wrong    ← submit 前に削除 / 解決
```

submit 前の cleanup で TODO / FIXME / XXX 等の作業 marker は **すべて解決**。残存させない。

## 3. ファイル構造 checklist

main.tex upload 前に以下の項目を確認:

- [ ] 日本語コメントがゼロ (Section 2.1)
- [ ] コメントアウト行がゼロ (Section 2.2)
- [ ] 空コメントなし (Section 2.3)
- [ ] TODO/FIXME 等の作業 marker なし (Section 2.4)
- [ ] 全 sections に英語コメントブロック (Section 1.1)
- [ ] 全 subsections に英語コメントブロック (Section 1.3)
- [ ] tables に英語コメントブロック (Section 1.5)
- [ ] preamble に standard structure 区切りコメント (Section 1.6)
- [ ] `\label` と `\ref` の整合性 (`\ref{undefined}` なし)
- [ ] DOI links が `\href{https://doi.org/...}{DOI: ...}` 形式 (consistent)
- [ ] `DOI to be assigned` が草稿に残っていない (Step 0 で確認済)
- [ ] `DOI Pending` が草稿に残っていない (Step 0 で確認済)
- [ ] `\date{}` が明示的な日付 (`\today` ではない、e.g., `\date{March 11, 2026}`)
- [ ] 二重コンパイル (`pdflatex main.tex` × 2) で全 references 解決

## 4. 比較テーブル作成要領 (Supplement 標準)

### 4.1 背景と目的

Supplement 論文で 2 つの物理的枠組みを対比する際は、**独立したセクション内に比較テーブルを配置する**。テーブルは査読者にとって最もスキャンしやすい形式であり、誤読防止 + 理論輪郭の明示 + 将来論文への布石として function。

### 4.2 テーブルの 3 部構成

比較テーブルを含むセクションは以下の 3 部構成:

1. **概念的導入段落** (1 段落) — 2 つの対象が表面上類似しているが構造的に異なることを宣言する。**疑問形を使わず平叙文** で書く。

2. **テーブル本体** — 下記 standard template (Section 4.3) 参照。

3. **テーブル後の解説段落群** — `\paragraph` 見出しで層別に説明。`\paragraph` 見出しは **平叙形のみ** (疑問形・体言止め禁止、Section 4.6)。

### 4.3 テーブルの LaTeX コード標準

```latex
% ----------------------------------------
% Table N: [Table Title]
% ----------------------------------------
\begin{table}[h]
\centering
\textbf{Table N. [表題（テーブル上部に太字で表示）]}\\[6pt]
\begin{tabularx}{\textwidth}{lXX}
\toprule
\textbf{Feature} & \textbf{[Case A]} & \textbf{[Case B]} \\[6pt]
\midrule\\[-4pt]
[行1の比較項目]   & [Case A の内容] & [Case B の内容] \\[8pt]
[行2の比較項目]   & [Case A の内容] & [Case B の内容] \\[8pt]
[数式を含む行]   & $\displaystyle\int ...$ & $\displaystyle\oint ...$ \\[12pt]
[最終行]         & [Case A の内容] & [Case B の内容] \\[4pt]
\bottomrule
\end{tabularx}
\caption{[キャプション文（テーブル下部）。両者に共通する構造と根本的差異を 1〜2 文で要約する。]}
\label{tab:[identifier]}
\end{table}
```

### 4.4 行間 spacing standard 値

| 行の種類 | 末尾 spacing |
|---------|------------|
| Header 行 (`\toprule` 直後) | `\\[6pt]` |
| `\midrule` 直後の調整 | `\\[-4pt]` (余分な空白を相殺) |
| 通常のデータ行 | `\\[8pt]` |
| 数式 (`\displaystyle`) を含む行 | `\\[12pt]` |
| 最終データ行 (`\bottomrule` 直前) | `\\[4pt]` |

**重要 placement rules**:

- `\textbf{Table N. ...}\\[6pt]` — 表題はテーブル**上部**、太字
- `\caption{...}` — テーブル**下部** (`\end{tabularx}` の後)
- `\label{...}` — `\caption{}` の **直後** (`\caption` の前に置くと参照番号がずれる)

### 4.5 標準 7 行カテゴリ (Supplement 比較テーブル参考)

Paper #41 の Table 1 (Shapiro delay vs AB effect) を雛形として、以下 7 行カテゴリ標準:

| 行カテゴリ | 記載内容の指針 |
|-----------|--------------|
| Field type | 各理論の基本的な幾何学的対象 (計量 / 接続 / 曲率 等) |
| Local curvature along path | 経路上の曲率の有無とその意味 |
| Observable | 実験的に測定される量 (位相差 / 固有時差 等) |
| Mathematical form | 線積分の具体的な数式表現 |
| Closed loop required | 測定に閉じたループが必要か否かとその理由 |
| Local force | 経路上に局所的な力が存在するか否か |
| Origin of effect | 効果の幾何学的・位相的起源の分類 |

7 行カテゴリは strict requirement ではなく **template guidance**。Paper-specific contents で異なる category set が適切な場合は適宜 adapt (例: #45 で three candidate-mechanisms は Mechanism / Physical origin / Logical obstacle / Current status の 4 列構造)。

### 4.6 テーブル後の解説段落 standard 構成

```latex
Table~\ref{tab:[identifier]} organizes these differences across
[N] levels, each of which corresponds to a distinct aspect of
[the comparison being made].

\paragraph{[Layer 1 name]: [declarative summary].}
[本文 ...]

\paragraph{[Layer 2 name]: [declarative summary].}
[本文 ...]

...
```

`\paragraph` 見出しの命名規則:

✅ Acceptable:
- `Physical level: local force and its absence.`
- `Observational level: a shared structure with an internal distinction.`
- `Mathematical level: line integrals and their structural variants.`

❌ Forbidden:
- `Physical level: Is there a local force?` (疑問形)
- `What they share` (体言止め)
- `Comparing layer 1 and layer 2:` (gerund 中途半端)

平叙形 (declarative form) のみ使用。Period (`.`) で 終わる完結 sentence。

### 4.7 テーブル追加時 checklist

- [ ] 表題が `\textbf{Table N. ...}\\[6pt]` 形式でテーブル上部
- [ ] `\caption{}` がテーブル下部 (`\end{tabularx}` の後)
- [ ] `\label{}` が `\caption{}` の直後
- [ ] `Table~\ref{tab:[identifier]}` で本文中から参照
- [ ] `\paragraph` 見出しが平叙形 (Section 4.6 規約)
- [ ] readme.txt の Technical Notes / Tables section に追記

## 5. Workspace integration notes (revised section, NEW)

### 5.1 比較テーブル存在の workspace signal

paper の比較テーブルは workspace 内 curatorial signal として function:

- `papers/0XX.md` frontmatter `concepts_first` field に table-based articulation を record
- table-based articulation は Methodological-honesty pattern の signal (Sec V Table I 「Three candidate mechanisms with logical-obstacle-and-status」 #45 precedent)
- 「Comparison table approach」 自体が curatorial pattern として modest articulation pool に candidate (HANDOFF v7.25 で #45 で 第 1 instance)

### 5.2 main.tex の workspace mapping

main.tex 構造と `papers/0XX.md` frontmatter の correspondence:

| main.tex element | papers/0XX.md frontmatter mapping |
|---|---|
| `\title{...}` | `title:` field |
| `\date{...}` | `date:` field |
| Abstract (`\begin{abstract}...\end{abstract}`) | `## Curatorial summary` body section |
| Section structure | body content `## Series-position context` 等 |
| Tables (numbered) | `concepts_first` items (table-based articulation) |
| `\bibitem` Hanamura papers | `relation:` field (supplements / continues / requires / references) |
| Acknowledgments | `provenance.ai_collaboration_acknowledged` |

main.tex の cleanup と workspace の curate 内容との **bidirectional consistency** を maintain (e.g., `papers/0XX.md` で declared な supplements が main.tex bibitem で cite されているか cross-check)。

### 5.3 Specific paper precedents

- **#45**: 3 substantial appendices + 3 comparison tables (Sec V Table I, Sec VI.A Table II, App B Table III) + REVTeX 4-2 format adoption (HANDOFF v7.25 第 1 instance)
- **#41**: Table 1 (Shapiro delay vs AB effect) — 比較 table standard 雛形 (HANDOFF v7.17 reference)
- **#43**: Table-based comparison + SU(2) teleparallel mathematical illustration (HANDOFF v7.19 #43 curate)

## 6. REVTeX 4-2 format support (revised section, NEW)

HANDOFF v7.25 で initial articulate された REVTeX 4-2 format adoption pattern (#45 第 1 instance):

### 6.1 REVTeX 4-2 preamble

```latex
\documentclass[reprint, amsmath, amssymb, aps, prb]{revtex4-2}
\usepackage{...}

\begin{document}

\title{<Full Title>}
\author{Satoshi Hanamura}
\email{hana.tensor@gmail.com}
\affiliation{<affiliation if any>}
\date{<明示日付>}

\begin{abstract}
...
\end{abstract}

\maketitle

\section{Introduction}
...
```

### 6.2 REVTeX 4-2 vs article format choice

- **REVTeX 4-2** (`\documentclass[reprint, ...]{revtex4-2}`): physics journal-style (APS / PRB), two-column reprint format, より formal presentation
- **Article** (`\documentclass[12pt, letterpaper]{article}`): generic LaTeX article, single-column, より flexible

#### Choice criteria:

- New papers (2026-03+): **REVTeX 4-2** preferred (#45 onwards precedent, より professional presentation)
- Earlier papers (#1-#44): article format (existing convention)

User-specific preference は workspace 内 modest articulation candidate (post-v7.25 で sustained adoption 確認 case): paper #57 onwards で REVTeX 4-2 sustained adoption が確認できれば format-shift-to-REVTeX-from-article pattern が formal taxonomy candidate。

### 6.3 REVTeX 4-2 specific differences

#### TableNotes

REVTeX 4-2 は `tabularx` の代わりに `ruledtabular` を推奨する場合:

```latex
\begin{table}
\caption{...}
\label{tab:...}
\begin{ruledtabular}
\begin{tabular}{lcc}
...
\end{tabular}
\end{ruledtabular}
\end{table}
```

ただし comparison table standard (Section 4) は `tabularx` ベース。Paper-specific choice (#45 で `tabularx` 使用)。

#### Bibliography

REVTeX 4-2 は `\bibliography{<bibfile>}` または embedded `\thebibliography` 双方対応:

```latex
% Embedded bibliography
\begin{thebibliography}{99}
\bibitem{ref1} ...
\end{thebibliography}
```

bibitem rationale 各 entry の prose content は workspace `papers/0XX.md` frontmatter relations の comment と consistent maintain。

## 7. Cleanup workflow (Step 1 detailed procedure)

### 7.1 Initial drafted main.tex

User が drafted main.tex を upload。典型的な状態:
- 日本語コメント混在
- Section/subsection コメントブロック不在 / 不統一
- 一部にコメントアウト行 / TODO marker 残存
- DOI link 形式不統一

### 7.2 Cleanup steps

#### Step 1.1: Read drafted main.tex

```python
with open('drafted_main.tex') as f:
    content = f.read()
lines = content.split('\n')
```

#### Step 1.2: Japanese comment detection + removal

```python
import re
JAPANESE_PATTERN = re.compile(r'[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]')
cleaned_lines = []
for line in lines:
    stripped = line.strip()
    if stripped.startswith('%') and JAPANESE_PATTERN.search(line):
        continue   # 日本語コメント行 → skip
    if stripped == '%':
        continue   # 空コメント行 → skip
    if re.match(r'^\s*%\\(date|today|maketitle|tableofcontents|...)', line):
        continue   # コメントアウト LaTeX command → skip (selective)
    cleaned_lines.append(line)
```

#### Step 1.3: Section comment block 追加

```python
section_pattern = re.compile(r'^\\section\*?\{(.+)\}$')
for i, line in enumerate(cleaned_lines):
    match = section_pattern.match(line.strip())
    if match:
        title = match.group(1)
        section_n = ...   # extract from \label or context
        # Insert before this line:
        cleaned_lines.insert(i, '% ========================================')
        cleaned_lines.insert(i+1, f'% Section {section_n}: {title}')
        cleaned_lines.insert(i+2, '% ========================================')
```

Subsection / table も同様。

#### Step 1.4: DOI link standardization

```python
# Pre-cleanup variations:
# {DOI: 10.5281/zenodo.XXXXXXX}
# https://doi.org/10.5281/zenodo.XXXXXXX
# \url{https://doi.org/10.5281/zenodo.XXXXXXX}

# Standardize to:
# \href{https://doi.org/10.5281/zenodo.XXXXXXX}{DOI: 10.5281/zenodo.XXXXXXX}
```

#### Step 1.5: Verification

`pdflatex main.tex × 2` で compile + 0 warning / 0 undefined references 確認。

### 7.3 Output

```
/mnt/user-data/outputs/main_<paper-number>.tex
```

## 8. Standards file maintenance

本 standards file は HANDOFF v7.X transitions で:
- 新 paper precedent (e.g., REVTeX 4-2 adoption #45 v7.25) の修正反映
- 比較 table standard (Section 4) の修正反映
- workspace integration notes (Section 5) の expansion

Update timing は modest articulation pool review timing と同期 (HANDOFF transition narrative で標準 file revision を report)。

## 9. References (Skill B 内)

- `references/workflow.md` Step 1: main.tex cleanup workflow position
- `references/readme-template.md`: Technical Notes section で main.tex 抽出 metadata
- `references/relations-strategy.md`: bibitem cite と workspace relations の bidirectional consistency
- Skill A `references/frontmatter-schema.md`: workspace frontmatter schema (cross-reference)
