# Master Workflow (Steps 0-4)

> Skill B の master workflow reference。Zenodo upload preparation の Steps 0-4 step-by-step procedure。Original WORKFLOW.md (HanaTensor/0sm-skills repository) の workspace 駆動 revised version。

---

## 1. Workflow overview

```
Step 0. Prerequisite check
        ├── Workspace curate 済み確認
        └── DOI placeholder check (drafted main.tex)

Step 1. main.tex cleanup
        └── latex-standards.md 規約適用

Step 2. readme.txt creation
        └── readme-template.md + workspace metadata + PDF abstract

Step 3. zenodo_relations.txt auto-generation
        └── workspace papers/0XX.md frontmatter relations から primary-mode 生成

Step 3.5. zenodo_description.html generation
        └── description-html.md + workspace concepts/equations/analogies から auto-extract

Step 4. Deliverable packaging + reverse relations list
        └── 4 files /mnt/user-data/outputs/ + reverse relations chat reminder
```

WORKFLOW.md original の Step 5 (GitHub `HanaTensor/0sm-skills` 更新) は本 skill 第 1 版 scope 外。

## 2. Step 0: Prerequisite check (必須・最初に実施)

### 2.1 Workspace curate 済み確認

```bash
# Check 1: paper file 存在
ls context/papers/0XX.md
  → Expected: ファイル存在
  → If not exist: "papers/0XX.md が未 curate です。先に 0sm-corpus-curate skill を invoke してください" と redirect

# Check 2: frontmatter relations populated
python3 << EOF
import yaml, re
with open('context/papers/0XX.md') as f:
    content = f.read()
match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
fm = yaml.safe_load(match.group(1))
print('relation:', fm.get('relation', {}))
EOF
  → Expected: supplements / continues / requires / references 配列が defined
  → If null/empty: WIP-curated state, relations refinement が必要
```

### 2.2 DOI placeholder check

drafted main.tex 内に以下の placeholder が残存していないか確認:

```bash
grep -n "DOI to be assigned\|DOI Pending" <drafted_main.tex>
```

#### Result handling

```
"DOI to be assigned" が存在する場合:
  → 作業を即座に中断
  → User へ: 「Zenodo にプレ登録して DOI を取得してから upload 準備を再開してください」

"DOI Pending" が存在する場合:
  → 確定 DOI (10.5281/zenodo.XXXXXXX 形式) への置換が完了しているか確認
  → 未置換の場合は先に置換を依頼
```

### 2.3 Optional: Workspace HANDOFF state check

```bash
head -10 HANDOFF.md
  → 現 v(N) baseline + paper #XX が curate set 内か確認
```

## 3. Step 1: main.tex cleanup

### 3.1 Required cleanup operations

`references/latex-standards.md` 規約に従う:

#### 3.1.1 日本語コメント全削除

```latex
% (削除前) これは日本語コメント
% (削除後)  ← この行ごと削除

% Some English comment              ← 残す
%\date{\today}                      ← コメントアウト行も削除
```

#### 3.1.2 英語 section コメントブロック追加

```latex
% ========================================
% Section N: [Section Title in English]
% ========================================
\section{...}

% ----------------------------------------
% Subsection N.M: [Subsection Title]
% ----------------------------------------
\subsection{...}

% ----------------------------------------
% Table N: [Table Description]
% ----------------------------------------
\begin{table}[h]
```

#### 3.1.3 ドキュメント構造区切り標準化 (preamble)

```latex
% ========================================
% Document Class and Package Setup
% ========================================
\documentclass[...]{...}
\usepackage{...}
...

% ========================================
% Page Layout Configuration
% ========================================
...

% ========================================
% Section Title Formatting
% ========================================
...

% ========================================
% Document Begin
% ========================================
\begin{document}

% ========================================
% Title, Author, and Date
% ========================================
\title{...}
\author{...}
\date{<明示日付, not \today>}

% ========================================
% Table of Contents
% ========================================
\tableofcontents

% ========================================
% Research Summary
% ========================================
...

% ========================================
% End of Document
% ========================================
\end{document}
```

#### 3.1.4 Comparison tables の standard format check (任意)

paper が比較 table を含む場合 (例: #45 Sec V Table I / Sec VI.A Table II / App B Table III):
- `\textbf{Table N. ...}\\[6pt]` 上部太字
- `\caption` 下部 (`\end{tabularx}` の後)
- `\label` は `\caption` 直後
- `\paragraph` 平叙形見出し

詳細は `references/latex-standards.md` Section 4 参照。

### 3.2 File structure checklist

cleanup 完了前に以下を確認:

- [ ] 日本語コメントがゼロ
- [ ] 全 sections に英語コメントブロック
- [ ] 全 subsections に英語コメントブロック
- [ ] tables に英語コメントブロック
- [ ] `\label` と `\ref` の整合性
- [ ] DOI link が `\href{https://doi.org/...}{DOI: ...}` 形式
- [ ] **`DOI to be assigned` 残存なし** (Step 0 で確認済)
- [ ] **`DOI Pending` 残存なし** (Step 0 で確認済)
- [ ] `\date{}` が明示日付
- [ ] 二重コンパイルで全 references 解決

### 3.3 Output

```
/mnt/user-data/outputs/main_<paper-number>.tex
```

## 4. Step 2: readme.txt creation

### 4.1 Template-driven approach

`references/readme-template.md` テンプレートから生成。`[PLACEHOLDER]` を以下から fill-in:

#### 4.1.1 Paper metadata (workspace から auto)

| Placeholder | Source |
|---|---|
| `[FULL TITLE OF THE PAPER]` | `papers/0XX.md` frontmatter `title:` |
| `[Month Day, Year]` | `papers/0XX.md` frontmatter `date:` |
| `[document type description]` | `type` + `subtype` 由来 (例: research / supplement / clarification) |

#### 4.1.2 ABSTRACT section

PDF Research Summary を plain text に変換:
- α → alpha
- γ → gamma
- ≈ → approximately
- ℏ → hbar
- ω → omega
- 上付き / 下付き文字 → 通常 ASCII 表現

1-2 paragraphs に summarize、Key topics の bullet list を末尾。

#### 4.1.3 RELATION TO PREVIOUS WORK section (workspace 駆動)

`papers/0XX.md` frontmatter relations から auto-extract:

```
Primary references:
1. <continues[0] title> (Zenodo <year>)
   DOI: <continues[0] DOI>

2. <continues[1] title> (Zenodo <year>)
   DOI: <continues[1] DOI>

...

Foundational framework (= references with foundational signal):
N. <reference foundational paper title> (Zenodo <year>)
   DOI: <DOI>
```

選択 priority:
1. continues + requires papers (necessary prerequisites)
2. supplements papers (thematic extensions)
3. references with `is_foundational: true` (foundational framework)

#### 4.1.4 KEY RESULTS section (workspace 駆動)

`papers/0XX.md` frontmatter から auto-extract:

```
What the model CAN derive:
- <concepts_first[i] articulation>
- <equations_first[j] articulation>
...

What the model CANNOT currently derive:
- <opens_tasks[k] description if status: open>
- <opens_tasks[l] description if methodological-honesty pattern>
```

#### 4.1.5 DOCUMENT STRUCTURE section

PDF section structure をそのまま転記:

```
Section 1: <Title>
  - <brief description>
Section 2: <Title>
  2.1 <Subsection>
  2.2 <Subsection>
...
Appendices:
  - <List of non-numbered sections>
```

#### 4.1.6 TECHNICAL NOTES section

main.tex から auto-extract:
- Document class
- `\usepackage` リスト
- Tables (`\caption` から抽出)
- Figures (`\caption` から抽出)
- Cross-references (`\label` count)

#### 4.1.7 ACKNOWLEDGMENTS section

paper の AI-collaboration acknowledgment (paper-internal Acknowledgments section の verbatim、または readme.txt template の standard form)。

**重要**: HANDOFF v7.19 / v7.24 / v7.25 で identify された **mixed-form coexistence pattern** を respect。readme.txt は #36 phrasing (standardized) を使用、paper-internal は paper-specific variant を維持。両者の wording が distinct であっても両 forms ともに保持。

### 4.2 Output

```
/mnt/user-data/outputs/readme_<paper-number>.txt
```

行幅 80 文字程度 / セクション区切り `=` 80 文字 / UTF-8。

詳細 template + auto-extract 規約は `references/readme-template.md` 参照。

## 5. Step 3: zenodo_relations.txt auto-generation (workspace 駆動 primary mode)

### 5.1 Auto-generation flow

`papers/0XX.md` frontmatter から zenodo_relations.txt 6 sections を auto-generate:

#### 5.1.1 [Summary] section

```
[Summary]
  Cites              : <count> entries (<unique DOI count>)
  Is supplement to   : <len(supplements)> entries
  Continues          : <len(continues)> entries
  References         : <len(references)> entries
  Requires           : <len(requires)> entries
  Is part of         : 1 entry
  
  Multi-relation DOIs: <count of papers in 2+ relations>
  Reverse-relation papers: <count of distinct target papers>
```

#### 5.1.2 [1] Cites section

各 bibitem-cited Hanamura paper を enumerate:
- supplements + continues + requires + references の和集合
- 各 entry の DOI + paper number + title + date + brief role description

非-Hanamura standard refs (Nakahara / MTW / Hehl et al. 等) は:
- 「Cites」 section の note paragraph で「formal citations in the bibliography but are not Zenodo records」 として記述
- Zenodo records ではないため [1] Cites の bullet items には含めない

#### 5.1.3 [2] Is supplement to section

`papers/0XX.md` frontmatter `supplements` 配列から:

```
[2] Is supplement to

This paper's <subtitle declaration / abstract framing> signals that it
supplements <high-level statement>.

1. DOI: <supplements[0] DOI>
   Paper #<n> — <title>
   Reason: <rationale from frontmatter comment>

2. ...
```

各 entry に **rationale paragraph** を frontmatter コメントから抽出 + paragraph として整形。

`supplements` が `null` の場合:

```
[2] Is supplement to

None applicable.

This paper is a stand-alone <type>, not declared as a supplement
in its title, abstract, or body text. <reasoning>
```

#### 5.1.4 [3] Continues section

`continues` 配列から同様に auto-generate。各 entry rationale 必須。

Triple-continuation case (#45 v7.25 precedent) などの multi-paper continuation pattern は **explicit articulation in the [Summary] note** で curatorial signal を明示。

#### 5.1.5 [4] References section

`references` 配列から auto-generate。Forward-references (#57 → #58/#59/#60 v7.26 precedent) は special handling:

```
[4] References

1. ... (regular references)

(Forward references — companion papers of #XX-#YY sequence):

N. DOI: <forward reference DOI>
   Paper #<n> — <title>
   Note: FORWARD REFERENCE — companion paper of the #XX-#YY sequence;
         supplies <deferred items> deferred from this paper.
```

#### 5.1.6 [5] Requires section

`requires` 配列から auto-generate。Broad-prerequisite-base character (例: #45 で 6 papers, #57 で 8 papers max) は [Summary] note で signal。

#### 5.1.7 [6] Is part of section

Workspace schema gap (HANDOFF v7.26 NEW pattern (d)) のため manual derivation:

```
Derivation rule:
  "Is part of" target = immediate predecessor in chronological/numerical sequence
                        OR foundational paper of sequence
  (Default: paper #1 for series founding paper membership)
  (Special case: foundational mechanism paper of sequence では sequence predecessor を指定)
```

例:
- #45 (2026-03-11): "Is part of" = #1 (founding paper, シリーズ membership)
- #57 (2026-04, sequence #57-#61 foundational): "Is part of" = #56 (immediate predecessor)

#### 5.1.8 [Multi-Relation Assignments] section

frontmatter で同 paper が複数 relation fields に登場する case を enumerate:

```
[Multi-Relation Assignments]   (same DOI, multiple relation types)

#XX (DOI): Cites + Continues + Requires
#YY (DOI): Cites + Continues + Is part of + Requires
...
```

v7.25 dual-relation (#40 in #45) / v7.26 quadruple-relation (#56 in #57) precedent。

#### 5.1.9 [Reverse Relations] section

各 forward relation について reverse 推奨を auto-derive:

| Forward relation (本論文) | Reverse relation (target paper) |
|---|---|
| Is supplement to <X> | <X> Is supplemented by 本論文 |
| Continues <X> | <X> Is continued by 本論文 |
| Requires <X> | <X> Is required by 本論文 |
| References <X> | <X> Is referenced by 本論文 |
| Is part of <X> | <X> Has part 本論文 |

```
[Reverse Relations -- Recommended Updates to Target Papers]

The following reverse relations should be added to the Zenodo records of
the listed papers, pointing back to <本論文 DOI>:

#XX (<DOI>): Is supplemented by | <本論文 DOI>
#YY (<DOI>): Is continued by | <本論文 DOI>
                                   Is required by | <本論文 DOI>
...
```

詳細は `references/relations-strategy.md` Section 4 参照。

### 5.2 Output

```
/mnt/user-data/outputs/zenodo_relations_<paper-number>.txt
```

英語のみ / Section 番号 `[N]` 形式 / UTF-8。

詳細 auto-generation 規約は `references/relations-strategy.md` 参照。

## 6. Step 3.5: zenodo_description.html generation

### 6.1 Auto-extract from workspace

`papers/0XX.md` frontmatter から:

#### 6.1.1 導入段落 (1-2 sentences)

PDF abstract または `papers/0XX.md` body の `## Curatorial summary` セクションから 1-2 文を抽出。

#### 6.1.2 Core Equations (2-4 equations)

`equations_first` 配列から central equations を select。Unicode で記述:

```html
<p><b>— Core Equations —</b></p>
<p>
<b>Two-layer kernel structure:</b><br>
K_int(A,B) = exp(i ω₀ L_int / v_ZB)
</p>
<p>
<b>SU(2) round-trip relation:</b><br>
U_{A→B} · U_{B→A} = -1 ∈ SU(2)
</p>
```

#### 6.1.3 Key Contributions (4-6 items)

`concepts_first` + `equations_first` + `analogies_first` から 4-6 items select:

```html
<p><b>— Key Contributions —</b></p>
<ul>
<li><b>Three candidate mechanisms for torsion:</b> ...</li>
<li><b>Spacetime-vs-internal-gauge dichotomy:</b> ...</li>
<li><b>Holonomy-sufficiency thesis:</b> ...</li>
<li><b>Pedagogical appendices:</b> ...</li>
</ul>
```

選択 criteria: paper の central thesis を最も明示する items 4-6 を select。

#### 6.1.4 シリーズ位置づけ

`papers/0XX.md` frontmatter `continues` + `supplements` から先行論文 DOI links:

```html
<p><b>— Series Position —</b></p>
<p>
This <type> continues the <thread> programme established in
<a href="<continues[0] DOI>">Paper #X</a> and
<a href="<continues[1] DOI>">Paper #Y</a>,
and supplements
<a href="<supplements[0] DOI>">Paper #Z</a>.
</p>
```

#### 6.1.5 主要参照テーブル

`references` 配列を `<table>` で render:

```html
<table>
  <thead>
    <tr><th>#</th><th>Title (abbreviated)</th><th>DOI</th></tr>
  </thead>
  <tbody>
    <tr>
      <td>10</td>
      <td>Redefining Electron Spin and AMM</td>
      <td><a href="https://doi.org/10.5281/zenodo.17764997">10.5281/zenodo.17764997</a></td>
    </tr>
    ...
  </tbody>
</table>
```

#### 6.1.6 Series Context (固定文)

`references/description-html.md` Section 5 の固定 template:

```html
<p>
The 0-Sphere Model is an ongoing research programme (2018–present) that derives
spin, anomalous magnetic moment, Zitterbewegung, and emergent spacetime from the
geometry and thermodynamics of a two-kernel electron model.
All papers in the series are archived on Zenodo:
</p>
<p>
<a href="https://zenodo.org/search?q=metadata.creators.person_or_org.name%3A%22Hanamura%2C+Satoshi%22">Zenodo search: Hanamura, Satoshi</a>
</p>
```

### 6.2 Tag validation

`references/description-html.md` Section 6 の Python validator script で許可タグ外検出:

```python
from html.parser import HTMLParser

class Validator(HTMLParser):
    ALLOWED = {'a','abbr','acronym','b','blockquote','br','code','caption',
               'div','em','i','li','ol','p','pre','span','strike','strong',
               'sub','table','tbody','thead','th','td','tr','u','ul'}
    ...
```

許可タグ外があれば修正、validator 0-error まで iterate。

### 6.3 Output

```
/mnt/user-data/outputs/zenodo_description_<paper-number>.html
```

UTF-8 / 行幅自由 / `<sup>` 不可 (Unicode 上付き文字または `<sub>` 代替) / `style` 属性除去前提。

詳細は `references/description-html.md` 参照。

## 7. Step 4: Deliverable packaging + reverse relations list

### 7.1 4 files presentation

```bash
# 4 deliverable files in /mnt/user-data/outputs/
ls /mnt/user-data/outputs/
  main_<paper-number>.tex
  readme_<paper-number>.txt
  zenodo_relations_<paper-number>.txt
  zenodo_description_<paper-number>.html
```

`present_files` tool で User に提示。

### 7.2 Reverse relations recommended-update list (chat reminder)

```
以下の <count> papers の Zenodo records に reverse relations を追加してください
(Zenodo Web UI 手作業範囲、本 skill scope 外):

#X (<DOI>): Add "Is supplemented by" <本論文 DOI>
#Y (<DOI>): Add "Is continued by" <本論文 DOI>
            Add "Is required by" <本論文 DOI>
#Z (<DOI>): Add "Is required by" <本論文 DOI>
...

Forward-companion reverse relations (#A, #B, #C が upload 後):
#A (<DOI>): Add "Continues" <本論文 DOI>
#B (<DOI>): Add "Continues" <本論文 DOI>
...
```

### 7.3 TikZ + 図表 file inclusion (任意)

paper が TikZ を使用する場合:
- `fig_*.tikz` 等の外部図表 file を main.tex と同じ archive に同梱
- main.tex は `\input{fig_*.tikz}` で参照
- archive 形式: `.zip` または `.tar.gz` (Zenodo upload form の対応形式)

詳細は paper-specific case で User に確認。

## 8. Workflow checklist

```
Zenodo upload 準備 完了確認 (4 deliverable files):

[ ] Step 0a: workspace curate 済み確認 (papers/0XX.md, relations populated)
[ ] Step 0b: DOI placeholder check (no "DOI to be assigned" / "DOI Pending")

[ ] Step 1:  main.tex cleanup 完了
            [ ] 日本語コメントゼロ
            [ ] 英語 section/subsection コメントブロック追加
            [ ] DOI link 形式統一
            [ ] 二重コンパイル成功

[ ] Step 2:  readme.txt 作成完了
            [ ] テンプレート fill-in 完了
            [ ] Workspace metadata auto-extract 反映
            [ ] PDF abstract plain text 化

[ ] Step 3:  zenodo_relations.txt 作成完了
            [ ] 6 sections auto-generated
            [ ] Multi-Relation Assignments enumerated
            [ ] Reverse Relations list auto-derived
            [ ] 英語のみ、Section 番号 [N] 形式

[ ] Step 3.5: zenodo_description.html 作成完了
            [ ] 6 必須 sections (導入/Core Eq/Key Contrib/Series Pos/参照テーブル/Series Context)
            [ ] 許可タグのみ使用 (validator 0-error)
            [ ] Workspace concepts/equations auto-extract 反映

[ ] Step 4:  4 deliverable files /mnt/user-data/outputs/ に出力
[ ] Step 4:  Reverse relations recommended-update list を chat に提示
```

## 9. Out-of-scope items

### 9.1 Step 5 (旧 WORKFLOW.md GitHub repo update)

`HanaTensor/0sm-skills` repository の `index.md`, `papers.md`, `concept.md`, `global-concept.md` への GitHub 更新は本 skill 第 1 版 scope 外。Workspace ↔ GitHub の関係 clarification 待ち (HANDOFF v7.X clarification 候補)。

### 9.2 Zenodo Web UI 操作

Reverse relations の Zenodo Web UI への反映 (本 skill recommended-update list を User が手作業で各 target paper の Zenodo record に追加) は本 skill scope 外。

### 9.3 Zenodo upload submit

実際の Zenodo API submit (curl / Web UI form 操作) は手作業範囲。

## 10. Reference cross-links

- `references/latex-standards.md`: Step 1 main.tex cleanup 規約 + 比較テーブル standard
- `references/readme-template.md`: Step 2 readme.txt template + workspace integration
- `references/relations-strategy.md`: Step 3 workspace 駆動 auto-generation 規約 (primary mode)
- `references/relation-types.md`: Step 3 Zenodo 33 relation types reference + workspace mapping
- `references/description-html.md`: Step 3.5 description HTML 標準 + auto-extract guidance

Skill A cross-reference (Skill B prerequisite):
- `0sm-corpus-curate` Skill A: workspace curate workflow (Step 0 prerequisite で参照)
