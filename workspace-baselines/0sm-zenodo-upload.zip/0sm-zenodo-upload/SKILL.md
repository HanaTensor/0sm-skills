---
name: 0sm-zenodo-upload
description: 0-Sphere Model paper の Zenodo upload 用 4 deliverable files (cleaned main.tex / readme.txt / zenodo_relations.txt / description.html) 生成 skill。Prerequisite: 0sm-corpus-curate で curate 済み。
---

# 0-Sphere Model Zenodo Upload Preparation

Curated paper を Zenodo upload submit-ready 状態に仕上げる skill。Workspace 駆動 auto-generation を primary mode とし、curate 済 frontmatter から zenodo_relations.txt の主要 content を自動生成する。

## Full context (frontmatter description 短縮版の補足)

本 skill は以下の 5 use case で invoke する:

- (a) drafted main.tex を upload-ready 状態に整えたい (日本語コメント削除 / 英語 section コメント追加 / DOI placeholder check)
- (b) readme.txt 新規作成 (テンプレート + paper metadata fill-in)
- (c) zenodo_relations.txt 生成 (workspace papers/0XX.md frontmatter から auto-generate primary mode、manual探索 fallback)
- (d) zenodo_description.html 生成 (許可タグ範囲 + Key Contributions auto-extract from frontmatter concepts_first/equations_first/analogies_first)
- (e) "Zenodo アップロード準備" / "main.tex クリーンアップ" / "readme.txt 作って" 等 framing

**Prerequisite**: paper が `0sm-corpus-curate` skill で curate 済みであること (zenodo_relations.txt content の workspace 駆動 auto-generation のため)。

**Out of scope**:
- Reverse relations の Zenodo Web UI 手作業反映 (recommended-update list を出力するのみ)
- WORKFLOW.md Step 5 (GitHub repo update) は本 skill 第 1 版 scope 外

## 1. Trigger conditions

以下の状況で本 skill を invoke する:

### 1.1 Full upload preparation (most common)

User が drafted main.tex を持ち、Zenodo upload submit-ready の 4 deliverable files (cleaned main.tex / readme.txt / zenodo_relations.txt / zenodo_description.html) 全部を必要とする場合。

### 1.2 Specific deliverable preparation

- main.tex cleanup のみ依頼
- readme.txt 新規作成のみ依頼
- zenodo_relations.txt 生成のみ依頼
- zenodo_description.html 生成のみ依頼

### 1.3 Trigger phrasings

- 「Zenodo アップロード準備」
- 「#XX を upload form に出したい」
- 「main.tex をクリーンアップ」
- 「readme.txt を作って」
- 「relations.txt 生成」
- 「description.html 作成」

## 2. Prerequisite check

paper 番号 #XX が `0sm-corpus-curate` skill で curate 済みであることを確認:

```bash
ls context/papers/0XX.md   # 存在 check
```

確認 items:
- `context/papers/0XX.md` 存在
- frontmatter の `relation:` field が populated:
  - `supplements`, `continues`, `requires`, `references` 配列が defined
  - 各 relation に rationale comment が付与

未 curate / partial curate の場合:
- **`0sm-corpus-curate` skill を先に invoke してください** と redirect
- 部分 curate (preliminary) の場合は relations refinement workflow を経て formal sync

詳細は `references/workflow.md` Step 0 参照。

## 3. Workflow overview

```
Step 0. Prerequisite check (workspace curate 済み確認 + DOI placeholder check)
Step 1. main.tex cleanup        → cleaned main.tex
Step 2. readme.txt creation     → readme.txt (workspace metadata + PDF abstract)
Step 3. zenodo_relations.txt    → workspace 駆動 auto-generate (primary)
Step 3.5. zenodo_description.html → workspace concepts/equations 駆動 + manual curation
Step 4. Deliverable packaging    → 4 files 納品 + reverse relations list 提示
```

詳細 step-by-step は `references/workflow.md` 参照。

## 4. Workspace 駆動 auto-generation (本 skill の核心)

### 4.1 zenodo_relations.txt content auto-generation (Step 3 primary mode)

`papers/0XX.md` frontmatter relations から zenodo_relations.txt 6 sections の主要 content を auto-generate:

```
[1] Cites          ← 全 bibitem (supplements + continues + requires + references の和集合 + non-Hanamura standard refs)
[2] Is supplement to ← frontmatter `supplements` 配列
[3] Continues      ← frontmatter `continues` 配列
[4] References     ← frontmatter `references` 配列 (bibitem cite で他 categories に含まれない Hanamura papers)
[5] Requires       ← frontmatter `requires` 配列
[6] Is part of     ← derivation rule: immediate predecessor in chronological/numerical sequence
                     OR foundational paper of sequence (#57 case では #56)
[Reverse Relations] ← 各 forward relation の reverse 推奨 list を auto-derive
```

各 entry に rationale を frontmatter コメントから抽出。Multi-relation single target は v7.25 / v7.26 precedent (dual / quadruple) に従って正当化。

詳細は `references/relations-strategy.md` (workspace-driven auto-generation primary mode) 参照。

### 4.2 zenodo_description.html Key Contributions auto-extract (Step 3.5)

`papers/0XX.md` frontmatter から Key Contributions 4-6 項目を auto-extract:

- `concepts_first` 配列 → 「Conceptual contributions」 items
- `equations_first` 配列 → 「Mathematical articulations」 items
- `analogies_first` 配列 → 「Analogical articulations」 items

選択 criteria: paper の central thesis を最も明示する items 4-6 を select。残りは body text で言及。

### 4.3 readme.txt RELATION TO PREVIOUS WORK auto-extract (Step 2)

`papers/0XX.md` frontmatter relations から RELATION TO PREVIOUS WORK section を auto-generate:

```
Primary references (= continues + requires の合併):
1. <title> (DOI link)
2. <title> (DOI link)
...

Foundational framework (= references with high signal, foundational papers):
3. <title> (DOI link)
```

詳細は `references/readme-template.md` 参照。

## 5. Workspace 駆動 vs Manual探索

### 5.1 Primary mode: Workspace 駆動 (本 skill 推奨)

- Paper が curate 済 (frontmatter relations populated)
- zenodo_relations.txt の 80%+ content が auto-generation 可能
- Manual additions: bibitem rationale 各 entry の prose content + Multi-relation 正当化 + 特殊 case (forward references 等)

### 5.2 Fallback mode: Manual探索

User uploaded zenodo workflow files (relations-strategy.md original) の Section 3 「Relation 選択フローチャート」 のような manual 探索 mode。Paper が未 curate の場合、または workspace driven mode が不適合な edge cases。

詳細は `references/relations-strategy.md` Section 5 参照。

## 6. Standards references (本 skill 内)

詳細 standards は本 skill の `references/` フォルダに配置:

| File | Content | Original source |
|---|---|---|
| `references/workflow.md` | Master workflow Steps 0-4 (revised, Step 5 GitHub update 削除) | WORKFLOW.md (revised) |
| `references/latex-standards.md` | main.tex cleanup 規約 + 比較テーブル標準 | latex-standards.md (mostly preserved) |
| `references/readme-template.md` | readme.txt テンプレート + workspace integration notes | readme-template.md (revised) |
| `references/relations-strategy.md` | Workspace 駆動 auto-generation primary mode (heavily revised) | relations-strategy.md (heavily revised) |
| `references/relation-types.md` | Zenodo 33 relation types + workspace mapping section | relation-types.md (revised, workspace mapping 追加) |
| `references/description-html.md` | Description HTML 標準 + Key Contributions auto-extract guidance | description-html.md (revised) |

## 7. Cross-reference to Skill A (`0sm-corpus-curate`)

本 skill (Zenodo upload) は **Skill A (corpus curate) の output を primary input** として使用する。Bidirectional dependency:

### 7.1 Skill A → Skill B handoff

Skill A での paper curate 完了後、User が Zenodo upload 準備に進む場合は本 skill (Skill B) を invoke。Skill A workflow Step 14 (baseline tarball package) で workspace state が consistent (validator all-clear maintained) であることが本 skill prerequisite。

### 7.2 Skill B → Skill A redirect

本 skill が invoke されたが paper が未 curate の場合:

```
"#XX について Zenodo upload 準備が依頼されましたが、
 context/papers/0XX.md が未 curate です。
 先に `0sm-corpus-curate` skill を invoke して curate を完了してください。
 curate 完了後、本 skill を再 invoke してください。"
```

WIP-curated (preliminary) の場合:

```
"#XX は WIP-curated 状態です。
 Zenodo 形式の formal zenodo_relations.txt があれば、
 先に `0sm-corpus-curate` skill で relations refinement (preliminary → formal sync) を実施してください。
 (HANDOFF v7.26 #57 precedent 参照)"
```

## 8. Deliverable file output

最終 4 files は `/mnt/user-data/outputs/` に place:

```
/mnt/user-data/outputs/
├── main_<paper-number>.tex                    # cleaned LaTeX source
├── readme_<paper-number>.txt                  # readme template fill-in
├── zenodo_relations_<paper-number>.txt        # auto-generated relations
└── zenodo_description_<paper-number>.html     # description HTML
```

加えて reverse relations recommended-update list を chat output (User reminder)。

## 9. Out-of-scope items

以下は本 skill 第 1 版 scope 外:

### 9.1 WORKFLOW.md Step 5 (GitHub `HanaTensor/0sm-skills` リポジトリ更新)

旧 WORKFLOW.md Step 5 の `index.md`, `papers.md`, `concept.md`, `global-concept.md` への GitHub 更新は、現 workspace (papers/, topics/, queries/, derived/) と OLD GitHub structure の関係 (parallel maintenance / migration / 内外分業) が clarification 待ちのため、本 skill 第 1 版では Zenodo 部分 (Steps 0-4) のみ scope。

User が本 skill 第 1 版で関連質問した場合、HANDOFF v7.X clarification を示唆。

### 9.2 Zenodo Web UI 操作 (reverse relations 反映)

Reverse relations の Zenodo Web UI への反映 (各 target paper の Zenodo record で「Is continued by」 / 「Is required by」 等 add) は手作業範囲。本 skill は recommended-update list を出力するのみ。

### 9.3 Zenodo upload submit (curl / API)

実際の Zenodo API submit は手作業範囲。本 skill は 4 deliverable files を生成するまで。

## 10. Worked example: Full upload preparation

(本 skill の典型的 invocation flow を 1 paper で例示)

### Input

User uploads:
- `paper45_main.tex` (drafted LaTeX source)
- 関連 PDF (再アップロード または既 curate session で context として保持)

または User が「#45 (Open-Path Spinorial Transport) の Zenodo upload 準備」 を依頼。

### Skill B invocation

#### Step 0. Prerequisite check

```
Workspace state check:
  context/papers/045.md 存在 ✓
  frontmatter relations populated ✓
    supplements: [33, 35, 38, 40] ✓
    continues: [29, 31, 40] ✓
    requires: [29, 31, 33, 35, 38, 40] ✓
    references: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41] ✓
  → Prerequisite OK, proceed to Step 1
  
DOI placeholder check:
  drafted main.tex に "DOI to be assigned" / "DOI Pending" の残存検査
  → 残存なし、proceed
```

#### Step 1. main.tex cleanup

`references/latex-standards.md` 規約適用:
- 日本語コメント全削除
- 英語 section コメントブロック追加
- コメントアウト行削除
- 比較テーブル (Sec V Table I, Sec VI.A Table II, App B Table III) 標準形式確認
- DOI link 形式統一

#### Step 2. readme.txt creation

`references/readme-template.md` テンプレートから生成 + `papers/045.md` frontmatter から auto-fill:
- Title: "Open-Path Spinorial Transport in the 0-Sphere Model and the Status of Torsion: ..."
- Date: 2026-03-11
- DOI: 10.5281/zenodo.18950974
- ABSTRACT: PDF abstract を plain text 化
- RELATION TO PREVIOUS WORK: continues + requires から auto-extract
- KEY RESULTS: opens_tasks (open) + concepts_first (achieved) から auto-extract
- DOCUMENT STRUCTURE: PDF section structure
- TECHNICAL NOTES: main.tex `\usepackage` + tables 抽出

#### Step 3. zenodo_relations.txt auto-generation

`papers/045.md` frontmatter から:

```
[1] Cites: 12 papers (supplements + continues + requires + references の合併 - 重複)
  + 3 non-Hanamura standard refs (Nakahara, MTW, Hehl et al.)
[2] Is supplement to: [33, 35, 38, 40] (各 entry に rationale comment from frontmatter)
[3] Continues: [29, 31, 40] (triple-continuation pattern, 各 entry に rationale)
[4] References: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41]
[5] Requires: [29, 31, 33, 35, 38, 40] (max 6, broad-prerequisite-base character)
[6] Is part of: #1 (founding paper, シリーズ membership)

[Multi-Relation Assignments]:
  #40: Is supplement to + Continues (dual-relation 第 1 instance v7.25)

[Reverse Relations - Recommended Updates to Target Papers]:
  各 forward relation の reverse 推奨を auto-derive
  例: #38 → "Is supplemented by" 10.5281/zenodo.18950974 (#45 DOI)
```

#### Step 3.5. zenodo_description.html generation (2-file output)

`references/description-html.md` Section 5 templates + `papers/045.md` frontmatter から:

- 導入段落: paper abstract から 1-2 文
- Core Equations: Eq. (II.2)-(II.3) two-layer kernel + Eq. (III.1) path-ordered exponential
  - **LaTeX with MathJax delimiters** (`\(...\)` inline / `\[...\]` display) で記述 (Section 8 conversion table 適用)
- Key Contributions (4-6 items): concepts_first + equations_first + analogies_first から select
- シリーズ位置: continues + supplements の primary papers DOI links
- 主要参照テーブル: references 全 papers DOI table
- Series Context: 固定文 + Hanamura, Satoshi Zenodo search link

**2 file output** (description-html.md Section 8.7):
- `zenodo_description_<N>.html`: Fragment (Zenodo paste 用、LaTeX delimiters)
- `zenodo_description_<N>_preview.html`: Preview (offline 確認用、KaTeX CDN wrapper、同 LaTeX content)

タグ検証 (description-html.md Section 6 Python validator) で 0-error 確認 (fragment file のみ対象、preview file は許可外タグの style/script を含むため除外)。

#### Step 4. Deliverable file packaging

5 files を `/mnt/user-data/outputs/` に place + present_files で User に提示:

```
main_<N>.tex
readme_<N>.txt
zenodo_relations_<N>.txt
zenodo_description_<N>.html         # Zenodo paste 用 (Step 3.5 fragment)
zenodo_description_<N>_preview.html # Local 確認用 (Step 3.5 preview)
```

(概念的には 4 deliverables、description は paste 用 + 確認用の 2-file mode)

Reverse relations recommended-update list を chat output に reminder:

```
以下の 7 papers の Zenodo records に reverse relations を追加してください (Web UI 手作業):

#38 (10.5281/zenodo.18718174): Add "Is supplemented by" 10.5281/zenodo.18950974
#40 (10.5281/zenodo.18736670): Add "Is supplemented by" 10.5281/zenodo.18950974
                                Add "Is continued by" 10.5281/zenodo.18950974
#33, #35, #29, #31, #1: 同様の reverse relations
```

### Output

- 5 deliverable files (4 conceptual: main.tex / readme.txt / relations.txt / description; description は 2-file mode で fragment + preview)
- Reverse relations recommended-update list (User手作業 reminder)

## 11. References

詳細 standards reference:

- `references/workflow.md`: Master workflow Steps 0-4 step-by-step
- `references/latex-standards.md`: main.tex cleanup + 比較テーブル標準
- `references/readme-template.md`: readme.txt template + workspace integration
- `references/relations-strategy.md`: Workspace 駆動 auto-generation primary mode
- `references/relation-types.md`: Zenodo 33 relation types + workspace mapping
- `references/description-html.md`: Description HTML 標準 + Key Contributions auto-extract
