# 0-Sphere Model — DOI 正典リスト (canonical DOI registry)

**最終更新**: 2026-05-30 (v8.01 establishment)
**目的**: 過去論文を読み込む際、常にこのリストを正典として DOI を照合する。新規論文 (#61〜) の相互参照は必ずこのリストの canonical DOI を引く。

## 照合ルール (チェック機能の本体)

1. **canonical = 最新版 (latest version)**。v1→v2 改訂があった論文は最新版 DOI を canonical とする。
2. **#60 以前は留置 (do NOT modify published cross-refs)**。既に Zenodo 公開済みのため、過去論文の bibliography が旧 DOI を記載していてもそのまま。「どちらが正しい?」「過去文献も直すか?」への答えは一律「#60以前は留置、新規論文のみ最新版を引く」。
3. **新規論文 (#61〜) は canonical を引く**。ドラフト段階の相互参照誤りはこのリストで照合・訂正する。
4. **読み込み時は常にこのリストを正典として照合**。論文本文・他論文の bibliography・memory のいずれと食い違っても、canonical 値が優先。
5. **#16 = 永久欠番** (User explicit)。curate しない。

## 複数 DOI を持つ論文 (v1/v2、要注意)

| # | canonical (最新版) | 旧版 (留置) | 備考 |
|---|---|---|---|
| 30 | 18819682 (v2) | 18135855 (v1) | #54 の bibliography は旧 v1 を記載 → 留置 |
| 51 | 20388056 (v2) | 19489126 (v1) | #55 の bibliography + workspace baseline 旧記録は v1 → 留置。#62/#65 は v2 で正 |

## canonical DOI 一覧 (#1〜#65)

| # | DOI | title (短縮) |
|---|---|---|
| 1 | 16759284 | A Model of an Electron Including Two Perfect Black Bodies |
| 2 | 16783727 | A New Representation of Spin Angular Momentum |
| 3 | 17759634 | Distinguishing Electron Spin via Riemann Surface |
| 4 | 17759699 | Perfect Contrast Cannot be Obtained in Double-Slit |
| 5 | 17759726 | Transition Theory of an Electron |
| 6 | 17759908 | Correspondence Between a 0-Sphere and the Electron |
| 7 | 17760132 | Coexistence Positive/Negative-Energy States in Dirac |
| 8 | 17760445 | Electron-Positron Pair Annihilation by Thermal Oscillations |
| 9 | 17764952 | Beyond the Standard Model: Neutrino Oscillations |
| 10 | 17764997 | Redefining Electron Spin and AMM (bridge eq γ=1+|a|) |
| 11 | 17765017 | Quantum Oscillations: ZB, Geodesic Paths, Proper Time |
| 12 | 17765039 | Radiation-Mediated Quantum Tunneling |
| 13 | 17765079 | Unified Spin Dynamics |
| 14 | 17765097 | Bridging QM and GR: AMM and Geodetic Precession |
| 15 | 17765121 | Spin-Induced Inertial Resistance (gyroscopic) |
| 16 | — | (permanent gap, do not curate) |
| 17 | 17765136 | From Clock Synchronization to Electromagnetism: U(1) |
| 18 | 17765200 | Time-Dependent Mass: Hamiltonian Approach |
| 19 | 17765238 | Spin as Real Vector: U(1) Gauge and SU(2) Periodicity |
| 20 | 17765244 | Emergent Conservation Laws: Noetherian Reinterpretation |
| 21 | 17765305 | Anomalous Magnetic Moments Without Fields |
| 22 | 17765318 | Gravitational Redshift of Internal Quantum Clocks (ZB) |
| 23 | 17765336 | From Zero-Sphere to Emergent Spacetime |
| 24 | 17765349 | Thermal Geodesics in the 0-Sphere Model |
| 25 | 18064535 | A Noetherian Inversion (Einsteinian geom → symmetry) |
| 26 | 17765409 | Spin from Geometry: Internal Berry Phase |
| 27 | 17765439 | Challenging the Uncertainty Principle |
| 28 | 18636509 | Supplementary Correction: Dimensional Consistency G,c² |
| 29 | 18067760 | Spinorial Phase Accumulation along Thermal Geodesics |
| 30 | 18819682 | From Curvature to Connection (v2; v1=18135855) |
| 31 | 18203433 | Line Integrals as Fundamental Observables (AB/Berry/Wilson) |
| 32 | 18275142 | Dissolution of the Vacuum Energy Problem |
| 33 | 18356895 | Geometrical Confinement: Rest Mass and ZB |
| 34 | 18437010 | Geometrical Confinement: Emergent Gravitational Dynamics |
| 35 | 18511664 | Detailed Exposition of Gravitational-Like Phenomena |
| 36 | 18603340 | Non-Perturbative Nature and Fine-Structure Constant |
| 37 | 18637487 | Reinterpreting Gravitational Potential Energy (line-integral) |
| 38 | 18718174 | Electron Interference from Internal Geometry (corrected 2026-05-30; was dup 18637487) |
| 39 | 18727981 | Vacuum Energy, Integral Ontology, Cosmological Constant |
| 40 | 18736670 | Derivative-Order Mismatch Between Gauge Theory and Gravity |
| 41 | 18809117 | Note on Derivative Hierarchy |
| 42 | 18857609 | Non-Perturbative Nature and Magnetic Monopole Absence |
| 43 | 18896784 | Observer-Dependent Torsion, ZB, Phase Accumulation |
| 44 | 18905344 | Internal Energy Stabilization, Charge Localization |
| 45 | 18950974 | Open-Path Spinorial Transport and Status of Torsion |
| 46 | 19010945 | Geometric Origin of the One-Half Factor |
| 47 | 19120057 | Rotational Lorentz Contraction as AMM Origin (muon corr.) |
| 48 | 19227518 | Geometric Origin of g=2: U(1) Fiber Bundle |
| 49 | 19393391 | Photon-Sphere Fragmentation as Gravitational Mediator |
| 50 | 19482145 | Rotation from Scalar Oscillation (photon-sphere ang. mom.) |
| 51 | 20388056 | Helical Trajectory, Synge, Spacetime Metric (v2; v1=19489126) |
| 52 | 19583032 | Geometric Origin of the Weak Equivalence Principle (λ_C) |
| 53 | 19616971 | From Gravitational Mediation to Directional Force Classification |
| 54 | 19701297 | Maxwell Electrodynamics as Derived Low-Energy Limit |
| 55 | 19800797 | Four Functions of the Open Wilson Line |
| 56 | 19900974 | The Framework Boundary: Local-Field vs Directed-Path |
| 57 | 19932176 | Spherical Harmonic Imprinting (Y_ℓ^m, gravitational coupling) |
| 58 | 19932861 | Spin-2 Structure of the Gravitational Mediator |
| 59 | 19932907 | Proton-Trapped Electron: Spin-2 Gravitational Radiation |
| 60 | 19932922 | The Berry-Synge-Bonnet-Myers Triangle |
| 61 | 19934138 | Two-Electron Algebraic Cancellation in He-4 (draft, unpublished) |
| 62 | 20091680 | γ-Equation Applied to the Proton (336 MeV, draft) |
| 63 | TBD | γ-Equation Applied to the Neutron (322.5 MeV, 13.4 MeV disc., draft) |
| 64 | TBD | Gravity as Thermal-Path Optimization (Snell-Fermat, draft) |
| 65 | TBD | AMM as Frame-Independent Invariant (g-2 three-scale, draft) |

## 公開状態 (publication status)

- **公開済み (Zenodo deposited)**: #1〜#60 (#16 欠番)。これらは確定・凍結。
- **未公開ドラフト**: #61 (DOI 予約 19934138 だが Zenodo 未アップロード)、#62 (DOI 自己予約 20091680)、#63/#64/#65 (DOI 未予約)。

## 既知の cross-reference 不整合 (留置、参考)

- #54 の `hanamura30` = 18135855 (#30 v1)。canonical は v2 18819682。**留置** (v1/v2 相違)。
- #55 の `hanamura51` = 19489126 (#51 v1)。canonical は v2 20388056。**留置** (v1/v2 相違)。
- これらは「公開済み論文の bibliography が旧版 DOI を引いている」例。新規論文では canonical を引くこと。

## 参照表記の統一 (viXra→DOI、2026-06 確定)

corpus 内の論文間相互参照は **すべて Zenodo DOI 表記**に統一する。viXra 表記は廃止 (Zenodo record に viXra origin が記載済みのため十分。User 確定 2026-06)。論文現物の bib が viXra でも、frontmatter・relation 成果物・description では DOI に直す。corpus 見直し時は `grep -rn viXra context/papers/` で残存を洗い出し一括で揃える。#27 改訂で確定した参照点: #4=17759699 (旧 viXra:1906.0275)、#6=17759908 (旧 2001.0610)、#8=17760445 (旧 2107.0029)。
