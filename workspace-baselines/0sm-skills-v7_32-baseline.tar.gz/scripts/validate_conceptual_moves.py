#!/usr/bin/env python3
"""
validate_conceptual_moves.py

Lightweight validator for context/derived/conceptual-moves.md.

This is a MANUALLY curated file (not auto-generated), but we want to catch
basic referent integrity errors:
  - Paper numbers cited in entries that do not exist in context/papers/
  - Paper numbers cited that are the permanent gap (#16)

Usage:
  python scripts/validate_conceptual_moves.py
"""

import re
import sys
from pathlib import Path


PERMANENT_GAP = {16}


def main():
    repo_root = Path(__file__).resolve().parent.parent
    moves_path = repo_root / "context" / "derived" / "conceptual-moves.md"
    papers_dir = repo_root / "context" / "papers"

    if not moves_path.exists():
        print(f"ERROR: {moves_path} not found")
        sys.exit(1)

    # Inventory of existing paper numbers
    existing = set()
    for p in papers_dir.glob("*.md"):
        if p.stem.isdigit():
            existing.add(int(p.stem))

    text = moves_path.read_text(encoding="utf-8")

    # Extract all #NN references (1-3 digits, not preceded by alphanumeric)
    refs = set()
    for m in re.finditer(r"(?<![A-Za-z0-9_])#(\d{1,3})\b", text):
        refs.add(int(m.group(1)))

    errors = []
    permanent_gap_refs = []
    nonexistent_refs = []

    for r in sorted(refs):
        if r in PERMANENT_GAP:
            permanent_gap_refs.append(r)
            errors.append(f"References permanent-gap paper #{r}")
        elif r not in existing:
            nonexistent_refs.append(r)
            errors.append(f"References nonexistent paper #{r}")

    print(f"Scanned: {moves_path.relative_to(repo_root)}")
    print(f"Paper references found: {len(refs)} unique (#{min(refs) if refs else '-'} to #{max(refs) if refs else '-'})")
    print(f"Existing papers in context/papers/: {len(existing)}")

    if not errors:
        print("\n✓ All paper references resolve to existing curated papers.")
        sys.exit(0)

    print(f"\n=== {len(errors)} validation issue(s) ===\n")
    for e in errors:
        print(f"  - {e}")

    if permanent_gap_refs:
        print(f"\nPermanent gap references: {permanent_gap_refs}")
        print("(#16 is declared a permanent gap per HANDOFF v7.9. Remove or annotate.)")

    if nonexistent_refs:
        print(f"\nNonexistent paper references: {nonexistent_refs}")
        print("(These may be forward-dangling references to uncurated papers.")
        print(" If intentional, annotate inline as '[uncurated]' to suppress this warning in future iterations.)")

    sys.exit(1)


if __name__ == "__main__":
    main()
