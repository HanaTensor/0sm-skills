#!/usr/bin/env python3
"""
validate_frontmatter.py

Validates frontmatter of all papers/*.md and topics/**/*.md files
against the v3 schema. Cross-checks integrity:
  - relation.* references point to existing papers
  - papers::topics_invoked matches topics::applies_to bidirectionally
  - topic example_readings::paper references match applies_to

Usage:
  python validate_frontmatter.py [--root context/]

Exits with code 0 if all valid, 1 if any errors found.
"""

import argparse
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required. Install with: pip install pyyaml")
    sys.exit(2)


# ============================================================
# Schema definitions
# ============================================================

PAPER_TYPES = {"research", "supplement", "clarification", "synthesis", "correction", "note"}

PAPER_SUBTYPES = {
    "research": {None, "foundational"},
    "supplement": {None, "mathematical", "conceptual", "structural", "historical",
                   "conceptual-and-mathematical"},
    "clarification": {None, "structural", "conceptual"},
    "synthesis": {None},
    "correction": {None},
    "note": {None, "structural", "methodological", "historical", "structural-proposal"},
}

PAPER_REQUIRED_FIELDS = {"number", "title", "date", "doi", "type"}
TOPIC_REQUIRED_FIELDS = {"subject", "layer", "title", "applies_to", "status"}

VALID_LAYER_NAMES = {"classical", "textbook", "0sm", "historical", "experimental"}
VALID_TOPIC_STATUS = {"active", "stub", "deprecated", "superseded"}
VALID_PREDICTION_STATUS = {"unmeasured", "partial", "confirmed", "refuted",
                            "open", "technically-difficult"}


# ============================================================
# Frontmatter extraction
# ============================================================

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def extract_frontmatter(filepath):
    """Extract YAML frontmatter from a markdown file. Returns dict or None."""
    text = filepath.read_text(encoding="utf-8")
    m = FRONTMATTER_RE.match(text)
    if not m:
        return None
    try:
        return yaml.safe_load(m.group(1))
    except yaml.YAMLError as e:
        return {"_yaml_error": str(e)}


# ============================================================
# Validation helpers
# ============================================================

def validate_paper(filepath, fm, errors):
    """Validate a single paper frontmatter dict."""
    where = f"papers/{filepath.name}"

    if fm is None:
        errors.append(f"{where}: missing or malformed frontmatter")
        return
    if "_yaml_error" in fm:
        errors.append(f"{where}: YAML parse error: {fm['_yaml_error']}")
        return

    # Required fields
    missing = PAPER_REQUIRED_FIELDS - fm.keys()
    if missing:
        errors.append(f"{where}: missing required fields: {missing}")

    # Type validation
    t = fm.get("type")
    if t not in PAPER_TYPES:
        errors.append(f"{where}: invalid type '{t}', expected one of {PAPER_TYPES}")
        return

    # Subtype validation
    sub = fm.get("subtype")
    if t in PAPER_SUBTYPES and sub not in PAPER_SUBTYPES[t]:
        errors.append(f"{where}: invalid subtype '{sub}' for type '{t}', "
                      f"expected one of {PAPER_SUBTYPES[t]}")

    # is_foundational only meaningful for research type
    if fm.get("is_foundational") and t != "research":
        errors.append(f"{where}: is_foundational=true only valid for type=research")

    # Number must match filename
    expected_num = int(filepath.stem)
    if fm.get("number") != expected_num:
        errors.append(f"{where}: frontmatter number={fm.get('number')} "
                      f"does not match filename {filepath.name}")

    # DOI format check (allow null for draft/unpublished papers)
    doi = fm.get("doi")
    if doi is None:
        # Allow null DOI only when explicitly marked as draft/unpublished
        if not fm.get("status") in ("draft", "unpublished"):
            errors.append(f"{where}: doi is null but status is not 'draft' or 'unpublished'")
    elif not isinstance(doi, str) or not doi.startswith("10.5281/zenodo."):
        errors.append(f"{where}: invalid DOI format: '{doi}'")

    # Predictions status validation
    for pred in fm.get("predictions") or []:
        status = pred.get("status") if isinstance(pred, dict) else None
        if status and status not in VALID_PREDICTION_STATUS:
            errors.append(f"{where}: invalid prediction status '{status}'")


def validate_topic(filepath, fm, errors):
    """Validate a single topic frontmatter dict."""
    where = f"topics/{filepath.relative_to(filepath.parents[2] / 'topics')}"

    if fm is None:
        errors.append(f"{where}: missing or malformed frontmatter")
        return
    if "_yaml_error" in fm:
        errors.append(f"{where}: YAML parse error: {fm['_yaml_error']}")
        return

    # Required fields
    missing = TOPIC_REQUIRED_FIELDS - fm.keys()
    if missing:
        errors.append(f"{where}: missing required fields: {missing}")

    # Status
    status = fm.get("status")
    if status not in VALID_TOPIC_STATUS:
        errors.append(f"{where}: invalid status '{status}', expected one of {VALID_TOPIC_STATUS}")

    # Subject must match parent folder name (if in folder)
    if filepath.parent.name not in ("topics",):  # not at topics root
        expected_subject = filepath.parent.name
        if fm.get("subject") != expected_subject:
            errors.append(f"{where}: subject='{fm.get('subject')}' "
                          f"does not match folder '{expected_subject}'")

    # Layer must match filename
    expected_layer = filepath.stem
    if fm.get("layer") != expected_layer:
        errors.append(f"{where}: layer='{fm.get('layer')}' does not match filename")


def cross_validate(papers_data, topics_data, errors):
    """Cross-reference checks between papers and topics."""
    paper_numbers = set(papers_data.keys())

    # 1. Check all relation references point to existing papers
    for n, fm in papers_data.items():
        rel = fm.get("relation") or {}
        for field in ("supplements", "continues", "requires", "references"):
            for ref in rel.get(field) or []:
                if ref not in paper_numbers:
                    errors.append(f"papers/{n:03d}.md: relation.{field} "
                                  f"references nonexistent paper #{ref}")
        for single_field in ("companion_to", "corrects"):
            ref = rel.get(single_field)
            if ref is not None and ref not in paper_numbers:
                errors.append(f"papers/{n:03d}.md: relation.{single_field}"
                              f" = {ref} but paper does not exist")

        # Check closes_tasks paper references
        for task in fm.get("closes_tasks") or []:
            if isinstance(task, dict):
                p = task.get("paper")
                if p is not None and p not in paper_numbers:
                    errors.append(f"papers/{n:03d}.md: closes_tasks references "
                                  f"nonexistent paper #{p}")

    # 2. Check topics_invoked / applies_to bidirectional consistency
    paper_to_topics = {n: set(fm.get("topics_invoked") or [])
                       for n, fm in papers_data.items()}

    topic_to_papers = {}
    for (subject, _), fm in topics_data.items():
        applies = set(fm.get("applies_to") or [])
        if subject not in topic_to_papers:
            topic_to_papers[subject] = set()
        topic_to_papers[subject] |= applies

    # Forward: each paper's topics_invoked must exist as topic folders
    for n, topics_set in paper_to_topics.items():
        for subject in topics_set:
            if subject not in topic_to_papers:
                errors.append(f"papers/{n:03d}.md: topics_invoked='{subject}' "
                              f"but no such topic folder exists")
            elif n not in topic_to_papers[subject]:
                errors.append(f"papers/{n:03d}.md: topics_invoked='{subject}' "
                              f"but topic's applies_to does not include #{n}")

    # Reverse: each topic's applies_to must be invoked by listed papers
    for subject, papers_set in topic_to_papers.items():
        for n in papers_set:
            if n not in paper_to_topics:
                errors.append(f"topics/{subject}/: applies_to includes nonexistent paper #{n}")
            elif subject not in paper_to_topics[n]:
                errors.append(f"topics/{subject}/: applies_to includes #{n} "
                              f"but paper's topics_invoked does not list '{subject}'")

    # 3. example_readings papers must be in applies_to
    for (subject, layer), fm in topics_data.items():
        applies = set(fm.get("applies_to") or [])
        for er in fm.get("example_readings") or []:
            if isinstance(er, dict):
                p = er.get("paper")
                if p is not None and p not in applies:
                    errors.append(f"topics/{subject}/{layer}.md: example_readings "
                                  f"includes #{p} but applies_to does not")


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="context", help="Path to context/ root")
    args = parser.parse_args()

    root = Path(args.root)
    papers_dir = root / "papers"
    topics_dir = root / "topics"

    if not papers_dir.is_dir():
        print(f"ERROR: {papers_dir} not found")
        sys.exit(1)

    errors = []

    # Validate papers
    papers_data = {}
    for p in sorted(papers_dir.glob("*.md")):
        if not p.stem.isdigit():
            continue
        fm = extract_frontmatter(p)
        validate_paper(p, fm, errors)
        if fm and "_yaml_error" not in fm and "number" in fm:
            papers_data[fm["number"]] = fm

    # Validate topics
    topics_data = {}
    if topics_dir.is_dir():
        for t in sorted(topics_dir.rglob("*.md")):
            if t.name == "README.md":
                continue
            fm = extract_frontmatter(t)
            validate_topic(t, fm, errors)
            if fm and "_yaml_error" not in fm:
                key = (fm.get("subject"), fm.get("layer"))
                topics_data[key] = fm

    # Cross-validate
    cross_validate(papers_data, topics_data, errors)

    # Report
    if errors:
        print(f"\n=== {len(errors)} validation error(s) ===\n")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print(f"OK: {len(papers_data)} paper(s), {len(topics_data)} topic file(s) "
              f"validated successfully")
        sys.exit(0)


if __name__ == "__main__":
    main()
