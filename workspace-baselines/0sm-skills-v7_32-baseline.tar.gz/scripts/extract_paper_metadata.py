#!/usr/bin/env python3
"""
extract_paper_metadata.py

Migrates papers from the legacy structure (01/-07/ group folders +
top-level index.md) to the new context/papers/NNN.md format.

For each paper found in legacy index.md, produces a draft
context/papers/NNN.md file with:
  - Pre-filled frontmatter from index.md (number, title, date, DOI)
  - Pre-filled provenance (viXra ID if present)
  - Best-effort body content extracted from NN/papers.md if found
  - Empty arrays for fields requiring human curation
  - TODO markers for required human decisions

The human reviewer then fills in:
  - type / subtype (default: 'research', adjust as needed)
  - is_foundational (default: false, set true for #1 etc.)
  - relation.* (companion_to, supplements, corrects, continues, requires)
  - threads (which C-* threads this paper belongs to)
  - topics_invoked (which interpretive lenses to apply)
  - analogies_first / equations_first / concepts_first
    (extracted from body if marked, else manual)
  - opens_tasks / closes_tasks
  - corrections_made
  - predictions

Usage:
  python extract_paper_metadata.py \\
      --legacy-root path/to/0sm-skills-old/ \\
      --output-dir context/papers/ \\
      [--paper N]   # extract just one paper, e.g. --paper 28
      [--dry-run]   # print what would be written, don't write

Format assumptions about legacy index.md:

  Each paper is delimited by one of these patterns:
    - "## Paper #N: Title"  or  "### #N. Title"
    - "Date: YYYY-MM-DD" or similar nearby
    - "DOI: 10.5281/zenodo.XXXXX" or "doi.org/10.5281/zenodo.XXXXX"
    - "viXra:NNNN.NNNN" (optional)

  These patterns are matched flexibly. Adjust REGEXES below if
  legacy index.md uses different conventions.
"""

import argparse
import re
import sys
from collections import OrderedDict
from pathlib import Path


# ============================================================
# Legacy format regexes (adjust to actual legacy format)
# ============================================================

# Paper section headers in index.md
PAPER_HEADER_RES = [
    re.compile(r"^##+\s+(?:Paper\s*)?#?(\d+)[:.\s]+(.*?)$", re.MULTILINE),
    re.compile(r"^##+\s+(\d+)\.\s+(.*?)$", re.MULTILINE),
]

# DOI extraction
DOI_RE = re.compile(r"10\.5281/zenodo\.(\d+)")

# viXra ID extraction
VIXRA_RE = re.compile(r"viXra:?\s*(\d{4}\.\d{4}(?:v\d+)?)", re.IGNORECASE)

# Date extraction (YYYY-MM-DD or YYYY-MM or YYYY/MM)
DATE_RE = re.compile(r"(\d{4})[-/](\d{1,2})(?:[-/](\d{1,2}))?")

# Group folder mapping by paper number
def get_group_folder(n):
    """Map paper number → group folder name (01-07 in legacy structure)."""
    if 1 <= n <= 10:
        return "01"
    if 11 <= n <= 20:
        return "02"
    if 21 <= n <= 30:
        return "03"
    if 31 <= n <= 40:
        return "04"
    if 41 <= n <= 47:
        return "05"
    # 06 was a ghost folder; #48+ went to 07
    if 48 <= n:
        return "07"
    return None


# ============================================================
# Parse legacy index.md
# ============================================================

def parse_legacy_index(index_path):
    """Parse legacy index.md, return list of dict per paper."""
    text = index_path.read_text(encoding="utf-8")

    # Find all paper sections by header
    matches = []
    for pattern in PAPER_HEADER_RES:
        for m in pattern.finditer(text):
            matches.append((m.start(), int(m.group(1)), m.group(2).strip()))

    if not matches:
        print(f"WARNING: no paper sections found in {index_path}. "
              "Check PAPER_HEADER_RES patterns.")
        return []

    # Sort by position, dedupe by number (first occurrence wins)
    matches.sort()
    seen_nums = set()
    papers = []
    for i, (pos, num, title) in enumerate(matches):
        if num in seen_nums:
            continue
        seen_nums.add(num)
        # Section content = from this header to next header
        end = matches[i + 1][0] if i + 1 < len(matches) else len(text)
        section = text[pos:end]

        paper = {
            "number": num,
            "title": title,
            "date": None,
            "doi": None,
            "vixra_id": None,
            "section_text": section,
        }

        # Extract DOI
        doi_m = DOI_RE.search(section)
        if doi_m:
            paper["doi"] = f"10.5281/zenodo.{doi_m.group(1)}"

        # Extract viXra
        vixra_m = VIXRA_RE.search(section)
        if vixra_m:
            paper["vixra_id"] = vixra_m.group(1)

        # Extract date
        date_m = DATE_RE.search(section)
        if date_m:
            year = date_m.group(1)
            month = date_m.group(2).zfill(2)
            day = date_m.group(3)
            if day:
                paper["date"] = f"{year}-{month}-{day.zfill(2)}"
            else:
                paper["date"] = f"{year}-{month}"

        papers.append(paper)

    return papers


def extract_paper_body_from_group(legacy_root, num):
    """Try to extract paper body text from NN/papers.md.

    Looks for a section header matching the paper number in the
    appropriate group folder. Returns body text or empty string.
    """
    group = get_group_folder(num)
    if not group:
        return ""
    group_papers_md = legacy_root / group / "papers.md"
    if not group_papers_md.is_file():
        return ""

    text = group_papers_md.read_text(encoding="utf-8")

    # Find paper section
    for pattern in PAPER_HEADER_RES:
        for m in pattern.finditer(text):
            if int(m.group(1)) == num:
                start = m.end()
                # Find next paper header to determine end
                rest = text[start:]
                next_match = None
                for p2 in PAPER_HEADER_RES:
                    m2 = p2.search(rest)
                    if m2 and (next_match is None or m2.start() < next_match):
                        next_match = m2.start()
                if next_match is not None:
                    return rest[:next_match].strip()
                return rest.strip()

    return ""


# ============================================================
# Generate new-format draft file
# ============================================================

def render_draft(paper, body_text):
    """Render the new context/papers/NNN.md draft."""
    n = paper["number"]
    title = paper["title"]
    date = paper["date"] or "TODO"
    doi = paper["doi"] or "TODO"
    vixra = paper["vixra_id"]

    fm_lines = []
    fm_lines.append("---")
    fm_lines.append("# === 識別情報 ===")
    fm_lines.append(f"number: {n}")
    fm_lines.append(f'title: "{title}"')
    fm_lines.append(f"date: {date}")
    fm_lines.append(f"doi: {doi}")
    fm_lines.append("")
    fm_lines.append("# === 型分類（HUMAN: 確認・修正） ===")
    fm_lines.append("type: research        # research|supplement|clarification|synthesis|correction|note")
    fm_lines.append("subtype: null         # see v3 spec for valid subtypes per type")
    fm_lines.append("is_foundational: false  # set true for #1, etc.")
    fm_lines.append("")
    fm_lines.append("# === 関係グラフ（HUMAN: 既存 README/index から記入） ===")
    fm_lines.append("relation:")
    fm_lines.append("  companion_to: null")
    fm_lines.append("  supplements: []")
    fm_lines.append("  corrects: null")
    fm_lines.append("  continues: []")
    fm_lines.append("  requires: []")
    fm_lines.append("  references: []")
    fm_lines.append("")
    fm_lines.append("# === 由来情報 ===")
    fm_lines.append("provenance:")
    if vixra:
        fm_lines.append(f'  vixra_id: "{vixra}"')
        fm_lines.append("  vixra_archived: true")
    else:
        fm_lines.append("  vixra_id: null")
        fm_lines.append("  vixra_archived: false")
    fm_lines.append("")
    fm_lines.append("# === スレッド帰属（HUMAN: global-concept.md C-* から選択） ===")
    fm_lines.append("threads: []")
    fm_lines.append("")
    fm_lines.append("# === topics 呼び出し（HUMAN: 該当する解釈レンズを列挙） ===")
    fm_lines.append("topics_invoked: []")
    fm_lines.append("")
    fm_lines.append("# === 初出メタデータ（HUMAN: 本文から抽出） ===")
    fm_lines.append("analogies_first: []")
    fm_lines.append("equations_first: []")
    fm_lines.append("concepts_first: []")
    fm_lines.append("")
    fm_lines.append("# === タスク管理（HUMAN: 既存記述から移植） ===")
    fm_lines.append("opens_tasks: []")
    fm_lines.append("closes_tasks: []")
    fm_lines.append("corrections_made: []")
    fm_lines.append("")
    fm_lines.append("# === 実験予測 ===")
    fm_lines.append("predictions: []")
    fm_lines.append("---")

    out = []
    out.extend(fm_lines)
    out.append("")
    out.append(f"# Paper #{n}: {title}")
    out.append("")

    if body_text:
        out.append("<!-- AUTO-EXTRACTED FROM LEGACY NN/papers.md -->")
        out.append("<!-- Review and clean up. Move structured data to frontmatter. -->")
        out.append("")
        out.append(body_text)
    else:
        out.append("<!-- TODO: paste body content (Core Concept, Key Equations, "
                   "Key Results, etc.) -->")
        out.append("")
        out.append("## Core Concept")
        out.append("")
        out.append("TODO")

    out.append("")
    return "\n".join(out)


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--legacy-root", required=True,
                        help="Path to legacy 0sm-skills checkout root")
    parser.add_argument("--output-dir", default="context/papers",
                        help="Output directory for new papers/NNN.md files")
    parser.add_argument("--paper", type=int, default=None,
                        help="Extract only this paper number")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would be written without writing")
    parser.add_argument("--overwrite", action="store_true",
                        help="Overwrite existing files (default: skip)")
    args = parser.parse_args()

    legacy_root = Path(args.legacy_root)
    if not legacy_root.is_dir():
        print(f"ERROR: legacy root {legacy_root} not found")
        sys.exit(1)

    legacy_index = legacy_root / "index.md"
    if not legacy_index.is_file():
        print(f"ERROR: legacy index.md not found at {legacy_index}")
        sys.exit(1)

    output_dir = Path(args.output_dir)
    if not args.dry_run:
        output_dir.mkdir(parents=True, exist_ok=True)

    papers = parse_legacy_index(legacy_index)
    print(f"Parsed {len(papers)} papers from {legacy_index}")

    if args.paper is not None:
        papers = [p for p in papers if p["number"] == args.paper]
        if not papers:
            print(f"ERROR: paper #{args.paper} not found in legacy index")
            sys.exit(1)

    n_written = 0
    n_skipped = 0
    for paper in papers:
        n = paper["number"]
        out_path = output_dir / f"{n:03d}.md"

        if out_path.exists() and not args.overwrite:
            print(f"  SKIP #{n}: {out_path} exists (use --overwrite to replace)")
            n_skipped += 1
            continue

        body = extract_paper_body_from_group(legacy_root, n)
        content = render_draft(paper, body)

        if args.dry_run:
            print(f"  DRY-RUN #{n}: would write {out_path} "
                  f"({len(content)} chars, body: {len(body)} chars)")
        else:
            out_path.write_text(content, encoding="utf-8")
            print(f"  WROTE #{n}: {out_path} "
                  f"({len(content)} chars, body: {len(body)} chars)")
            n_written += 1

    print(f"\nSummary: {n_written} written, {n_skipped} skipped, "
          f"{len(papers) - n_written - n_skipped} other")


if __name__ == "__main__":
    main()
