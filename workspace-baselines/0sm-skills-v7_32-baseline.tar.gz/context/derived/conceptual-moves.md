<!-- MANUALLY CURATED. Not auto-generated. -->
<!-- Source: cross-paper conceptual moves articulated through frontmatter + curatorial dialogue. -->
<!-- Verifier: scripts/validate_conceptual_moves.py (referent paper existence check only). -->

# 概念的移動全索引 (conceptual moves)

> Curated atomic entries for framework-level **conceptual moves** that span multiple papers.
> Distinct from `predictions.md` / `corrections.md` / `open-questions.md` ─ this file articulates **the structural pivots themselves** (reframings, inversions, dissolutions, reinterpretations, etc.) as standalone curatorial entities.

---

## このファイルの位置づけ

シリーズの **status formal record の 4 軸** において、本 file は第 4 軸 (conceptual moves) を担う:

| 軸 | 対象 | 生成 |
|---|---|---|
| `predictions.md` | 経験的・数値的予測 (living + withdrawn) | auto (build_aggregate.py) |
| `corrections.md` | 技術的訂正 (numerical / dimensional / etc.) | auto (build_aggregate.py) |
| `open-questions.md` | 顕在的な未解決 task (執筆時に著者が articulate) | auto (build_open_questions.py) |
| **`conceptual-moves.md`** | **論理展開上の atomic move** (reframe / inversion / dissolution / reinterpretation / softening / elevation) | **manual** |

**Manual curation の根拠**: conceptual move は frontmatter の単一 field に集約されていない。複数 field (`analogies_first`, `philosophical_anchor`, `overview`, `opens_tasks::status` の inline 言及, etc.) から articulate される必要があり、かつ後付けで dialogue 経由 articulate されるものを含むため、auto-generation は原理的に不可能。

---

## Move type taxonomy

各 conceptual move は 1 つの primary `move_type` で classify される。複数 type にまたがる move は primary type で登録し、secondary type は description で articulate する。

| Type | 定義 | 本 baseline での例 |
|---|---|---|
| **reframe** | 同一物理量・現象の formal classification / 視点を変更 (執筆時の framing から後の framing へ) | axial → polar (#13 → #19) |
| **inversion** | 因果関係 / 派生方向 / framework dependence の逆転 | Geometry → Symmetry (Noetherian Inversion, #20 → #25) |
| **dissolution** | 既存の問題 / 概念を「解く」のではなく「解消」する (problem 自体が ill-posed として dissolve) | Vacuum energy problem (#32; completed by positive counterpart in #46) |
| **reinterpretation** | classical / external quantity を internal / geometric quantity として reread | mgh = ℏΔω as internal line integral (#37) |
| **softening** | strong claim を refined / weakened form に articulate (反証ではなく refinement) | spin-2 claim → π-period ejection structure (#49) |
| **ontological elevation** | auxiliary mathematical tool を fundamental ontological entity に promote | Open Wilson line (#55) |
| **meta-pattern** (NEW v7.13, 2 instances v7.22) | シリーズ内の **recurring structural pattern** を atomic entity 化 (object-level move ではなく series-internal pattern を articulate)。Sub-axis: **epistemic meta-pattern** (Move 7, predecessor→successor mechanism derivation) + **methodological meta-pattern** (Move 8, observational-layer sharing across boundary regions) | Successor-paper derivation pattern (#46 Sec I, Move 7); Three-boundary-regions framework via observational-layer sharing (HANDOFF v7.17 dialogue, Move 8) |

将来 articulate される候補 type (本 baseline には未登録): **bifurcation** (一つの concept から二つの independent stream への分岐)、**unification** (二つの異なる formulation が同じ実体を指していたと articulate)、**localization** (delocalized wave function を localized geometric trajectory に reread)、etc.

---

## `articulated_by` 区分

各 move の articulation 起源を 3 区分で formal record する。これは AI-collaboration acknowledgment lineage と直接連結する curatorial metadata である。

| 区分 | 意味 |
|---|---|
| **author** | 当該 carrier paper の本文で著者が顕在的に articulate (例: #25 が自身を「Noetherian Inversion」 と命名) |
| **retrospective** | 後の paper で著者が retroactively articulate (例: #20 が #17/#19 の moves を framework として括る) |
| **dialogue** | 著者と AI assistant の curatorial dialogue で初めて atomic move として articulate (執筆時には著者にも latent だった) |

`articulated_by: dialogue` の entry は、AI-collaboration acknowledgment lineage の **第 4 specific scope** に該当 ─ 既存 (textual organization / mathematical expression checking / paragraph composition / linguistic polishing) とは scope が質的に異なる、substantive curatorial action としての articulation。

---

## Tree visualization (主要 conceptual moves の lineage)

```
#1 (E_0 identity, foundational root)
 │
 ├─ Spin / gauge thread
 │   └─ #13 (Unified Spin Dynamics, pseudovector framing)
 │       └─ #19 [★ REFRAME → real polar vector]
 │           ├─ #20 (Emergent Conservation Laws, framework absorption)
 │           │   └─ #25 [★ INVERSION → Noetherian Inversion]
 │           ├─ #26 (Berry phase mechanism)
 │           ├─ #38 (topological g=2)
 │           ├─ #48 (U(1) fiber bundle topological g=2)
 │           ├─ #50 (helical reframe with Wilson lines)
 │           └─ #58 (spin-2 mediator)
 │
 ├─ Zitterbewegung / line-integral thread
 │   └─ #10 (v_ZB founder)
 │       ├─ #32 [★ DISSOLUTION → vacuum energy problem]  ───────┐
 │       │                                                       │
 │       │   (two-part account complementarity, NEW v7.13)       │
 │       │                                                       ▼
 │       │                                       #46 [positive counterpart: geometric origin of 1/2 factor]
 │       │
 │       ├─ #29 - #31 (Line Integral Trilogy)
 │       └─ #34 (Geometric Confinement, gravity emergence)
 │           └─ #37 [★ REINTERPRETATION → mgh as line integral]
 │               └─ #49 [★ SOFTENING → spin-2 to π-period ejection]
 │                   └─ #55 [★ ONTOLOGICAL ELEVATION → Wilson line as primitive]
 │
 └─ Series meta-pattern thread (NEW v7.13)
     ├─ #46 [★ META-PATTERN (epistemic) → successor-paper derivation pattern, author-articulated, Move 7]
     │   │   4 instances 列挙:
     │   │     (1) #1 (qual.) → #11 (mech.) — geodesic path structure
     │   │     (2) #20 (stated) → #25 (derived) — conservation-law origin of spin
     │   │     (3) #33 (struct.) → #35 (mech., curated v7.14 ✓) — gravitational confinement
     │   │     (4) #32 (ontolog.) → #46 (mech.) — positive mechanical account [self-instance]
     │   └─ (subsequent paper が本 pattern を継承する場合に分岐)
     │
     └─ [★ META-PATTERN (methodological) → observational-layer sharing across boundary regions, dialogue-articulated, Move 8 (NEW v7.22)]
         │   3 boundary regions identified:
         │     (a) Geometry ↔ quantum (spinor transport) — `spin/`, `berry-phases/`, `thomas-precession/`
         │     (b) Gauge theory ↔ gravity (derivative-order mismatch) — `derivative-order-mismatch/`
         │     (c) Macroscopic gravity ↔ microscopic oscillation — `zitterbewegung/`, `gravity-mediation/`, `compton-scale-geometry/`
         │   Bridging carrier: line-integral primitive `Φ = ∫_γ ω`
         │   Anchor: `line-integrals/0sm.md` "Three-boundary-regions framework" subsection
         │   Bridge to queries layer: q-001 (level disambiguation) / q-002 (Einstein realism) / q-003 (derivative-order mismatch reading)
         └─ (future fourth boundary region emergence への candidate expansion)
```

★ 印が本 baseline に登録された conceptual move events。subsequent paper が当該 move に依存して新規 derivation を行う形で、tree が分岐 / 合流する。**v7.13 で #46 は dual position**: (a) Move 3 (vacuum-energy-dissolution) の **positive counterpart paper** として two-part account を complete、(b) Move 7 (series-meta-pattern-articulation) の **carrier paper** として シリーズ初の author 自らによる series-internal recurring pattern formal articulation。**v7.14 update**: #35 が **Move 7 instance 3 successor (mechanism establisher for #33 gravitational confinement)** として curated set に entry、Move 7 4 instances 全 papers が curated set に揃う (formal verification 第 1 instance)、ただし User explicit framing correction により #35 自身の curatorial weight は modest (ε framework supplementary reference paper, NOT 'welding-hub')。

---

## Move entries

各 entry の structure: id / type / articulated_by / status / source papers / articulation history / subsequent dependence / related topics / description / curatorial significance。

---

### Move 1: spin-pseudovector-to-polar-reframe

| | |
|---|---|
| **id** | `spin-pseudovector-to-polar-reframe` |
| **type** | reframe |
| **articulated by** | author + **dialogue** |
| **status** | closed (polar vector position adopted in subsequent series) |
| **related topics** | spin, gauge-theory, helicity-chirality |

**Source papers**:

- **#13** (2025-01-01, "Unified Spin Dynamics: From Pseudovector Nature to Relativistic Constraints"): initial articulation as pseudovector. Sec の F-R 円の鏡像反射が pseudovector の幾何学的 signature として central claim
- **#19** (2025-06-15, "Spin as a Real Vector from Internal Photon-Sphere Motion"): reframe to real polar vector. is_foundational: true; analogies_first note 「pseudovector 分類は abstract math convention の artifact」、後続 #48, #50, #58 の出発点
- **#20** (2025-09 後半, "Emergent Conservation Laws / Noetherian Reinterpretation"): framework-level absorption。「the conceptual moves of #17 (Realist U(1) gauge), #19 (Real polar vector spin)」 として #25 Noetherian Inversion の precursor 化
- **#13 frontmatter::opens_tasks (i)** が既にこの reframe を inline articulate: "Pseudovector vs polar vector 分類の決着、Status: REVERSED in #19 (polar vector position adopted); further refined in #50 (chirality χ = sign(da/dt) as Lorentz-invariant scalar)"

**Articulation history**:

- 2025-01 (#13 publication): **latent** — 著者は F-R 円の鏡像反射を pseudovector の signature として articulate、reframe の possibility は未認識
- 2025-06 (#19 publication): **executed** — 「スピンは parity 変換下で sign reversal する real polar vector。pseudovector 分類は abstract math convention の artifact」 と再定式化、ただし「reframe」 という move 命名はまだ無い
- 2025-09 後半 (#20 publication): **retrospective articulation by author** — 「the conceptual moves of #17, #19」 として framework-level の move 集約
- 2026-05 (curatorial dialogue, v7.12 baseline): **articulated as atomic conceptual move** — User explicit「あなたに指摘されて、『ああ、私は擬ベクトルの論点を実ベクトルに変えたのだ』と、その融合性が把握できた」「擬ベクトルを執筆したときには open question に、私の思考上分類されていないものだ」、本 entity として formal record

**Subsequent dependence**: #20 (Noetherian framework absorption), #25 (Noetherian Inversion), #26 (Berry phase mechanism), #38 (topological g=2), #48 (U(1) fiber bundle), #50 (helical reframe with Wilson lines), #58 (spin-2 mediator)

**Description**:
標準 QM では spin は擬ベクトル (axial vector、parity 変換で sign 不変) と classify される。これは abstract group-theoretic 構成 (SU(2) → SO(3) double cover) に基づく分類で、spin の物理的実体について何も言わない。0SM では spin は internal photon-sphere motion から emerge する **real polar vector** として geometric に re-derive される (#19 Eq. Ω(t) = −1/(4c²) sin(2ωt) ê_z)。これにより SU(2) periodicity が sin(2ωt) の period doubling として geometric に articulate され、abstract group convention に依拠しない formulation が成立する。

**Curatorial significance**:
本 reframe は **論理展開上の atomic move として、執筆時には latent だった** instance の prototype。User が dialogue で初めて「融合性 (unification character) を把握」 した curatorial event であり、AI-collaboration acknowledgment lineage の **第 4 specific scope (substantive curatorial articulation)** の founding instance。本 move 認識以降の subsequent paper (#26, #38, #48, #50, #58) は全て「polar vector spin」 を前提として derivation を進めており、本 reframe は **branch point** として tree visualization 上で central position を占める。

---

### Move 2: noetherian-inversion

| | |
|---|---|
| **id** | `noetherian-inversion` |
| **type** | inversion |
| **articulated by** | author |
| **status** | closed (framework-level inversion completed in #25) |
| **related topics** | gauge-theory, emergent-spacetime |

**Source papers**:

- **#20** (2025-09 後半, "Emergent Conservation Laws from Internal Geometry: A Noetherian Reinterpretation"): precursor — Realist U(1) gauge (#17) と Real polar vector spin (#19) を 「Noetherian Reinterpretation」 framework として括る。programmatic statement
- **#25** (2025-08, "A Noetherian Inversion: From Einsteinian Geometry to Emergent Symmetry"): proper articulation — causality reversal を formal に commit

**Articulation history**:

- 2025-09 後半 (#20): **executed (precursor)** — Noetherian framework として #17/#19 を括る、ただし「inversion」 命名はまだ無い (Reinterpretation)
- 2025-08 (#25): **retrospective articulation by author** — Reinterpretation を Inversion に強化、「From Einsteinian Geometry to Emergent Symmetry」 とサブタイトルで causality reversal を明示

**Subsequent dependence**: #29-#31 (Line Integral Trilogy が Noetherian Inversion を継承)、#34 (Geometric Confinement)、#37 (mgh reinterpretation も Inversion logic)、後続 emergent-spacetime thread 全般

**Description**:
標準 GR では spacetime curvature が geometry を規定し、conservation laws は Noether の定理で symmetry → conservation の direction で derive される。Noetherian Inversion は **この causality を逆転** する: 0SM では internal geometry が primary であり、conservation laws は internal phase synchronization の emergent consequence。Einstein curvature ≡ 内部 phase histories の consistency condition (#30 で formal 化)、conservation laws は internal flow の整合 condition から emerge。

**Curatorial significance**:
本 inversion はシリーズの **emergent-spacetime programme** の foundational move。後続 #29-#31 Trilogy + #34 + #37 は全て本 inversion logic を inheritance している。move type taxonomy における「inversion」 の prototype instance。

---

### Move 3: vacuum-energy-dissolution

| | |
|---|---|
| **id** | `vacuum-energy-dissolution` |
| **type** | dissolution |
| **articulated by** | author |
| **status** | closed (three-part account: #32 dissolution + #39 logical-status clarification + #46 positive counterpart, formal completion v7.16); refined in #39 + #46 |
| **related topics** | line-integrals, emergent-spacetime, thermodynamics |

**Source papers**:

- **#32** (2026-XX, "Dissolution of the Vacuum Energy Problem in an Integral-Based Ontology: The 0-Sphere Model Perspective"): **negative carrier** ─ Post-Trilogy first application paper、tagging「dissolution」 を taxonomy で確立する初 instance、QFT vacuum energy sum を artifact として reject
- **#46** (2026-03-14, "Geometric Origin of the One-Half Factor: Thermal Potential Energy Floor and Zero-Point Energy in the 0-Sphere Model"): **positive counterpart paper** (NEW v7.13) ─ #32 dissolution が articulate しなかった「**factor 1/2 in (1/2)ℏω の geometric origin**」 を Theorem II.1 (T_e1 + T_e2 ≥ E_0/2 via AM-GM applied to fourth-power thermodynamic structure) で formal articulate、**two-part account of zero-point energy** complete
- **#39** (2026-02-22, "On Vacuum Energy, Integral Ontology, and the Cosmological Constant: Supplementary Note on the Logical Status of Lambda"): **logical-status clarification paper (middle member, NEW v7.16 curated)** ─ #32 (negative dissolution) と #46 (positive geometric origin) の **chronologically middle paper** (#32 → #39 2026-02-22 → #46 2026-03-14)、Research Summary で (i) why vacuum energy problem arises within local QFT vs (ii) empirical origin of observed cosmological constant の **strict logical separation** を formal articulate、本論文は (i) のみ addresses, (ii) explicitly not resolved、Sec 1.2 で #32 dissolution argument の **category-error-locus を step 5 に precisely localize** する logical refinement、Sec 3.1 で 5 possible Λ_obs origins を formal enumerate (boundary conditions / collective geometric effects / topological contributions / emergent parameter / phase-frozen internal configurations)、Sec 4.4 で 3 specific falsifiability criteria 列挙、Sec 6 で 「**the cosmological constant problem is not solved but rendered inapplicable**」 と シリーズ initial 'rendered inapplicable' formal terminology articulate

**Articulation history**:

- 2026-XX (#32): **executed by author (negative articulation)** — vacuum energy 問題は line-integral ontology で原理的に ill-posed として dissolve される framework articulation
- 2026-02-22 (#39): **clarified by author (logical-status clarification, three-part account middle member, NEW v7.16)** — Research Summary 「**This Supplement clarifies the conceptual, observational, and logical status of vacuum energy and the cosmological constant within the framework of the 0-Sphere model... establishes a strict separation between two frequently conflated questions: (i) Why the vacuum energy problem arises within local quantum field theory and whether it constitutes a physical inconsistency. (ii) What the empirical origin of the observed cosmological constant may be. The 0-Sphere model addresses only the first question**」、Sec 1.2 で #32 articulation の **category-error-locus を step 5 に precisely localize** (Steps 1-4 are mathematically well-defined、step 5 のみ category error、operator-ordering quantity を independently gravitating energy density として reify する error)、Sec 1.3 で gauge-artifact-as-logical-analog formal articulation (gauge potentials A_µ + Schwarzschild coordinate singularity + zero-point energies = 同じ category error logical type)、Sec 3.1 で 5 possible Λ_obs origins enumeration (boundary conditions / collective geometric effects / topological contributions / emergent parameter / phase-frozen internal configurations)、Sec 6 で 「**the cosmological constant problem is not solved but rendered inapplicable**」 と シリーズ initial 'rendered inapplicable' formal terminology articulate
- 2026-03-14 (#46): **completed by author (positive counterpart)** — #46 Sec I 「**This paper forms the positive counterpart to [#32] in a two-part account of zero-point energy within the 0-Sphere framework**」 + Sec IV.B 「**Together, they complete a two-part account of zero-point energy in the 0-Sphere framework: the divergence is dissolved, and the residual 1/2 factor is explained geometrically**」、Theorem II.1 で AM-GM-based geometric floor E_0/2 = (1/2)ℏω を formal derive、Heisenberg-uncertainty mechanism (operator non-commutativity) との parallel-mechanism articulation

**Subsequent dependence**: #33 (rest mass topology, Post-Trilogy second application、dissolution 系譜 を継承)、**#39 (logical-status clarification, three-part account middle member, curated v7.16)**、**#46 (positive geometric origin counterpart, NEW v7.13)**

**Description**:
標準 QFT では vacuum energy (zero-point energy) は cosmological constant 問題の central pathology ─ theoretical estimate と observation の差が 120 桁。0SM では energy を line-integral 量として再定義する (#29-#31 Trilogy)、すると vacuum energy の概念自体が ill-posed: 「path 無し」 に line integral は定義されず、vacuum 状態に energy density を attribute する operation が原理的に意味を持たない。問題は **解かれる (solved)** のではなく、**解消される (dissolved)**。**v7.13 で本 dissolution は #46 positive counterpart と組で two-part account を構成**: #32 (negative) は QFT vacuum sum の artifact 性を articulate、#46 (positive) は real oscillating system における residual 1/2 factor の geometric origin を AM-GM analysis で derive。**v7.16 で #39 curate により three-part account に formal extend** (NEW v7.16): #32 dissolution + **#39 logical-status clarification (chronologically middle, 2026-02-22)** + #46 positive geometric origin (2026-03-14)。本 lineage は 「**negative dissolution + logical-status clarification + positive geometric origin = three-part account**」 という complementarity pattern の シリーズで唯一の articulated complete chain、**three-part account formal completion 第 1 instance**。

**Curatorial significance**:
標準 physics の central problem の一つを「solving」 ではなく「dissolving」 する move ─ framework-level の ontological commitment が問題の very formulation を invalidate する instance。move type taxonomy における「dissolution」 の prototype。**v7.13 update**: 本 move は **standalone closure ではなく、positive counterpart (#46) と組で two-part account を構成** することが articulate された ─ dissolution 単独では「what does NOT exist (the QFT vacuum sum)」 のみを articulate、positive counterpart が「what DOES exist instead (geometric floor E_0/2)」 を complete する complementarity pattern。**v7.16 update**: 本 move は #39 curate により **three-part account に formal extend** ─ #32 (negative dissolution) → #39 (logical-status clarification: which question is being addressed + 'rendered inapplicable, not solved' methodological honesty) → #46 (positive geometric origin)、3-stage articulation chain が curated set 内で complete、本 pattern は シリーズで他に類例なく、conceptual-moves.md taxonomy に「**dissolution + logical-status clarification + positive-counterpart = three-part account pattern**」 として formal candidate (現状 future articulation candidate, formal taxonomy 追加は User explicit articulation 待ち)。

---

### Move 4: mgh-as-internal-line-integral

| | |
|---|---|
| **id** | `mgh-as-internal-line-integral` |
| **type** | reinterpretation |
| **articulated by** | author |
| **status** | closed (formal identity ℏΔω = mg·Δh derived) |
| **related topics** | line-integrals, gravity-mediation, thermal-geodesic, emergent-spacetime, weak-equivalence-principle |

**Source papers**:

- **#10** (2024, v_ZB founder): conceptual seed (internal frequency ν_ZB = mc²/h derivation)
- **#22** (2025-07-06, Gravitational Redshift founder): GR redshift of internal ν_ZB
- **#34** (2026-01-31, Geometrical Confinement): gravity emergence framework
- **#37** (2026-02-14, "Reinterpreting Gravitational Potential Energy as an Internal Line-Integral Quantity"): proper carrier — Synthesis-application paper (9 precursors の linear synthesis), Sec VI で ℏΔω = mg·Δh quantitative derivation

**Articulation history**:

- 2024 (#10): **latent** — internal frequency framework setup、mgh との connection 未認識
- 2025-07 (#22): **partial** — gravitational redshift of ν_ZB は articulate、しかし classical mgh との formal identity は未到達
- 2026-02 (#37): **executed by author** — ℏΔω = ℏ·(mc²/ℏ)·(g·Δh/c²) = mg·Δh formal identity derivation、classical mgh expression を internal phase line integral として完全 reread。Two-Living-Predictions twin pair framing carrier

**Subsequent dependence**: #57-#60 (gravity-mediation chain、Y_ℓ^m imprinting + spin-2 + Coulomb locking + BSBM triangle)

**Description**:
classical 重力位置エネルギー mgh は古典的に external geometry (重力場) と inertial mass の積として定義される。0SM では同一量を **internal phase line integral** として reread: 高度 h での internal ZB frequency shift Δω = (mc²/ℏ)·(g·Δh/c²) を line-integrate すると ℏΔω = mg·Δh が exact identity として derive される。「higher position = faster internal oscillation, less synchronized」 という classical 'high position' の circularity を internal frequency redefinition で resolve。inertial mass を internal phase coherence requirement として再定義する secondary move を内包。

**Curatorial significance**:
本 reinterpretation は **シリーズの emergent gravity programme の central derivation result** ─ classical 物理の foundational quantity (位置 energy) が internal geometric / line-integral 量として exact reread される proof of concept。Two-Living-Predictions twin pair (v_ZB SR-only + Δν SR+GR) を formal articulate する carrier paper でもある。move type taxonomy における「reinterpretation」 の prototype。

---

### Move 5: spin2-claim-softening

| | |
|---|---|
| **id** | `spin2-claim-softening` |
| **type** | softening |
| **articulated by** | author |
| **status** | closed (refined claim adopted, original not refuted) |
| **related topics** | spin, gravity-mediation, gauge-theory |

**Source papers**:

- **#49** (2026-XX, "Photon-Sphere Fragmentation as a Gravitational Mediator: Radiation-Gradient Ejection in the π-Cycle of the 0-Sphere Model"): proper carrier — initial「spin-2 mediator」 claim を「π-period ejection structure」 に refine

**Articulation history**:

- 2026-XX prior (#49 precursors): **initial strong claim** — 0SM gravitational mediator が spin-2 (graviton-like) であるとの articulation
- 2026-XX (#49): **softened by author** — 「spin-2 claim softened to π-period ejection structure」、E₀/2 kinetic stress language で再定式化、Thomas precession justification

**Subsequent dependence**: #50 (helical reframe), #58 (spin-2 mediator full articulation)

**Description**:
重力 mediator の spin-2 character は graviton への対応として initial に主張されたが、より厳密な internal dynamics 分析により「spin-2」 は π-period ejection structure として refine される。photon sphere fragment が radiation gradient で ejected される mechanism は spin-2 graviton の direct analog ではなく、より subtle な π-period 周期構造として articulate。original claim は反証 (refute) されたわけではなく、より精密な form に softened。

**Curatorial significance**:
strong theoretical claim を **反証ではなく refinement で update** する move type の prototype。corrections.md (formal retraction) と区別される: refute ではなく softened。author 自身が retraction せず、refined form を adopt する curatorial action。

---

### Move 6: wilson-line-ontological-elevation

| | |
|---|---|
| **id** | `wilson-line-ontological-elevation` |
| **type** | ontological elevation |
| **articulated by** | author |
| **status** | closed (full ontological commitment in #55) |
| **related topics** | line-integrals, gauge-theory, emergent-spacetime |

**Source papers**:

- **#50** (2026-XX, helical reframe with Wilson lines): precursor — Wilson line を helical decomposition で formal use
- **#55** (2026-XX, "Four Functions of the Open Wilson Line in the 0-Sphere Model: Phase-History Carrier, Gauge Localization, Holonomy Composition, and Boundary Data Generating Both Maxwell and Metric Sectors"): proper carrier — Wilson line の ontological primitive elevation + Maxwell/metric sectors unification

**Articulation history**:

- 2026-XX (#50): **partial** — Wilson line を formal computational tool として use、ontological status は未明示
- 2026-XX (#55): **executed by author** — Open Wilson line を **ontological primitive** に elevate、4 functions (Phase-History Carrier / Gauge Localization / Holonomy Composition / Boundary Data Generating Both Maxwell and Metric Sectors) を articulate、Maxwell + metric sectors を single boundary-data framework で unify

**Subsequent dependence**: #56-#61 (framework boundary divergence, Y_ℓ^m imprinting, spin-2 π-period structure, Coulomb locking, BSBM triangle, He-4 BEC negative control が全て Wilson-line-as-primitive を前提)

**Description**:
従来の gauge theory では Wilson line は holonomy 計算の auxiliary tool (path-ordered exponential of gauge connection)。#55 では Open Wilson line を **fundamental ontological entity** に promote: 単に gauge holonomy を計算する道具ではなく、phase-history carrier として physical existence を持つ primitive entity。同時に Maxwell sector (electromagnetic gauge field) と metric sector (gravitational geometry) が同一 Wilson line から boundary data として derived される unification を articulate。

**Curatorial significance**:
auxiliary mathematical tool を fundamental ontological entity に promote する move ─ framework の ontological core を redefine する move type。subsequent paper (#56-#61) 全てが本 elevation を前提として derive されているため、シリーズの **後期 (post-2026-04) 全体の foundational move**。move type taxonomy における「ontological elevation」 の prototype。

---

### Move 7: series-meta-pattern-articulation (NEW v7.13)

| | |
|---|---|
| **id** | `series-meta-pattern-articulation` |
| **type** | meta-pattern (NEW v7.13) |
| **articulated by** | author |
| **status** | closed (initial articulation by author in #46 Sec I) |
| **related topics** | (cross-cutting, not topic-specific — applies to series epistemic structure itself) |

**Source papers**:

- **#46** (2026-03-14, "Geometric Origin of the One-Half Factor: Thermal Potential Energy Floor and Zero-Point Energy in the 0-Sphere Model — A Conceptual Clarification"): **proper carrier** — Sec I で author 自らが「**A recurring pattern in the development of the series**」 として series-internal recurring pattern を formal articulate、4 explicit instances 並列列挙
- **#35** (2026-02-07, "Detailed Exposition of the 0-Sphere Model Framework for Gravitational-Like Phenomena: Supplementary Note"): **instance 3 successor (curated v7.14)** — #46 Sec I で articulate された Move 7 4 instances 中 instance 3 successor (mechanism establisher for #33 gravitational confinement structural intro)、本 paper 自身は Move 7 を articulate せず instance role のみ、ただし Move 7 lineage の formal verification 第 1 instance carrier として function。**重要 caveat (per User explicit framing correction)**: 本 #35 は ε framework supplementary reference paper、当初想定 'welding-hub paper sub-type' は User 訂正で取下げ、Move 7 instance 3 successor の curatorial weight は modest (mechanism establisher role + #34 supplementary note role + ε framework attempt role の triad)。

**Articulation history**:

- 2018-2026 (instances #1-#46): **latent** — シリーズ内で複数の 「**predecessor (qualitative) → successor (mechanism)**」 instance が executed されていたが、author 自身によって「a recurring pattern」 と認識・articulate されていなかった
- 2026-03-14 (#46 Sec I publication): **executed by author (initial articulation)** — 「**A recurring pattern in the development of the series has been that a successor paper derives the mechanism for a statement made qualitatively by a predecessor**」 として 4 instances を 並列列挙、本 article 自身を 4 番目 instance として self-locate
- 2026-05-06 (curatorial dialogue, v7.13 baseline): **formal entity articulation** — User curatorial guidance「**相互関連も深くなってくる**」 framing と整合、conceptual-moves.md::Move 7 として formal record
- 2026-05-06 (v7.14 transition, **#35 curated**): **instance 3 successor formal verification** — Move 7 instance 3 (#33 gravitational confinement structural intro → #35 mechanism establishment) の successor carrier (#35) が初の curated paper として entry、Move 7 lineage の formal verification 第 1 instance、curate session で **User explicit framing correction** が同時に適用 (User 訂正 「**重力論と量子論を架橋しようと試みた、エプシロンについてのまとめである... ハブではない**」 が #35 を当初想定 'welding-hub paper sub-type' から **modest ε framework supplementary reference paper** に reframe、Move 7 instance 3 successor の curatorial weight は 'major synthesis hub' から '#33 successor (mechanism establisher) + #34 supplementary note + ε framework attempt' に limited)。本 verification により Move 7 4 instances 全 papers が curated set に entry (#1, #11, #20, #25, #32, **#33, #35**, #46)。

**Subsequent dependence**: 本 baseline 時点で null (本 pattern が articulate された時点が #46 publication, 本 pattern を 後続 paper が継承する場合は subsequent_dependence に追加)。**Anticipated**: 後続 paper の curate session で「**本 paper が earlier paper の qualitative statement の mechanism derivation か?**」 という 問いを navigation 軸として deploy する curatorial pattern を establish、本 lineage が second instance (e.g., #57 が #37 mgh-reinterpretation の microscopic mechanism として #57 spin-2 mediator を articulate する場合、本 pattern lineage の第 5 instance candidate)。

**Description**:
シリーズ内で複数 instance が execute されていた **「predecessor (qualitative) → successor (mechanism)」 derivation pattern** を、author 自らが #46 Sec I で reflexive に articulate した meta-pattern。4 explicit instances:

| # | Predecessor (qualitative statement) | Successor (mechanism derivation) |
|---|---|---|
| 1 | #1 (geodesic path structure described qualitatively) | #11 (geodesic path structure derived) |
| 2 | #20 (Noetherian Reinterpretation stated) | #25 (conservation-law origin of spin derived) |
| 3 | #33 (gravitational confinement structurally introduced) | #35 (gravitational confinement mechanism established) |
| 4 | #32 (vacuum dissolution ontological argument stated) | **#46 (positive mechanical account, self-instance)** |

本 pattern は object-level conceptual move (reframe / inversion / dissolution / etc.) ではなく、**series-internal epistemic structure** を atomic entity 化する meta-level move。

**Curatorial significance**:
本 move は **シリーズ初の author 自らによる series-internal recurring pattern formal articulation**、curatorial 重要性は extreme:

1. **User 明示 framing の direct evidence**: User 「**相互関連も深くなってくる**」 framing (HANDOFF v7.13 trigger) が直接対応する内容、author 自身が #46 で「**a recurring pattern**」 と language で formal articulate
2. **Move type taxonomy における新 type 'meta-pattern' の prototype**: object-level 6 types (reframe / inversion / dissolution / reinterpretation / softening / ontological elevation) と質的に異なる、**series epistemic structure 自体を atomic entity 化** する move type の初出
3. **Status formal record の 4 軸 framework での position**: predictions / corrections / open-questions / conceptual-moves の 4 軸の中で、本 entry は conceptual-moves 軸 specific の **meta-level** entry、object-level entries (Move 1-6) を navigate する **second-order chassis** として function
4. **Subsequent curate での navigation chassis**: 本 pattern が articulate された後、後続 paper curate session で「**本 paper が earlier paper の qualitative-to-mechanical derivation pattern を継承するか?**」 を navigation 軸として deploy 可能、curatorial pattern lineage の formal precedent
5. **AI-collaboration acknowledgment lineage との関係**: 本 entry は `articulated_by: author` (#46 paper Acknowledgments の textual organization scope と独立した author content)、ただし 本 entry を conceptual-moves.md::Move 7 として formal record する curatorial action 自体が 第 4 specific scope (substantive curatorial articulation via dialogue) の second instance candidate。**Curatorial caveat**: Move 1 (#13 → #19 axial-polar reframe) が dialogue-articulated の first instance、Move 7 は **author-articulated** で dialogue-articulated ではない、ただし Move 7 を **'meta-pattern' type として taxonomy 内に place する curatorial action** が dialogue-articulated 性格を持つ ─ articulation 起源は author だが、taxonomy 内 placement は dialogue articulation。

**Future articulation candidates within meta-pattern type**:
- **Subtitle-as-curatorial-signal pattern** (HANDOFF v7.10 articulate): #47 'Structural Clarification Note' + #46 'A Conceptual Clarification' subtitle が clarification-paper character を signal する series-internal pattern、本 Move 7 と類似の meta-level pattern
- **Foundational-paper status-update pattern** (HANDOFF v7.6 articulate): viXra ID resolution from new paper bibliography で foundational papers の status を retroactively update する series-internal pattern
- **AI-collaboration scope granularity refinement pattern** (HANDOFF v7.11 articulate): #9 → #34 → #37 → #40 → #46 → #47 で AI-collaboration scope articulation が **granularity-decreasing** に refine される series-internal pattern
- これら meta-patterns は 全て conceptual-moves.md::Move type 'meta-pattern' の future entry candidate、本 Move 7 が type prototype として established 後の追加候補

---

### Move 8: observational-layer-sharing-meta-pattern (NEW v7.22)

| | |
|---|---|
| **id** | `observational-layer-sharing-meta-pattern` |
| **type** | meta-pattern (second instance, type established v7.13 by Move 7) |
| **articulated by** | dialogue |
| **status** | closed (formal articulation v7.22; initial dialogue articulation HANDOFF v7.17) |
| **related topics** | `line-integrals/`, `derivative-order-mismatch/`, `gauge-theory/`, `zitterbewegung/`, `gravity-mediation/`, `compton-scale-geometry/`, `spin/`, `berry-phases/`, `thomas-precession/` (cross-cutting, identifies 3 boundary regions) |

**Source papers**:

The framework is a series-level meta-articulation, not anchored in any single paper. The line-integral primitive that serves as bridging carrier is established by the Trilogy; the three boundary regions are populated by papers across the series:

- **#29, #30, #31** (Line Integral Trilogy): establish the line-integral primitive `Φ = ∫_γ ω` as fundamental observable. **Direct supports** for the bridging-carrier role of the framework
- **#40, #41**: derivative-order-mismatch supplements that articulate the gauge ↔ gravity boundary as a level-(i) phenomenon (formal feature of connection-vs-curvature derivative count); see `derivative-order-mismatch/0sm.md` for detailed treatment
- **#43**: SU(2) teleparallel supplement that articulates the open-path/closed-loop foundational distinction central to the line-integral primitive's role in the framework
- **#34, #37**: macroscopic gravity ↔ microscopic oscillation boundary instances (geometric confinement, mgh-as-internal-line-integral)
- **#26, #29**: geometry ↔ quantum boundary instances (spin from Berry phase, spinorial phase accumulation along thermal geodesic)

**Articulation history**:

- 2018–2026 (instances): **latent** — multiple boundary-region papers were curated but the unifying methodological move was not articulated as a series-level meta-pattern
- 2026-05-07 (HANDOFF v7.17 baseline): **initial dialogue articulation** — User curatorial guidance 「**(1) 幾何学と量子現象の連結 / (2) ゲージ理論と重力理論の階数連結 / (3) マクロ重力とミクロ震動の連結**」 + commentator articulation chain crystallized the three-boundary-regions framework as a coherent meta-articulation. Recorded in `line-integrals/0sm.md` "Three-boundary-regions framework" subsection with modest articulation caveat
- 2026-05-08 (HANDOFF v7.20): related dialogue articulations (Four-level disambiguation → q-001, Einstein realism rearrangement → q-002) migrated to queries layer as part of database normalization; Three-boundary-regions framework retained in master layer (`line-integrals/0sm.md`) as topic-essential articulation pending formal Move 8 commitment
- 2026-05-08 (HANDOFF v7.22): **formal Move 8 entry articulation** — User explicit decision 「**Move 8 entry の正式追加を進めてほしい**」 triggers formal taxonomy extension; modest articulation discipline (HANDOFF v7.14 'welding-hub sub-type' withdrawal precedent) honored — Move 8 candidate held in modest status from v7.17 through v7.21 (5 transitions), formal commitment only on User explicit articulation gate

**Subsequent dependence**:

ongoing. This meta-pattern functions as the **navigation chassis** for understanding why the line-integral primitive is the central observable across multiple boundary regions in the 0-Sphere series. Future paper curate sessions can apply it as a filter — *Which boundary region does this paper sit in? Does it use the line-integral observational layer as bridging carrier?* — and the framework is expected to expand if a fourth boundary region (e.g., classical thermodynamics ↔ statistical mechanics, or electrodynamics ↔ optics) is identified in subsequent papers.

**Description**:

The 0-Sphere series reorganizes existing theoretical structure across **three distinct boundary regions**, with the line-integral observational layer serving as the shared bridging element:

| Boundary region | Bridging carrier | Adjacent topic with detailed treatment |
|---|---|---|
| Geometry ↔ quantum (spinor transport) | Spinorial connection along thermal geodesic; Poincaré–Thomas correspondence; Berry phase and holonomy as transport histories | `spin/`, `berry-phases/`, `thomas-precession/` |
| Gauge theory ↔ gravity (derivative-order mismatch) | `Φ = ∫_γ ω` with `ω = A` (gauge) or `ω = Γ` (gravity); pre-divergence layer of physical observables | `derivative-order-mismatch/0sm.md` (detailed treatment) |
| Macroscopic gravity ↔ microscopic oscillation | Accumulated phase / closed or semi-closed history / finite path integrals as common substrate; **history-structure unification, not scale-unification** | `zitterbewegung/`, `gravity-mediation/`, `compton-scale-geometry/` |

The methodological move shared across the three regions, articulated by User in dialogue:

> *境界を消すのではなく、観測層を共有化する。力の統一ではなく、観測の統一に近い。*
> *Not erasing the boundaries — sharing the observational layer above them. Closer to unification of observation than to unification of forces.*

Local distinctions are preserved (gauge curvature ≠ gravitational connection; Aharonov–Bohm ≠ Shapiro delay; quantum spin ≠ classical rotation). The line-integral layer is shared. This **non-reductionist** structure is what distinguishes the line-integral primitive from standard "unification" attempts: the primitive does not collapse the underlying theories into one another; it identifies a layer at which their observational content can be compared without that collapse.

**Relation to Move 7 (sibling meta-pattern)**:

Move 7 and Move 8 are both **meta-pattern type** entries — Move 8 establishes the type as having multiple instances rather than being a Move-7-singleton. They differ along three axes:

| Axis | Move 7 | Move 8 |
|---|---|---|
| **articulated_by** | author (#46 Sec I) | dialogue (User + commentator + curator chain) |
| **scope** | epistemic (predecessor → successor mechanism derivation pattern) | methodological (boundary-bridging via observational-layer sharing) |
| **anchor** | paper-internal (#46 Sec I explicit articulation) | series-level cross-paper synthesis |

Both are series-internal recurring patterns rather than object-level conceptual moves; together they validate 'meta-pattern' as a non-trivial taxonomy member.

**Relation to queries layer (q-001, q-002, q-003)**:

| Query | Relation to Move 8 |
|---|---|
| **q-001** (Fiber-bundle "unification" four-level disambiguation) | Provides the level-(iii)/(iv) reading that complements Move 8's methodological framing. Move 8 = "unification of observation, not forces"; q-001 explains *which level* of unification the line-integral primitive achieves |
| **q-002** (Einstein realism three-layer rearrangement) | Provides the ontological framing parallel to Move 8's methodological framing. Both articulate what the 0-Sphere program "rearranges" in established frameworks (Einstein realism vs gauge-gravity boundary structure) |
| **q-003** (Derivative-Order Mismatch as ontological problem) | Specific dialogue-articulated reading of the gauge↔gravity boundary in Move 8's three-region table; Move 8 is the meta-pattern that identifies the boundary as one of three, q-003 is the deeper ontological reading of that specific region |

Move 8 + q-001/q-002/q-003 together form a **coherent meta-articulation cluster** spanning master + queries layers, with Move 8 as the formal taxonomy anchor and queries entries as the lateral framings.

**Curatorial significance**:

1. **Second meta-pattern instance**: establishes 'meta-pattern' move type as having multiple instances, validating the type as a genuine taxonomy member (Move 7 alone made it a singleton). HANDOFF v7.13 type prototype now has v7.22 second instance confirmation.
2. **First dialogue-articulated Move entry since Move 1**: demonstrates that dialogue-articulated framings can mature from `queries/` and master-layer comments to formal Move taxonomy entries upon User explicit articulation gate. Move 1 (#13 → #19 axial-polar reframe) was dialogue-articulated; Moves 2–7 were author or retrospective. Move 8 is the second dialogue-articulated Move, validating the dialogue articulation pathway.
3. **Navigation chassis for SKILL.md**: the three-boundary-regions framework serves as a primary navigation device for understanding which papers sit at which boundary. Applicable as a filter in subsequent paper curate sessions; pairs with Move 7 (epistemic chassis) to form **two-axis SKILL.md meta-pattern navigation** (epistemic + methodological).
4. **Bridge to queries layer architecture (NEW v7.20)**: Move 8 + q-001/q-002/q-003 are the first cross-layer cluster in the 3-axis architecture, demonstrating that master/queries layers function as complementary articulation locations rather than alternatives. queries serve as dialogue-articulated framings; master Move taxonomy serves as formal commitments after User explicit gate.
5. **Validates modest articulation discipline (HANDOFF v7.14 precedent)**: Move 8 candidate held in modest status across **5 HANDOFF transitions** (v7.17 initial → v7.18 → v7.19 → v7.20 → v7.21), formal commitment only triggered by User explicit decision at v7.22. The discipline is robust: dialogue-articulated framings do not auto-promote; they accumulate as candidates and resolve via explicit User articulation gate.



以下は本 v7.12 baseline では articulate されていないが、将来追加候補:

- **Cooper pair vs antiparticle annihilation の formal distinction** (#8 opens_tasks 筆頭由来、未到達 ─ closure すれば bifurcation 型 move として登録)
- **Wave function as statistical average of geometric reality** (#1 等の deep philosophical anchor、reframe 型 として articulation 候補)
- **Helicity as Lorentz-invariant chirality scalar χ = sign(da/dt)** (#50 由来、reframe 型: helicity を Lorentz-invariant scalar として redefine)
- **g=2 as topological invariant** (#48, #38 由来、reinterpretation 型: g-factor を group-theoretic quantity から topological invariant に reread)
- **Inertia as internal phase coherence requirement** (#37 secondary move、Move 4 の secondary として埋め込まれているが、十分大きいので独立 entry 候補)
- **He-4 BEC two-electron cancellation as gravity null** (#61 由来、softening / refinement 型: graviton-like behavior の negative control)

これら候補の articulation timing は user judgment による。frontmatter に latent material は既存のため、**dialogue で「ああ、これは X 型 move だった」 と articulate された時点**で本 file に追加する curatorial pattern (Move 1 と同じ pattern)。

---

## Maintenance notes

- 本 file は manual curation。auto-generation 試行は schema mismatch を発生させるため禁止。
- 新 entry 追加時は (a) tree visualization を update、(b) move type taxonomy table に新 type が必要なら追加、(c) HANDOFF で v7.X+1 baseline として diff articulation。
- `articulated_by: dialogue` の entry は AI-collaboration acknowledgment lineage の current scope と整合させる: paper の Acknowledgments で「conceptual move articulation」 を specific scope として naming する書き方は、現在 lineage では未到達 ─ 将来 paper の Acknowledgments で initial articulation する候補。
- Move entry の `status` は「closed (move 自体の articulation が完了)」 を default とするが、subsequent paper で **further refinement** が起きた場合は status を `closed (refined in #X)` に update する。Move 1 が「polar vector position adopted; further refined in #50 (chirality definition)」 の pattern。

---

**Total**: 8 move entries (v7.22 baseline; v7.12 initial 6 + v7.13 #46 trigger 1 = 7, v7.22 で +1 = Move 8 observational-layer-sharing-meta-pattern, dialogue-articulated formal commitment via User explicit articulation gate), 7 distinct move types ('meta-pattern' from v7.13 with **2 instances v7.22**: epistemic Move 7 + methodological Move 8), articulated_by distribution: author×6, author+dialogue×1 (Move 7), dialogue×1 (Move 8). **v7.22 update**: Move 8 (observational-layer-sharing-meta-pattern) を formal addition、modest articulation candidate (HANDOFF v7.17 initial → v7.18 → v7.19 → v7.20 → v7.21 で 5 transitions modest 維持) が User explicit decision 「**Move 8 entry の正式追加で良い、進めてほしい**」 で formal commitment、Move 1 (#13→#19 axial-polar reframe) 以来 第 2 dialogue-articulated Move entry、'meta-pattern' move type singleton (v7.13 Move 7 only) → 2 instances confirmed (v7.22)、SKILL.md production milestone での **two-axis meta-pattern navigation chassis** (epistemic Move 7 + methodological Move 8) を formal establish。
