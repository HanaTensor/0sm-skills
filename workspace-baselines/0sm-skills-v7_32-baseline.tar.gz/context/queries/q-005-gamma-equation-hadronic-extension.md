---
id: q-005
title: "γ-equation extension from leptonic to hadronic kernel structure: |a| as compositeness measure, 336 MeV two-direction derivation, and SU(3) MCP candidate"
created: 2026-05-09
updated: 2026-05-09
status: active
sources:
  papers: [10, 9]
  topics: [thermodynamics, zitterbewegung, spin]
  queries: []
dialogue_origin: "HANDOFF v7.26 → v7.27 transition session, extensive brain-walking with User on γ-equation extension to charged spin-1/2 baryons, surfacing (i) 336 MeV two-direction derivation from m_p / γ_p matching QCD constituent quark mass scale (ii) bicycle wheel kinematic argument for γ = 1 + |a| convention extending to neutral spin-1/2 particles (iii) bound-neutrino Lissajous frozen state hypothesis as physical interpretation of 13.4 MeV kernel mass discrepancy between proton and neutron (iv) proton-antineutrino kernel exchange symmetry partner hypothesis as separate foundational structural articulation"
purpose: dialogue-prep + cross-reading + paper-execution-direction
---

# q-005: γ-equation extension from leptonic to hadronic kernel structure

## 問題意識

The γ-equation $\gamma = 1 + a$ was originally articulated for the electron (paper #10), where $a_e \approx 1.16 \times 10^{-3}$ predicts an internal Zitterbewegung velocity $v_\text{ZB}^e \approx 0.048c$ — a non-relativistic regime. For the proton, $a_p \approx 1.793$ is approximately 1500 times larger, far beyond the perturbative regime where standard QED expansions apply. The first-principles geometric derivation of the γ-equation in #10, however, does not depend on perturbative expansion. This raises the central question: **what does the γ-equation predict when applied to composite hadrons where pQCD fails?**

The dialogue surfacing this question (HANDOFF v7.26 → v7.27 transition) produced four structurally connected articulations that are each independently substantial enough to anchor separate paper executions. They are recorded here as a single research-direction registration to preserve the unity of the dialogue and the structural connections among the candidate paper-level executions.

## 中心結果: 336 MeV 二方向導出

The γ-equation applied to the proton yields:

$$\gamma_p = 1 + a_p = 2.793, \qquad m_{0,\text{kernel}}^p = \frac{m_p}{\gamma_p} = \frac{938.27 \text{ MeV}/c^2}{2.793} \approx 336 \text{ MeV}/c^2$$

Independently, QCD predicts the **constituent quark mass** of up/down quarks $\approx 336 \text{ MeV}/c^2$ from chiral symmetry breaking ($\langle\bar{q}q\rangle$ vacuum condensate dynamics + baryon spectroscopy fits). Two completely independent theoretical paths — one from $\{m_p, a_p\}$ via γ-equation, the other from QCD vacuum structure via chiral symmetry breaking — converge on the same numerical value to three significant figures.

This convergence is the **central finding** of the q-005 thread. Its epistemological status is not "0-Sphere Model derives QCD constituent quark mass from first principles" (overclaim — QCD's value is also phenomenological from baryon spectroscopy fits), but rather "**two phenomenological routes from disjoint input data converge on the same scale**" — a non-trivial cross-framework numerical signature suggesting the two frameworks may describe the same physical entity (kernel rest mass $\equiv$ constituent quark mass) from different angles.

## bicycle wheel kinematic argument: γ = 1 + |a|

The γ-equation extension to the neutron requires handling negative $a_n = -1.913$. User-articulated bicycle wheel argument: Lorentz contraction depends on $|v|^2$, not rotation direction; therefore the kinematic factor $\gamma$ depends on $|a|$ alone. The sign of $a$ encodes spin-magnetism orientation (independent kinematic vs orientation factorization).

Resulting prediction:

$$\gamma_n = 1 + |a_n| = 2.913, \qquad m_{0,\text{kernel}}^n = \frac{m_n}{\gamma_n} = \frac{939.57}{2.913} \approx 322.5 \text{ MeV}/c^2$$

The 13.4 MeV gap between $m_0^p$ and $m_0^n$ becomes a **specific framework prediction** testable against lattice QCD baryon mass calculations.

## |a| as compositeness measure

A structural pattern emerges: $|a|$ measures internal compositeness / relativistic internal motion content.

| Particle class | $|a|$ | $\gamma$ regime | $m_0 / m_\text{obs}$ |
|---|---|---|---|
| Elementary leptons (e, μ, τ) | $\sim 10^{-3}$ | non-relativistic ($\gamma \approx 1$) | $\approx 1$ |
| Composite baryons (p, n) | $\sim 1.8\text{-}1.9$ | highly relativistic ($\gamma \approx 2.8\text{-}2.9$) | $\approx 0.34$ |

This articulates a **0-Sphere Compositeness Principle** (modest articulation candidate): the Standard Model's "elementary vs composite" distinction is captured by the magnitude of the anomalous magnetic moment in the 0-Sphere reading, with the kinematic factor $\gamma$ providing the bridge between the observed mass and the kernel rest mass.

## bound-neutrino Lissajous frozen state hypothesis (13.4 MeV interpretation)

The 13.4 MeV kernel mass discrepancy between proton and neutron requires physical interpretation. User-articulated hypothesis: inside the neutron, the bound antineutrino is in a Lissajous frozen state (Lissajous oscillation suppressed; energy that would manifest as kinetic energy in free state is in rest-mass-equivalent form when bound). The β decay event is the freezing→activation transition.

Energy bookkeeping at two levels:

- **Observed level**: $m_n - m_p = m_e + Q_\beta + m_{\bar{\nu}}^\text{rest} \approx 1.293$ MeV (standard β decay accounting, framework-consistent)
- **Kernel level**: $m_0^p - m_0^n = 13.4$ MeV (bound antineutrino frozen Lissajous energy contribution)
- The two levels are reconciled by the γ factor difference ($\gamma_n - \gamma_p = 0.120$).

Foundational anchor: paper #9 (0-Sphere Neutrino Model, DOI 10.5281/zenodo.17764952) which articulates two thermal oscillators with different frequencies $\omega_{\nu 1} \neq \omega_{\nu 2}$ producing Lissajous trajectory + W±/Z⁰ as encapsulating bosons. The bound state hypothesis is a natural extension of #9's framework into the neutron's internal structure.

**Falsifiable predictions (three-layer)**:
1. Bound antineutrinos do not exhibit neutrino flavor oscillation (Lissajous source frozen)
2. β decay event marks Lissajous activation transition (transient signature in neutrino spectrum)
3. Other β-active nuclei ($^3$H, $^{14}$C, $^{40}$K) show similar ~13 MeV kernel mass discrepancy patterns

## proton-antineutrino kernel exchange symmetry partner hypothesis

User-articulated symmetry preservation argument:

- Electron has kernel A↔B exchange symmetry (#1 framework)
- Neutrino has asymmetric kernel pair (Lissajous structure, #9)
- For symmetry to be preserved at higher level, neutrino's broken symmetry requires a partner
- Hypothesis: proton has complementary asymmetric kernel structure; inside the neutron, proton + bound antineutrino forms a kernel-exchange-symmetric whole

Structurally parallel to standard model lepton number conservation (each particle carries a kernel-asymmetry quantum number; bound states have symmetric combinations).

Implications:
- (A) Proton has intrinsic broken kernel symmetry (free proton too)
- (B) Proton and neutrino are deep structural partners (lepton-quark cross-sector connection beyond SM)
- (C) Connects to QCD's SU(3) via "MCP" (transformation plug)
- (D) Provides candidate framework for proton spin crisis (proton's broken kernel symmetry as internal-asymmetry source)

## paper-execution direction

**Paper A** (target: scope-disciplined #22-style single-result paper):
- Scope: 336 MeV two-direction derivation ONLY
- Title candidate: "Application of the γ-Equation to the Proton: Convergence with the QCD Constituent Quark Mass Scale"
- Defense content (neutron, |a| convention, bound-neutrino, kernel partner) → defer to Paper B/C
- Maximum-impact compact paper, falsifiability anchor clean

**Paper B** (target: foundational structural paper):
- Scope: γ = 1 + |a| extension to charged/neutral spin-1/2 baryons + |a| as compositeness measure principle + bound-neutrino Lissajous frozen state hypothesis + β decay kinematic accounting
- Defense / extension of Paper A's central claim against neutron-side stress test

**Paper C** (target: foundational structural paper):
- Scope: proton-antineutrino kernel exchange symmetry partner hypothesis + lepton number reinterpretation + proton spin crisis connection candidate
- Most ambitious; builds on Paper A + Paper B

User decision (HANDOFF v7.26 → v7.27 transition): **Paper A first, scope-narrowed to 336 MeV ONLY**. This protects Paper A's central claim from dilution by defense content and establishes a clean #22-style precedent for the hadronic empirical anchor.

## paper #9 forward extension status

Paper #9 (Beyond the Standard Model: Neutrino Oscillations and the Search for New Physics, 2023-04-16) was originally curated (HANDOFF v7.7 → v7.8) as **isolated extension paper** position with User-explicit articulation 「現在のところ唯一の論文である。後続を考えているが、アイデアが湧かない」. The q-005 thread surfaces three concrete forward extensions of #9 (Paper A direct anchor, Paper B/C foundation, future Lissajous quantitative paper for $\omega_1, \omega_2$ → 13.4 MeV derivation), challenging the "isolated" status. Per Option α curatorial discipline, formal `relation` field update of 009.md is deferred until Paper A/B/C are landed (Zenodo upload completion gate).

## 関連 queries

- **q-001** (Fiber-bundle "unification" four-level disambiguation): 本 q-005 で surface した 「two phenomenological routes converge on same scale」 epistemological framing は、q-001 の level-(iii) observational semantics と level-(iv) ontological status の両軸に関わる ─ 0-Sphere kernel rest mass と QCD constituent quark mass の identification は ontological claim (level iv)、numerical convergence は observational evidence (level iii)
- **q-004** (Phenomenological unification via line integral): 本 q-005 の central claim 「proton observed mass 938 MeV decomposes into γ × m_0」 は line integral framework と structurally distinct (kernel rest mass は局所量、line integral は path-history 量)、両者は 0-Sphere framework 内の異なる primitive layer

## 適用 protocol (curatorial filter として)

Future papers / dialogue で hadronic empirical anchor または compositeness articulation が surface した際の filter:

> *本 articulation は q-005 の四 strands (336 MeV two-direction / |a| compositeness / bound-neutrino frozen / kernel partner) のどれに anchor するか? 該当 strand が active か? Forward execution direction (Paper A/B/C) のどれに connect するか?*

This protects the curatorial record from collapsing the four structurally connected but executionally distinct paper-level threads into a single undifferentiated articulation.
