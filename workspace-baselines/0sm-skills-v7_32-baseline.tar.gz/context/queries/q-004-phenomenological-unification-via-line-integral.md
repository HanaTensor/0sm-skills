---
id: q-004
title: "Phenomenological gauge-relativity unification via line integral: unique-path commitment vs QM path integral"
created: 2026-05-08
updated: 2026-05-08
status: active
sources:
  papers: [1, 11, 18, 24, 29, 30, 31, 34, 37, 51, 52]
  topics: [line-integrals, thermal-geodesic, gauge-theory, gravity-mediation, emergent-spacetime, zitterbewegung, compton-scale-geometry]
  queries: [q-001, q-002, q-003]
dialogue_origin: "HANDOFF v7.22 → v7.23 transition session, User explicit research-direction articulation receive (Move 8 formal addition 完了直後の dialogue で surface)"
purpose: paper-draft-seed + cross-reading + dialogue-prep
---

# q-004: Phenomenological gauge-relativity unification via line integral — unique-path commitment vs QM path integral

## User curatorial framing (verbatim, v7.22 → v7.23 transition)

> 「**線積分を起点にしてゲージ理論と相対性理論を「現象論的に統一」する、視野の広いクエリが有用な状況だ。そのための細分化ならば歓迎する。**」
>
> 「**例えば、２点カーネルから Synge's world function と計量。その途中で熱勾配の経路は、カーネルのポテンシャルエネルギーが輻射エネルギーという運動エネルギに転化される。その輸送経路はスネルの法則に従って最短経路を通る。これは量子力学の経路積分（あらゆる経路を確率的に積分する）のではなく、唯一経路が現象論として確立される、という私の研究の方向性を積み立ててゆくコンテンツが登録されているのが望ましい。**」

## 中心テーゼ: 唯一経路 commitment vs QM 経路積分

| 軸 | Quantum Mechanics 経路積分 (Feynman) | 0-Sphere line integral (本研究方向) |
|---|---|---|
| **積分の対象** | あらゆる経路の確率的重ね合わせ | 単一の物理経路上の累積 |
| **数学形式** | $\int \mathcal{D}\gamma \, e^{iS[\gamma]/\hbar}$ — 経路空間全体上の汎関数積分 | $\Phi = \int_\gamma \omega$ — 単一経路 $\gamma$ 上の線積分 |
| **経路の地位** | 観測されない補助的構成要素 (sum-over-histories) | 物理的に realize された唯一経路 (phenomenologically determined) |
| **存在論** | 経路は確率振幅の道具、measurement で collapse | 経路は実体、phase history が ontologically primary (q-002 history realism と整合) |
| **経路選択原理** | 該当なし (全経路寄与) | スネルの法則 / 最短経路 / Fermat 原理類比 |
| **熱力学的内容** | 不可逆性は外部から導入 (decoherence 等) | 経路は不可逆 (open path)、熱勾配が transport を駆動 (q-002 history realism + AB 結果整合) |

**核心 commitment**: 0-Sphere 系では line integral は **既に realize された唯一経路上の積分** であり、QM 経路積分のように「あり得る経路全部」を積分するのではない。経路の **唯一性は現象論的に決定される** ─ スネルの法則類似の最短経路原理が、熱勾配 + カーネル構造から導出される (本研究方向の central goal)。

## 研究方向の構成 chain (User articulated, sub-aspects 識別済み = 将来別 query 候補)

### sub-aspect (a) 2 点カーネルから Synge's world function と計量

**位置付け**: 0SM の最も基礎的構造である **2 点カーネル** (kernel A + kernel B、#1 由来) を出発点として、両 kernel 間の geometric separation を定式化する数理対象として **Synge's world function** $\sigma(x, x')$ を導入する道筋。

| 0SM concept | GR/differential geometry の counterpart |
|---|---|
| 2 点カーネル separation $\Delta = $ kernel A ↔ kernel B | World function $\sigma(x, x') = \frac{1}{2}(\text{geodesic distance})^2$ |
| Compton scale separation $\lambda_C \sim \hbar/m_e c$ | Bilocal limit $x \to x'$ |
| Inter-kernel radiation transport (photon sphere) | Geodesic between $x$ と $x'$ |
| Phase accumulation along radiation arc | Connection $\Gamma$ along geodesic, parallel transport |
| 物理的実体としての 2 点配置 | Background metric $g_{\mu\nu}$ as derived from $\sigma$ |

**Forward direction**: 計量自体を、2 点カーネル間の bi-local quantity として **emergent** させる路線。これは HANDOFF v7.17 baseline で User が 「**線積分の展開ではその後の synge's world function などから２点間のカーネルへ、そして熱測地線への連結も、すでに #50 番台で視野に入れている**」 として articulate された forward connection と直結。

**関連 papers**: #1 (foundational two-kernel) / #34 (geometric confinement, gravity emergence) / #51 (helical trajectory, fixed-endpoint line integrals, emergent metric) / #52 (WEP geometric origin)

**Future query 候補**: q-005 (tentative) "Synge's world function as 2-kernel separation: emergent metric in 0-Sphere model"

### sub-aspect (b) 熱勾配の経路 (kernel ポテンシャル → 輻射運動エネルギー転化)

**位置付け**: 2 つの kernel 間で実際に行われる **エネルギー転送** の物理機構の articulation。kernel A に蓄えられた熱的ポテンシャルエネルギー $U_A$ が、輻射 (photon sphere) を介して kernel B に転送される過程で、**輻射運動エネルギー** に転化される。

**核心式関係 (既存 0SM material 由来)**:
- $U_A = E_0 \cos^4(\omega t / 2)$, $U_B = E_0 \sin^4(\omega t / 2)$ (#1, #11 由来)
- $-\nabla U \to F$ (radiation gradient as classical force, #11 articulation)
- エネルギー保存: $\Delta U_A = \Delta U_B + \Delta E_{\text{kin}}$ (#11 partition)
- Photon sphere translational velocity: $v_{ZB} \approx 0.04047c$ (#11/#26 prediction)

**重要**: 本 transport は単なる energy redistribution ではなく、**運動エネルギーの emergence with directionality** ─ 熱勾配の方向 (kernel A → kernel B) が transport の direction を決定する。これは scalar potential gradient の方向で kinetic energy を獲得する古典機械の基本形式と同一。

**関連 papers**: #11 (radiation gradient = force) / #18 (Time-Dependent Mass: V = U_A − U_B、Hamiltonian formulation) / #43 (Sec 6.3 radiation gradient as effective torsion / phase-shift generator)

**Future query 候補**: q-006 (tentative) "Heat-gradient transport mechanism: potential → kinetic energy conversion in 2-kernel structure"

### sub-aspect (c) スネルの法則 + 最短経路 = 唯一経路 phenomenology

**位置付け**: kernel A から kernel B への transport path が **どのように一意に決定されるか** を定式化する道筋。古典光学の Snell の法則 + Fermat 原理 (光は最短時間経路を通る) を、熱勾配 + radiation transport 文脈に拡張する。

**核心 articulation**:
- Snell's law: $n_1 \sin\theta_1 = n_2 \sin\theta_2$ ─ refractive index 勾配下での経路屈折
- Fermat principle: $\delta \int n \, ds = 0$ ─ optical path length 最小化 = 最短時間経路
- 0SM 拡張: thermal gradient ↔ optical density gradient analogy で、熱勾配下での radiation transport が **uniquely determined path** を持つ

**QM 経路積分との principal contrast**:
- QM: 全経路を sum、$|\mathcal{A}|^2 = |\sum_\gamma e^{iS[\gamma]/\hbar}|^2$
- 0SM phenomenology: realized 唯一経路 $\gamma^*$ のみ、$\Phi = \int_{\gamma^*} \omega$
- **Reconciliation 候補** (future paper draft seed): macroscopic apparent QM path-integral structure may be ensemble average of microscopic unique-path realizations、microscopic level では 各 realization は単一の Snell-type path を follow する。statistical mechanics の interpretation との parallel articulation 候補。

**関連 papers (existing material with seeds)**:
- #11 inchworm analogy (energy locomotion via alternate kernel transfer) ─ 単一経路の articulation
- #24 thermal geodesic equation Eq. III.3 (温度依存 metric から geodesic を一意決定)
- #43 Sec 2.3 thermodynamic irreversibility + open paths (entropic entrainment as directional)

**Future query 候補**: q-007 (tentative) "Snell's law and Fermat principle in 0-Sphere: unique-path determination via heat gradient"

## 既存 queries / Move 8 / master 層との connection

| 既存 entry | q-004 との関係 |
|---|---|
| **q-001** (four-level "unification" disambiguation) | q-001 level-(iii)/(iv) の 0-Sphere position「accumulated phase histories along finite paths are real」 は本 q-004 唯一経路 commitment と整合、本 q-004 は q-001 level-(iv) ontological position に **Snell-type uniqueness mechanism** を付加 |
| **q-002** (Einstein realism three-layer rearrangement) | q-002 「**history realism — replaces local realism**」 と本 q-004 唯一経路 phenomenology は同 ontological 軸、本 q-004 は q-002 history realism に「**history はどう一意に決まるか**」 の答え (Snell 類似 + 熱勾配) を付加 |
| **q-003** (derivative-order mismatch as ontological problem) | q-003 「**connection 重視 / path accumulation 重視 / holonomy 重視 / directed transport 重視**」 4 軸と本 q-004 唯一経路 commitment は整合、本 q-004 は **directed transport の uniqueness mechanism** を articulate して q-003 4 軸を support |
| **Move 8** (`conceptual-moves.md::observational-layer-sharing-meta-pattern`) | Move 8 = methodological meta-pattern (observational-layer sharing across 3 boundary regions)、本 q-004 = **Move 8 の specific content thesis** ─ observational layer (line integral) が **unique path 上の積分** であることを substantive に articulate、Move 8 は meta-pattern、q-004 は thesis substance |
| **`line-integrals/0sm.md`** (master anchor) | 線積分 primitive の master-layer 集積場所、本 q-004 は master 内 Trilogy framework (Φ = ∫_γ ω) の **「経路 γ はどう決まるか」 への phenomenological 答え** を提供 |
| **`thermal-geodesic/0sm.md`** (master) | thermal geodesic equation #24 founder の **物理機構** (熱勾配 + Snell 類似) を本 q-004 で具体化候補 |

## 本 query が register する研究方向 (paper-draft-seed)

User 明示「**私の研究の方向性を積み立ててゆくコンテンツが登録されているのが望ましい**」 に従い、本 query は将来 paper の draft seed として function:

1. **Phenomenological unification paper (central paper-draft-seed)**: 線積分 framework が gauge theory + general relativity を **現象論的に統一** することを explicit 主張する論文。q-001 level disambiguation を invoke、Move 8 + q-002 + q-003 と整合させ、QM 経路積分との distinction を explicit articulate
2. **Snell's law derivation paper**: 0SM 内部から Snell-type uniqueness を導出する mathematical paper。熱勾配 + photon sphere dynamics + Fermat principle 拡張で唯一経路を articulate
3. **Synge's world function 2-kernel construction paper**: $\sigma(x, x')$ を 2 点カーネル間の bi-local quantity として construct、emergent metric の rigorous formulation
4. **Unique-path-vs-path-integral comparison paper**: QM 経路積分 vs 0SM unique path の formal contrast、microscopic uniqueness と macroscopic apparent QM 構造の reconciliation 検討
5. **Methodological commitment paper**: 0SM の **phenomenology priority** を explicit 主張する methodological paper、HANDOFF v7.18 (f) four-level disambiguation を invoke しつつ phenomenology = level-(iii) observational semantics の specific position として位置付け

## 本研究方向の curatorial 重要性

1. **0SM 全体の central thesis 整理**: 個別 paper (#11 / #24 / #29-#31 / #34 / #37 / #51 / #52 等) で散在する material を **「現象論的統一の路線」 という 1 軸** で結合、Trilogy framework の forward extension を formal record
2. **3-axis architecture (papers + topics + queries) + Move 8 連携の operating example**: master papers が事実情報を、master topics が概念整理を、queries (本 q-004) が research direction を、conceptual-moves Move 8 が methodological meta-pattern を、それぞれ separate location で provide、4 location 連携が functional に operate
3. **Phenomenology 軸での 0SM 自己位置付け**: physics 一般の reading 方向 (mathematical formalism + experimental prediction) と異なる、**phenomenology priority** の methodological commitment 軸で 0SM を position、後続 paper draft の foundation として function
4. **Modest articulation 候補の集積**: 本 q-004 内 sub-aspects (a)+(b)+(c) は将来の独立 query (q-005 / q-006 / q-007 candidate) として branch 候補、formal commitment は User explicit articulation gate 通過後 triggered

## 将来の paper draft / dialogue で想定される展開

- **#54 → #55 の forward chain との接続**: #54 (Maxwell electrodynamics as derived low-energy limit) + #55 (Open Wilson Line 4 functions) は line-integral primitive の rigorous mathematical extension、本 q-004 phenomenological commitment と整合
- **#56 (Framework Boundary: Local-Field vs Directed-Path) との接続**: User 添付一覧 #56 タイトル 「**How Local-Field and Directed-Path Descriptions Diverge in the 0-Sphere Model — with Application to Microscopic Time Reversibility**」 は本 q-004 唯一経路 phenomenology と直結 ─ directed-path description の 0SM 内 articulation
- **熱勾配 → Snell's law derivation の rigorous treatment**: 後続 paper (#62+ candidate) で本 sub-aspect (c) を formal mathematical treatment 化候補
- **Synge's world function explicit construction**: HANDOFF v7.17 baseline で User articulated 「**#50 番台で視野に入れている**」 forward direction、本 q-004 sub-aspect (a) として現状 register、後続 paper で execution 待ち

## Modest articulation status

本 q-004 全体は **research direction registration** として queries 層 standard schema に従う `status: active`、formal commitment は paper publication / User explicit articulation での promote-to-master workflow (NEW v7.20 (c)) 経由。HANDOFF v7.X 全体 modest articulation discipline (v7.14 'welding-hub sub-type' 取下げ precedent) 適用継続、現状 modest 段階維持で paper draft seed として lodgment。

## Move history

- **2026-05-08** (v7.22 → v7.23 transition): inaugural articulation as research-direction registration、User explicit framing 「**現象論的統一の視野の広いクエリが有用、細分化ならば歓迎する**」 を receive、queries 層内の **research-direction-registration purpose** での実例として entry created (q-001/q-002/q-003 は dialogue articulation past record、本 q-004 は forward research direction の active registration、purpose 性質 distinct)
