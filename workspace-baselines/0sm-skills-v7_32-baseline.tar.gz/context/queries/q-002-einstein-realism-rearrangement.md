---
id: q-002
title: "Einstein realism three-layer rearrangement framing"
created: 2026-05-07
updated: 2026-05-08
status: active
sources:
  papers: []
  topics: [derivative-order-mismatch, line-integrals]
  queries: [q-001, q-003]
dialogue_origin: "HANDOFF v7.17 → v7.18 transition session, User + commentator dialogue chain (q-001 と同 dialogue chain で surface した第二の framing、本 v7.20 transition で master 層から query 層へ正規化)"
purpose: dialogue-prep + cross-reading
---

# q-002: Einstein realism three-layer rearrangement framing

## 問題意識

A second dialogue-articulated framing (姉妹 query: q-001) positions the 0-Sphere line-integral program against **Einstein's realism**, which is itself not a single thesis but a layered cluster. Distinguishing the layers makes visible what the 0-Sphere reorganization keeps and what it gives up — and where the reorganization sits in relation to Einstein's own late-life trajectory.

## Einstein realism as a three-layer cluster

| Layer | Content | Where it appears in Einstein's writing |
|---|---|---|
| **Local realism** | Distant events are independent unless mediated by local interactions; "no spooky action at a distance" | EPR (1935) and Einstein's late objections to QM completeness |
| **Geometric realism** | What is "really there" *is* geometry itself; physics should describe geometric structure rather than reduce to it | General covariance commitment; the unified field theory program of his late life |
| **Background independence** | Physics is independent of any preferred frame or fixed background structure | The Hole Argument resolution and the structure of GR itself |

These layers are correlated in Einstein's own thought — local + geometric + background-independent realism formed a coherent commitment for him — but they are **logically separable**, and the Aharonov–Bohm effect (1959) was the first major experimental result to force the question of *which* of the three layers is in tension with the rest.

## How the AB effect destabilizes local realism

The Aharonov–Bohm phase shift is observed for an electron path that traverses only `F_µν = 0` regions. No local field is present along the path, yet the interference pattern shifts. This is straightforwardly inconsistent with **local realism in its strongest form**: a local-field-only ontology cannot account for the phase shift.

Mainstream gauge theory's resolution (gauge potentials `A_µ` are themselves real) is **mathematically adequate but in tension with Einstein's local realism**, because `A_µ` is gauge-dependent — its pointwise values change under gauge transformations. To say that a gauge-dependent quantity is *real* is to take a stance that Einstein's program would have viewed uneasily (the "gauge dependence problem" of gauge potential realism).

## The 0-Sphere rearrangement

The 0-Sphere line-integral framework treats accumulated phase histories along finite paths as the primary observable and ontological substrate. Mapped against the three Einstein layers:

| Layer | 0-Sphere stance | Comment |
|---|---|---|
| Local realism | **Weakened / partly given up** | Local field values cannot, on their own, carry the observational content; the AB result is taken at face value |
| Geometric realism | **Kept and extended** | "Geometry" is not the local point-set but the structure of finite-path histories — a *history realism* generalizing geometric realism |
| Background independence | **Kept** | Phase histories are defined without reference to a preferred frame or background structure |

## 核心 reading

The substantive curatorial reading: the 0-Sphere program **rearranges** Einstein realism rather than abandoning or fully retaining it. The core that is kept (geometric + background) is what most distinctively distinguishes Einstein's program from a Newtonian or operationalist alternative; the layer that is given up (local realism in its strongest form) is the layer the AB effect made costly to retain. Local realism is not simply discarded; it is **replaced** by history realism (the structure of finite-path accumulations), which inherits the geometric and background-independent characters of the layer it replaces.

Read this way, the 0-Sphere line-integral program is not anti-Einsteinian. It can be read as an attempt to **reconcile Einstein's geometric realism with the post-AB observational record** — a move that retains the parts of Einstein realism that the AB effect did not destabilize and modifies the part it did. Whether Einstein himself would have endorsed this rearrangement is a genuine open question; his late-life "geometrize everything" inclination is consistent with the direction but cannot be cited as authority.

## 関連 queries

- **q-001** (Fiber-bundle "unification" four-level disambiguation): 本 q-002 と同 dialogue chain で surface した姉妹 framing、levels (iii) + (iv) (observational semantics + ontological) の articulation を本 q-002 が ontological 軸でさらに展開
- **q-003** (Derivative-Order Mismatch as ontological problem): commentator articulation で本 q-002 の "geometric realism kept and extended" reading を支持、connection-primary-vs-curvature-primary 議論 が geometric realism 拡張 = history realism と直結

## Modest articulation status

Dialogue-articulated curatorial reading, **not an author-internal articulation in #40 or #41**. Whether to elevate it to a formal SKILL.md protocol or a Move 9 candidate awaits **User explicit authorial articulation**. The framing's defensibility rests on the layered structure of Einstein realism (well-attested in the philosophy-of-physics literature) and the post-AB observational record; what remains User's call is whether to position the 0-Sphere program *as* an Einstein-realism rearrangement in the curatorial record. Per HANDOFF v7.14 'welding-hub sub-type' withdrawal precedent, modest articulation is maintained pending that explicit articulation.

## Move history

- **2026-05-07** (v7.17 → v7.18): Initial articulation in dialogue, embedded as section in `derivative-order-mismatch/0sm.md` "Einstein realism との関係: three-layer rearrangement (curatorial framing)" + cross-reference in `line-integrals/0sm.md` "Three-boundary-regions framework" subsection
- **2026-05-08** (v7.19 → v7.20): Migrated to `queries/q-002-einstein-realism-rearrangement.md` as part of database normalization (User explicit decision: 「**既存の (f), (g) を移転しよう**」), original embedding in both `derivative-order-mismatch/0sm.md` and `line-integrals/0sm.md` replaced with brief pointer references
