# `context/queries/` ─ クエリ・キャッシュ層 (Query / Cache Layer)

**作成**: 2026-05-08 (HANDOFF v7.19 → v7.20 transition)

**Database 類比における位置**:

| 層 | 類比 | 書き換え | 内容性質 |
|---|---|---|---|
| `context/papers/` | 縦軸マスタ (paper master) | 追加 only (新 paper curate) | 各論文の事実情報 |
| `context/topics/0sm,textbook` | 横軸マスタ (topic master) | 追加 only (新 topic / applies_to 拡張) | 各 topic の概念整理 |
| **`context/queries/`** (本層) | **クエリ / view / cache** | **書き換え自由** | **複数マスタを横断して articulate された素材** |
| `context/derived/` | 派生 view (auto-generated) | 自動再生成 | scripts/ で papers/ + topics/ から build |

## 用途 (User curatorial framing 由来)

1. **Dialogue 準備**: 完成 SKILL.md をもとに User-Claude 間で論文相談を進める際の素材集積
2. **Bibitem 簡素化**: Zenodo upload / 新規論文作成時に複数 papers の DOI/title/date を一括取得して LaTeX bibitem 形式で並べる作業成果物
3. **横断 articulation**: User の研究特色である「物理学や幾何学の境界線を結合」する分野横断的 reading を集積

## 各 query file の構造

各 file は次の frontmatter schema を持つ:

```yaml
---
id: q-NNN                      # 連番 (3桁zero-pad)
title: "短い articulation 名"
created: YYYY-MM-DD
updated: YYYY-MM-DD
status: active                 # active / archived / promoted-to-master
sources:                       # 横断する master files
  papers: [N, N, ...]          # paper number 整数 array (空可)
  topics: [name, name, ...]    # topic subject string array (空可)
  queries: [q-NNN, ...]        # 他 query への relation (空可)
dialogue_origin: "出典記述"    # ChatGPT share / 対話セッション / 等
purpose: dialogue-prep         # dialogue-prep / bibitem-simplification / cross-reading / paper-draft-seed
---
```

## 正規化ルール (database normalization 観点)

1. **Master 層との sources 関係は明示**: 各 query は `sources.papers` + `sources.topics` で参照する master entries を frontmatter で明示。これにより query → master の foreign-key 関係を保つ。

2. **Master 層の事実は重複させない**: 各論文の DOI / title / date 等の事実情報は `papers/NNN.md` に single source of truth を持ち、queries はそれを参照する形で記述。queries 内でこれら事実を verbatim にコピーしない (代わりに「#43 (Trilogy supplement, 2026-03-07)」のように参照記法を使う)。

3. **Articulation の出処を明示**: query 内 articulation が author-articulated (paper 内) か curator/dialogue articulated (paper 外) かを明示。前者は master へ移すべきで、queries に残るのは後者のみ。

4. **`status: active` 中は modest articulation 段階**: query 内 articulation は formal taxonomy commitment を含まない。`promoted-to-master` 判定は User explicit articulation gate 通過後に triggered。promote されたら status を `promoted-to-master` に変更し、対応する master file を update。

5. **Validator scope 外**: `derived/index.md` 等の auto-generated files は引き続き `papers/` + `topics/` のみを source とする。queries は `validate_frontmatter.py` の対象外 (将来 schema が安定したら別途 validator 追加候補)。

## 命名規則

`q-NNN-<theme-kebab-case>.md`

- NNN = 3桁zero-pad 連番 (q-001, q-002, ..., q-999)
- theme = kebab-case (lowercase + hyphen separator)、topic folder naming convention に整合
- 拡張子 = `.md`

## 現在の entries (v7.23 baseline)

| id | title | sources (papers / topics) | purpose | promoted? |
|---|---|---|---|---|
| q-001 | Fiber-bundle "unification" four-level disambiguation | (papers なし) / `derivative-order-mismatch`, `line-integrals`, `gauge-theory` | dialogue-prep + cross-reading | (active, dialogue origin v7.18) |
| q-002 | Einstein realism three-layer rearrangement | (papers なし) / `derivative-order-mismatch`, `line-integrals` | dialogue-prep + cross-reading | (active, dialogue origin v7.18) |
| q-003 | Derivative-Order Mismatch as ontological problem | #40, #41 / `derivative-order-mismatch`, `line-integrals`, `gauge-theory` | dialogue-prep + cross-reading | (active, dialogue origin v7.19→v7.20 commentary) |
| **q-004** | **Phenomenological gauge-relativity unification via line integral: unique-path commitment vs QM path integral** | **#1, #11, #18, #24, #29, #30, #31, #34, #37, #51, #52** / **`line-integrals`, `thermal-geodesic`, `gauge-theory`, `gravity-mediation`, `emergent-spacetime`, `zitterbewegung`, `compton-scale-geometry`** | **paper-draft-seed + cross-reading + dialogue-prep** | **(active, research-direction registration v7.22→v7.23, User explicit framing)** |

## Promote-to-master workflow

query 内 articulation が author-articulated に昇格 (例: 後続 paper で author 自身が articulate した) した場合:

1. 対応 master file (paper or topic) に articulation を移植
2. query frontmatter `status: active` → `status: promoted-to-master` に変更
3. query body 末尾に「**Promoted to**: `papers/NNN.md` § XXX (date)」 を追記
4. file 自体は削除しない (historical record として保持、status で識別)

## 注意事項

- queries 層は **書き換え高頻度**、各 dialogue session で active に update される動的層
- master 層 (papers / topics) との混同を避けるため、master 層に直接 dialogue-articulation を embed するのは避け、queries に集積する discipline を維持
- HANDOFF v7.X 全体の **modest articulation discipline** (HANDOFF v7.14 'welding-hub sub-type' 取下げ precedent) は queries 層内でも適用、formal commitment は status 変更を要する明示的判断

---

**設立 baseline**: HANDOFF v7.20 (2026-05-08), User explicit decision: 「**queries は、私にもあなたにもわかりやすいと思う。データベース的なノリッジ思考性を主張していてよい**」 + 「**既存の (f), (g) を移転しよう。できるだけ「データベースの正規化」を進めたい**」 + 「**本相談を実例として entry 収納しよう**」.
