---
id: q-001
title: "Fiber-bundle 'unification' four-level disambiguation protocol"
created: 2026-05-07
updated: 2026-05-08
status: active
sources:
  papers: []
  topics: [derivative-order-mismatch, line-integrals, gauge-theory]
  queries: [q-002, q-003]
dialogue_origin: "HANDOFF v7.17 → v7.18 transition session, User + commentator dialogue chain (本 articulation は v7.18 turn で initial surface、本 v7.20 transition で master 層から query 層へ正規化)"
purpose: dialogue-prep + cross-reading
---

# q-001: Fiber-bundle "unification" four-level disambiguation protocol

## 問題意識

A recurring difficulty in reading the gauge-gravity literature is that "unification" is used as a single word for several quite different claims. Surfaced in dialogue (User + commentator) following the v7.17 baseline, the curatorial framing distinguishes **four levels** at which a unification claim can be evaluated. Whether a given proposal — fiber bundle formalism, Yang–Mills gauge program, the line-integral observational layer of the 0-Sphere Model, or anything else — counts as "unifying" gauge theory and gravity depends entirely on which level is meant.

## 四層の整理

| Level | What is unified | Standard / mainstream status | 0-Sphere Model (line-integral framework) status |
|---|---|---|---|
| **(i) Formalism** | Mathematical structure: connection / curvature / parallel transport / holonomy as a common geometric language for both gauge and gravity | **Complete** — late-20th-century fiber bundle achievement (principal G-bundle for gauge, frame bundle for gravity); no controversy in the mainstream literature | Complete (inherited; no new contribution at this level) |
| **(ii) Predictive completeness** | Empirical adequacy: GR and Yang–Mills both make dependable predictions in their respective regimes; no internal conflict | **Complete** — predictions of GR and the Standard Model do not conflict where both apply; experimental physics has no problem proceeding | Complete (inherited; no new contribution at this level) |
| **(iii) Observational semantics** | What is "really observable" — curvature, connection, line integral, holonomy class, parallel-transport history | **Open / unresolved** — the Aharonov–Bohm effect surfaced this question explicitly (a phase shift through `F = 0` regions), but the question of whether observability is properly located at the curvature level, the connection level, the holonomy class level, or some combination has no settled answer | **Open with a specific position offered**: the observational primitive is the line integral `Φ = ∫_γ ω`; what is observable is *accumulated phase along finite paths*, not pointwise curvature and not the gauge-fixed connection in isolation |
| **(iv) Ontological** | What is real — local fields, gauge potentials, accumulated histories, Wilson loop classes — and what is gauge artifact | **Open / unresolved** — multiple positions coexist in the literature (Wilson loop realism, gauge potential realism via #36's instrumentalism-vs-realism contrast, holonomy realism, structural realism); no single agreed position | **Open with a specific position offered**: accumulated phase histories along finite paths are real; pointwise gauge potentials are gauge-dependent and therefore not directly real; pointwise local field values are derivative; Wilson-loop-class structure is the closed-trajectory specialization of the open-path primitive |

## 本 disambiguation の核心

The mainstream physics framing — "fiber bundle formalism unified gauge theory and gravity in the 1970s" — is **true at levels (i) and (ii) and false at levels (iii) and (iv)**. The reason it is rarely contested is that mainstream physics treats levels (iii) and (iv) as either *foundational philosophy* (and therefore not properly part of physics) or as *a definitional question* (and therefore not empirically decidable). The 0-Sphere series rejects both moves: it treats levels (iii) and (iv) as **physics questions**, gives them specific answers (the line integral is the observable primitive; accumulated phase histories are real), and accepts the consequences of those answers — including a different reading of what the gauge-gravity "unification" achieved by the fiber bundle formalism actually accomplished.

## 0-Sphere series 内での位置付け

Concretely: the topic `derivative-order-mismatch/` is positioned at levels (iii) and (iv). The derivative-order mismatch is a level-(i) phenomenon (a formal feature of the connection-vs-curvature derivative count). The 0-Sphere bridging move — relocating the observational layer to `Φ = ∫_γ ω` — is a level-(iii) reorganization that has level-(iv) ontological consequences (phase histories are real, point fields are derivative). The companion `derivative-order-mismatch/textbook.md` layer documents the level-(i)/(ii) achievement; the `derivative-order-mismatch/0sm.md` layer documents the level-(iii)/(iv) reading.

## 適用 protocol (curatorial filter として)

When a future paper or dialogue raises a "unification" claim, this four-level disambiguation can be applied as a filter. The questions are:

> *Which level is the claim made at? At which levels has it been demonstrated, and at which is it a stipulation?*

This protects the curatorial record from collapsing claims at one level into apparent claims at another.

## 関連 queries

- **q-002** (Einstein realism three-layer rearrangement): 本 q-001 と同 dialogue chain で surface した姉妹 framing、ontological positioning 軸を independent に articulate
- **q-003** (Derivative-Order Mismatch as ontological problem): commentator articulation chain で本 q-001 の level-(iii)/(iv) reading を強化、derivative-order mismatch を「unification 問題」 ではなく「ontological 階層問題」 として前景化

## Modest articulation status

Dialogue-articulated curatorial framing rather than a paper-internal articulation. Recorded as a **candidate applied filter** for subsequent paper curate sessions. Formal taxonomy addition (e.g., as a curatorial protocol in `SKILL.md` or as a Move 9 candidate in `derived/conceptual-moves.md`) awaits **User explicit authorial articulation**, per the discipline established at HANDOFF v7.14 ('welding-hub sub-type' withdrawal precedent).

## Move history

- **2026-05-07** (v7.17 → v7.18): Initial articulation in dialogue, embedded as section in `derivative-order-mismatch/0sm.md` "Levels of unification: curatorial disambiguation (dialogue-articulated)"
- **2026-05-08** (v7.19 → v7.20): Migrated to `queries/q-001-fiber-bundle-unification-disambiguation.md` as part of database normalization (User explicit decision: 「**できるだけ「データベースの正規化」を進めたい**」), original embedding in `derivative-order-mismatch/0sm.md` replaced with brief pointer reference
