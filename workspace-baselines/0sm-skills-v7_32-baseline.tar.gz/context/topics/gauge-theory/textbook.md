---
subject: gauge-theory
layer: textbook
title: "Gauge Theory: Standard Modern Treatment (Textbook Layer)"
applies_to: [17, 19, 20, 41, 42, 43, 44, 45, 48, 54, 55, 60]
status: stub
created: 2026-05-05
updated: 2026-05-08
related_topics:
  - subject: gauge-theory
    layer: 0sm
  - subject: line-integrals
    layer: textbook
  - subject: berry-phases
    layer: textbook
  - subject: topology
    layer: textbook
example_readings: []
tags: [gauge-theory, local-gauge-invariance, u1-gauge, su2-gauge, su3-gauge, yang-mills, fiber-bundle, qed, qcd, electroweak, wilson-line, wilson-loop, anomaly, ghost-field, brst, principal-bundle, connection-1-form, curvature-2-form]
---

# Gauge Theory: Standard Modern Treatment (Textbook Layer)

**Status:** Stub. This layer articulates the **standard QFT / mathematical-physics treatment** of gauge theory, against which the 0-Sphere Model's reinterpretation (in the sibling `gauge-theory/0sm.md` layer) is articulated. It is provided as a reference layer — when a 0-Sphere paper invokes a standard gauge-theoretic concept, this layer documents what the standard meaning is.

## Local gauge invariance principle

The cornerstone of 20th-century particle physics: physical observables must be invariant under **position-dependent (local)** symmetry transformations. For a complex field ψ(x), local U(1) invariance under

```
ψ(x) → e^{iα(x)} ψ(x)
```

requires introducing a **gauge connection** A_μ(x) transforming as

```
A_μ(x) → A_μ(x) − (1/e) ∂_μ α(x)
```

so that the **covariant derivative** D_μ ψ = (∂_μ + ie A_μ) ψ transforms covariantly. Promoting global → local symmetry is the **gauge principle** that generates dynamics: the Maxwell field A_μ for U(1), Yang-Mills fields for SU(2)/SU(3).

## Standard gauge groups in particle physics

| Gauge group | Theory | Force | Coupling |
|---|---|---|---|
| **U(1)** | QED | Electromagnetism | α ≈ 1/137 |
| **SU(2)** | Weak / electroweak | Weak force | α_W |
| **SU(3)** | QCD | Strong force | α_s |
| **U(1) × SU(2) × SU(3)** | Standard Model | All | combined |

## Geometric formulation: principal bundle

In modern mathematical physics, gauge theory is formulated as **connections on principal G-bundles**:

- **Base manifold** M (spacetime)
- **Structure group** G (the gauge group, e.g., U(1) for QED)
- **Principal bundle** P → M with fiber G
- **Connection 1-form** A ∈ Ω¹(P, 𝔤): parallel-transport prescription
- **Curvature 2-form** F = dA + A ∧ A: gauge-covariant field strength tensor
- **Wilson line / loop** W[γ] = P exp(∮_γ A): gauge-invariant observable along closed path

## Wilson lines and loops

Wilson lines W[γ_AB] = P exp(∫_γ A) are **path-ordered exponentials** of the connection. For an abelian U(1), this reduces to the Aharonov-Bohm phase exp(ie ∮_γ A_μ dx^μ). Wilson loops (closed paths) are **gauge-invariant observables** in lattice QCD and topological field theory.

## Anomalies and topological terms

- **Chiral anomaly** (Adler-Bell-Jackiw): classical chiral symmetry broken by quantum effects, links to topology via index theorem
- **θ-term** in QCD: ∫ θ Tr(F ∧ F), couples to instanton number
- **Chern-Simons forms**: topological gauge theories in 3D, central in topological insulators

## Position relative to the 0-Sphere Model

The 0-Sphere Model takes a **methodologically inverted** position relative to standard gauge theory:

- **Standard QFT**: gauge invariance is a **postulated symmetry principle** that generates the form of interactions
- **0-Sphere Model**: U(1) gauge structure is **emergent from kernel oscillation dynamics**, not postulated (#48 U(1) fiber bundle from kernel + photon-sphere geometry, #54 Maxwell as derived low-energy limit, #55 Wilson line as ontological primitive over A_μ)

This methodological inversion is the central thesis of the sibling `gauge-theory/0sm.md` layer.

## Applicable papers (textbook treatment invocation)

Currently identified papers that invoke standard gauge-theoretic concepts as comparison reference:

- **#17** (foundational): early gauge theme + standard local gauge invariance reference
- **#19**: Thomas precession with gauge interpretation, real polar vector spin
- **#20**: Noetherian Inversion programmatic, gauge structure inversion claim
- **#48**: U(1) fiber bundle articulation (0SM-native, references standard fiber bundle formalism)
- **#54**: Maxwell as low-energy limit (departure from standard "Maxwell as fundamental")
- **#55**: Wilson lines as ontological primitives (departure from standard "A_μ as fundamental")
- **#60**: gauge-theoretic comparison in geometric unification context

## Reading guidance

Standard textbook references (not currently parsed into layer content):

- **Peskin & Schroeder** "An Introduction to Quantum Field Theory" — Ch. 15 (QED), Ch. 16 (Yang-Mills)
- **Weinberg** "The Quantum Theory of Fields" Vol. II — gauge theories, BRST
- **Nakahara** "Geometry, Topology and Physics" — fiber bundle formulation, connection / curvature
- **Frankel** "The Geometry of Physics" — gauge theory on principal bundles
- **Kobayashi-Nomizu** "Foundations of Differential Geometry" — mathematical foundation

When at least 5 0-Sphere papers require explicit comparison against specific textbook treatments, this stub will be elevated with detailed sub-sections.
