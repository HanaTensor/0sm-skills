---
subject: background-independence
layer: textbook
title: "Background Independence in Quantum Gravity: Standard Treatment"
applies_to: [23, 24, 26, 29, 31, 32]
status: stub
created: 2026-05-05
updated: 2026-05-05
related_topics:
  - subject: background-independence
    layer: 0sm
  - subject: emergent-spacetime
    layer: 0sm
example_readings: []
tags: [background-independence, lqg, smolin, ashtekar, rovelli, causal-set, quantum-gravity]
---

# Background Independence in Quantum Gravity: Standard Treatment

**Status:** Stub. To be populated when standard textbook treatment of background independence is required as a comparison reference distinct from the 0-Sphere-native interpretation in `background-independence/0sm.md`.

## Future content scope

Standard literature on background independence in quantum gravity:

- **Smolin 2006** ("The Case for Background Independence", in *The Structural Foundations of Quantum Gravity*, Oxford UP) — foundational manifesto distinguishing background-dependent from background-independent approaches, cited in #23 as the central reference for the BI criterion.
- **Ashtekar-Lewandowski 2004** ("Background Independent Quantum Gravity: A Status Report", Class. Quant. Grav. 21, R53) — comprehensive review of LQG as implementation of BI, cited in #23.
- **Rovelli 2004** (*Quantum Gravity*, Cambridge UP) — textbook treatment of LQG and BI principles.
- **Thiemann 2007** (*Modern Canonical Quantum General Relativity*, Cambridge UP) — rigorous mathematical treatment of LQG.
- **Sorkin 1991, 2003** — Causal Set Theory as alternative BI program.
- **Smolin 2017** ("Temporal naturalism") — extension of BI to temporal structure.

Future content may include:

- **Definition and precisification**: What does it mean for a theory to be background-independent? Distinguishing partial vs full BI; perturbative vs non-perturbative BI.
- **Diffeomorphism invariance**: General covariance vs full BI (active diffeomorphisms vs passive coordinate transformations).
- **The hole argument**: Einstein's original motivation for BI in GR via the Loch-Loch (hole) thought experiment.
- **Background independence in string theory**: String theory's claim to BI (M-theory, AdS/CFT) vs critiques (Smolin, Penrose) that perturbative string theory is background-dependent.
- **Lattice gauge theory's background dependence**: Why lattice formulations remain background-dependent (lattice as discretization of pre-given spacetime) and the difficulty of fully BI lattice approaches.
- **LQG quantization procedure**: Spin networks as background-independent quantum geometry; area and volume operators with discrete spectra.
- **Causal Set Theory**: Discrete causal sets as BI alternative to continuous spacetime.
- **The relationship of BI to emergence**: Background-independent theories often imply emergent spacetime, but the converse need not hold.

## Distinction from 0sm layer

The companion file `background-independence/0sm.md` documents the **0-Sphere-native treatment**: BI as methodological criterion realized through proper-time parametrized worldline processes, with `S^0` (zero-sphere) as pre-geometric seed and spacetime as derived bookkeeping device. The 0-Sphere Model belongs to the same broad class as LQG and Causal Set Theory (BI quantum gravity) but with its own specific ontology (kernel structure, photon sphere, internal phase).

This textbook layer, when populated, will document the **standard treatment** — particularly the LQG implementation of BI which is the closest mainstream cousin to the 0-Sphere Model's program.

## Threshold for elevation

This stub is elevated to **active** status when at least 5 0-Sphere papers explicitly require detailed comparison against standard textbook background-independence formalism. Current count: **6** papers in `applies_to` (#23, #24, #26, #29, #31, #32), so the threshold is technically met, but most current invocations are at the conceptual level (citing Smolin 2006 / Ashtekar-Lewandowski 2004) without requiring the detailed technical formalism. The stub remains in placeholder state until a new paper requires explicit technical comparison.

## Reading guidance

Until populated, background-independence questions about the standard treatment should be answered from the cited standard literature directly (Smolin 2006, Ashtekar-Lewandowski 2004, Rovelli 2004) and the companion file `background-independence/0sm.md` provides the 0-Sphere-native interpretation.
