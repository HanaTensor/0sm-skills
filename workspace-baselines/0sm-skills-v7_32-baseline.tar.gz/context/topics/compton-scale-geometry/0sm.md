---
subject: compton-scale-geometry
layer: 0sm
title: "Compton-Scale Internal Geometry: Kernel Separation and Characteristic Length"
applies_to: [2, 3, 5, 11, 21, 22, 23, 24, 33, 34, 36, 37, 38, 42, 43, 45, 46, 47, 49]
status: stub
created: 2026-05-06
updated: 2026-05-07
related_topics:
  - subject: zitterbewegung
    layer: 0sm
  - subject: spin
    layer: 0sm
  - subject: thermodynamics
    layer: 0sm
  - subject: gravity-mediation
    layer: 0sm
example_readings: []
tags: [compton-wavelength, internal-geometry, kernel-separation, characteristic-length, lambda-c, electron-internal-structure, photon-sphere, 0sphere-model]
---

# Compton-Scale Internal Geometry: Kernel Separation and Characteristic Length

**Status:** Stub. The Compton wavelength λ_C = ℏ/(m_e c) ≈ 3.86 × 10⁻¹³ m serves as the **fundamental characteristic length** of the 0-Sphere Model's internal geometry. The two kernels (#1 origin) are separated by a distance of order λ_C, and most observable internal dynamics (Zitterbewegung, kernel oscillation, photon-sphere mediation) operate at this scale.

## Central commitment

The Compton wavelength is **not** merely a dimensional combination of physical constants — it is the **operational scale of internal electron structure** in the 0-Sphere Model. All internal phenomena (energy circulation, ZB oscillation, photon-mediated synchronization) are anchored to λ_C-scale geometry.

```
λ_C = ℏ / (m_e c) ≈ 3.86 × 10⁻¹³ m       (#38 Eq. I.1, foundational scale)
```

## Why Compton scale (not Bohr radius, not classical electron radius)?

The 0-Sphere Model commits to **Compton-scale internal geometry** rather than:

- **Bohr radius** a₀ ≈ 5.29 × 10⁻¹¹ m (atomic scale, ~137 × λ_C): too large, atomic scale is **emergent** from electron-nucleus interaction, not internal
- **Classical electron radius** r_e ≈ 2.82 × 10⁻¹⁵ m (~λ_C / 137): too small, classical r_e is a **dimensional artifact** of pre-quantum electrostatic energy, no fundamental significance in the framework
- **Planck length** ℓ_P ≈ 1.6 × 10⁻³⁵ m: irrelevant scale for electron internal structure

**Compton scale uniquely satisfies**:
1. ZB period T_zb ≈ ℏ / (m_e c²) (#38 Section IV.B)
2. Kernel separation compatible with two-body internal structure (#1)
3. Photon-sphere internal geometry scale (#48 U(1) fiber bundle)
4. Universal across all electron observables (g-factor, AMM, spin, ZB)

## Foundational papers in the topic

| Paper | Role | Compton-scale invocation |
|---|---|---|
| **#2** | **series-earliest articulator (草稿止まり variation)** | **Section II.A Fig 2 caption「Bare electrons at two points, −a and +a, are separated by a distance of 2a, which is the same length of the electron's Compton wavelength」 + Section III.A 「first destination point separated by the radial spread of the virtual photon to the Compton wavelength」 が series で **2a = λ_C = step 幅 = 仮想光子半径** の三項 identification を最初に明示 articulate (2018-12)。但し本論文 specific machinery (整数倍位相 nπ discretization、linear-motion variation) は後続論文に直接 propagate せず草稿止まり pattern、conceptual seed としてのみ functioning** |
| **#3** | **canonical visual articulation = current 「全ての基盤」** | **User explicit articulation (HANDOFF v7.3): 「**Figure 1 の考察は、現在の zitterbewegung の振動と光子球の様子を描いており、'全ての基盤' になっている。またコンプトン波長オーダーでの議論のもとにもなっている。**」 ─ Fig 1 五位相 (a)-(e) cycle (bare electrons at fixed ±a, virtual photon yellow sphere SHM, 2a = Compton wavelength) が **canonical zitterbewegung + Compton-scale visual primitive**。#2 の linear-motion variation を skip し、#1 oscillation picture を canonical visual form に固化、後の #38 systematic foundational invocation の 8 年早い visual root** |
| **#5** | **discrete-vs-continuous distinction articulator** | **User explicit articulation (HANDOFF v7.4): 「**コンプトン波長でカーネル A → B へと移動するため、光子球は連続的なエネルギーだが、カーネルが移転する場所はコンプトン波長を基準にして離散的な箇所にもたらされる、と論じている。エネルギー移動（輻射勾配に伴う光子球の移動）は連続的だが、カーネルは離散的に移転する点を述べた最初の論文。**」 ─ シリーズで **photon sphere = continuous energy / kernel = discrete (at λ_C scale)** distinction を最初に formal articulate (2019-09)。後の thermal-geodesic + line-integrals 框架の foundational distinction、#38 systematic invocation の 7 年早い conceptual root** |
| #11 | quantum oscillations | ZB + geodesic paths + proper time at Compton scale via radiative energy transfer |
| #21 | observer-dependence | Compton-scale internal frame as central reference for AMM observer-dependent interpretation |
| #22 | gravitational redshift | Compton-scale internal geometry yields gravitational redshift Δν/ν ≈ 5.29 × 10⁻¹⁰ |
| #23 | emergent spacetime | Compton scale as boundary between internal-emergent and external-spacetime regimes |
| #24 | thermal geodesics | Compton-scale thermal geodesic paths |
| #33 | topological confinement | Energy topologically confined at Compton scale |
| #34 | gravitational emergence | Compton-scale photon-mediated synchronization |
| **#38** | **systematic foundational invocation** | **Eq. I.1 establishes λ_C as the framework's central length scale, "two localized energy concentrations (kernels) separated by a finite distance of order λ_C". 8 年遡る #2 の conceptual root + 7 年遡る #3 の canonical visual articulation を systematic 化** |
| #49 | photon-sphere fragmentation | Compton-scale photon sphere as gravitational mediator origin |

## Methodological position

The 0-Sphere Model's commitment to Compton-scale internal geometry is a **strong empirical hypothesis**:

- It implies the electron has resolvable internal structure at ~10⁻¹³ m scale, **far above** the Planck scale and well within the reach of next-generation ultrafast spectroscopy
- It is **falsifiable**: failure to observe Compton-scale internal dynamics in attosecond-resolution experiments would constrain the framework
- It is **distinguishable** from QED's pointlike electron: QED treats the electron as a point with quantum-fluctuation-dressed cloud, the 0-Sphere Model treats it as a real bipartite Compton-scale structure

## Connection to other topics

- **`zitterbewegung/0sm.md`**: ZB occurs at Compton-scale (period T_zb ~ ℏ/m_e c² corresponds to spatial scale λ_C)
- **`spin/0sm.md`**: spin emerges from Compton-scale two-kernel oscillation + Thomas precession
- **`gravity-mediation/0sm.md`** (#34, #49, #57+): gravitational mediation operates via Compton-scale photon-sphere fragments
- **`thermodynamics/0sm.md`**: kernel-internal TPE oscillation occurs at Compton scale

## Future content scope

- **Experimental verification at Compton scale**: when attosecond + electron microscopy achieves λ_C-scale resolution, direct test of two-kernel geometry
- **Compton-scale vs. classical-limit transition**: at what mass / energy does Compton-scale internal structure become irrelevant? Macromolecule interferometry (Arndt group reach) provides empirical handle
- **Generalization to muon, tau**: λ_C-equivalent for heavier leptons via their respective rest masses, predictions for muon-internal-structure should follow

## Reading guidance

- **Primary entry**: #38 Eq. I.1 for foundational scale articulation, #11 for ZB + geodesic + proper time integration
- **Adjacent topics**: `topics/zitterbewegung/0sm.md`, `topics/spin/0sm.md`, `topics/gravity-mediation/0sm.md`
