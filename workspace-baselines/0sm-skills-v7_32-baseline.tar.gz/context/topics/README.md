# topics/ — 解釈レンズ層

> File: `context/topics/README.md`
> 用途：topics/ 配下のファイル構造・命名規約・運用則の単一参照点

---

## 1. このフォルダの役割

`topics/` は 0-Sphere Model の論文群を読むための**解釈レンズ**を集めたフォルダ。各 topic ファイルは、特定の物理現象や概念について「**論文をこのレンズで読み直すとどう見えるか**」を定める。

**重要な認識:**

論文は静的な属性の束ではなく、レンズによって異なる像を結ぶ対象である。同じ論文 #49 を `thomas-precession` レンズで読むと運動学的フレーム、`weak-equivalence-principle` レンズで読むと等価原理導出フレーム、と異なる読みが共存する。これは 0-Sphere Model 自身の構造（同一の Wilson line W[A→A'] が経路微分で F_μν、端点微分で g_μν を生む——単一対象、複数機能）をメタデータ層に投影した設計。

---

## 2. ディレクトリ構造

主題（subject）ごとにフォルダを切り、その中で**層（layer）** を表す短いファイル名を使う：

```
topics/<subject>/<layer>.md
```

**例:**

```
topics/
├── README.md                          # このファイル
│
├── spin/                              # 主題: スピン
│   ├── classical.md                   # 古典・直観層
│   ├── textbook.md                    # 学術正統層
│   └── 0sm.md                         # 0-Sphere 独自解釈層
│
├── thomas-precession/                 # 主題: Thomas 歳差
│   ├── textbook.md                    # 学術正統層
│   └── 0sm.md                         # 0-Sphere 独自解釈層
│
└── tonomura-experiment.md             # 単一スコープ主題（フラット）
```

---

## 3. Subject 命名規約

- ASCII slug、小文字、ハイフン区切り
- 物理現象または概念の名前
- 例: `spin`, `thomas-precession`, `berry-phase`, `line-integrals`, `zitterbewegung`, `weak-equivalence-principle`

**避けるべき命名:**

- 人物名（`tomonaga`, `dirac` 等）— 内容が把握しにくい
- 数式記号（`gamma-1-plus-a` 等）— 検索性が悪い
- 略号（`wep` ではなく `weak-equivalence-principle`）— ただし広く通用する場合は許容（`zitterbewegung` のドイツ語表記など）

---

## 4. Layer 命名（標準三層）

| ファイル名 | 意味 | 想定内容 |
|---|---|---|
| `classical.md` | 古典・直観層 | 量子論以前または準古典的扱い、直観モデル、Stern-Gerlach の幾何学的解釈 |
| `textbook.md` | 学術正統層 | 現代物理の正統教科書扱い、SU(2)/QFT/Dirac 方程式、Tomonaga「スピンはめぐる」のような講義系 |
| `0sm.md` | 0-Sphere 独自解釈層 | Hanamura 独自の 0-Sphere Model 解釈、他の二層と異なる主張 |

**追加可能な Layer（必要に応じて）:**

- `historical.md` — 歴史的展開、人物中心
- `experimental.md` — 実験的検証の論点
- その他、必要が顕在化した時点で追加

---

## 5. フォルダ作成の閾値

主題ごとに**2 つ以上の層が必要になった時点で**フォルダ化する。1 層しか必要ない小さい主題は、フォルダではなく単一ファイルで OK：

```
topics/
├── spin/                              # 三層構造（フォルダ）
├── thomas-precession/                 # 二層構造（フォルダ）
└── tonomura-experiment.md             # 単一スコープ（フラット）
```

**フォルダから単一ファイルへの「降格」も可能:**

層を削減した結果 1 層になったら、フラットに戻して構わない。命名規約は単方向ではない。

---

## 6. 新トピック作成の閾値

以下を**全て**満たす場合のみ新規作成：

- 3 本以上の論文から実質的に参照される見込みがある
- 各論文で毎回再説明すると分量・整合性の負担が大きい
- 既存トピックとは独立した主題である

---

## 7. ファイル frontmatter 必須フィールド

各 topic ファイルは以下を frontmatter に含める：

```yaml
---
subject: thomas-precession    # フォルダ名と一致
layer: textbook               # ファイル名と一致（拡張子なし）
title: "Thomas Precession: Textbook Treatment via Tomonaga's Lectures"
applies_to: [10, 19, 47, 48, 49, 50, 51, 52]   # 適用論文番号
status: active                # active | stub | deprecated | superseded
created: 2026-04-03
updated: 2026-04-05
related_topics:
  - subject: spin
    layer: textbook
example_readings:             # ハイブリッド構造の生成クエリ層
  - paper: 10
    aspect: "kinematic necessity of v×a ≠ 0"
  - paper: 49
    aspect: "inversion of cause-effect framing"
tags: [spin, kinematics, thomas-precession]
---
```

**`applies_to` は canonical:**

論文 frontmatter `topics_invoked` と build action で整合検証される。`applies_to` を更新したら、対象論文の `topics_invoked` も整合させる。

---

## 8. Example readings セクション（ハイブリッド構造）

各 topic の本文末尾に、`example_readings` の各エントリに対応する読解を 1〜3 文で記述する：

```markdown
## Example readings: applying this lens to specific papers

### Reading #10 through this lens
[1〜3 文の読解]

### Reading #49 through this lens
[1〜3 文の読解]
```

**設計則:**

- `applies_to` の中から代表的に 2〜5 論文を選ぶ（全部書く必要はない）
- 各読解は 1〜3 文で簡潔に。レンズが論文をどう変容させるかを示す
- 同じ論文が複数 topic で example reading として登場することは**むしろ望ましい**——多重読解の可視化そのもの
- 読みの内容に大きな進展があった場合のみ更新（論文追加のたびの更新は不要）

---

## 9. Stub ファイルの扱い

将来内容を充実させる予定で先に place-holder として作成する場合：

```yaml
---
subject: spin
layer: classical
title: "Spin: Classical and Pre-Quantum Treatments"
applies_to: []
status: stub                  # 重要: stub 状態を明示
created: 2026-05-05
updated: 2026-05-05
---

# Spin: Classical and Pre-Quantum Treatments

**Status:** Stub. To be populated when classical/intuitive spin
content needs a dedicated home.

Future content scope:
- [箇条書きで将来の内容方針]
```

`status: stub` の状態で残っているファイルは、build action から「placeholder」フラグ付きで derived/ に集計される。

---

## 10. 現行 topics 一覧（2026-05 時点）

| Subject | Folder/File | Layers | Status |
|---|---|---|---|
| spin | `spin/` | classical (stub), textbook (stub), 0sm (stub) | early |
| thomas-precession | `thomas-precession/` | textbook (active), 0sm (stub) | mature |

将来追加見込みの主題：

- `berry-phase/` — #26, #38, #48 の核心
- `line-integrals/` — #29, #30, #31, #40, #51 のスレッド
- `zitterbewegung/` — 0-Sphere 中心予測
- `lorentz-contraction/` — #10, #35, #36, #47
- `weak-equivalence-principle/` — #52
- `thermodynamics/` — #1, #24, #34
- `gauge-theory/` — #17, #19, #38, #48
- `dirac-equation/` — #7, #51
- `helicity-chirality/` — #50

---

*Last updated: 2026-05-05*
