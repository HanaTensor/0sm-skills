---
subject: double-slits
layer: 0sm
title: "Double-Slit Interference in the 0-Sphere Model: Visibility Ceiling from Internal Geometry"
applies_to: [4, 38]
status: stub
created: 2026-05-06
updated: 2026-05-06
related_topics:
  - subject: spin
    layer: 0sm
  - subject: thermodynamics
    layer: 0sm
  - subject: thomas-precession
    layer: 0sm
  - subject: topology
    layer: 0sm
  - subject: zitterbewegung
    layer: 0sm
example_readings: []
tags: [double-slit, interference, visibility, tonomura, matter-wave, electron-interference, biprism, 0sphere-model, c-30-thread]
---

# Double-Slit Interference in the 0-Sphere Model: Visibility Ceiling from Internal Geometry

**Status:** Active stub. Founded by `#4` (2019-07-28, "Perfect Contrast cannot be obtained in the Electron Double-Slit Experiment") and systematically completed by `#38` (2026-02-21, "Electron Interference from Internal Geometry"). The two papers form an indissoluble companion pair (`#38 companion_to: 4`) spanning the **C-30 thread** ("Internal-geometry origin of double-slit visibility limit / Pvis < 1 ceiling for matter waves vs. Pvis = 1 photons").

## Central commitment

The systematic deviation **Pvis ≠ 1** observed in matter-wave double-slit experiments — Tonomura 1989 (electrons), Arndt 1999 (C₆₀), Carnal & Mlynek 1991 (helium atoms) — is **NOT** experimental error or environmental decoherence, but **theoretical inevitability** rooted in the electron's internal two-kernel spinorial structure (#1 origin). This contrasts with photon double-slit experiments where Pvis = 1 is achievable in principle.

## Founding paper (#4, 2019-07-28)

**Deterministic baseline articulation**: Two bare electrons (Spinor1 with TPE Te1 = E₀cos⁴(ωt/2), Spinor2 with TPE Te2 = E₀sin⁴(ωt/2)) split before reaching the biprism and pass through different slits with **phase-dependent asymmetric amplitudes** A_spinor1 = cos²θ, A_spinor2 = sin²θ.

Key contributions:
- **Visibility metric** Pvis ≡ (p_max − p_min)/(p_max + p_min) (Eq. II.1, with Tonomura 2010 email correspondence as historical motivation source)
- **Modified fringe formula** |ψ(x)|² = (cos²θ · J₀(kr₁) + sin²θ · J₀(kr₂))² (Eq. III.6, Bessel-function approach)
- **Six-phase deterministic sample** (50:50, 66:34, 79:21, 91:8, 98:2, 100:0) demonstrating qualitative Pvis ≠ 1 (Fig. 6, Table I)
- **Photon-vs-electron dichotomy** (Section IV.B, Section V): photon-as-vector (no TPE structure → Pvis = 1) vs electron-as-spinor-pair (TPE asymmetry → Pvis < 1)
- **Phase-controlled emission proposal** (Section V conclusion): falsifiable prediction that controlled phase emission would yield variable visibility, currently technically-difficult

## Systematic completion (#38, 2026-02-21)

**Probabilistic-completion articulation**: 7-year program continuity from #4, achieving closed-form analytical results.

Key contributions:
- **Single-electron visibility** V(θ) = 2cos²θsin²θ / (cos⁴θ + sin⁴θ) (Eq. IV.3), continuous from V(0) = 0 to V(π/4) = 1
- **Universal closed-form bound** ⟨V⟩ = (1/2π) ∫₀^{2π} V(θ) dθ = √2 − 1 ≈ 0.4142 (Eq. IV.4) — **configuration-independent prediction**
- **Monte Carlo verification** N = 20,000 electrons with θ ∼ U(0, 2π), observed ⟨V⟩ = 0.4132 (Fig. 1, within 0.24% of theoretical)
- **SU(2) scalarization argument** (Section III.C-D): "the minimal scalar invariant is therefore quartic" — 4-power energy identity necessity from spinorial double-cover
- **Quartic-vs-quadratic identity contrast** (Section IV.C): photon quadratic identity has no intrinsic cross term (allowing Pvis = 1), electron quartic identity has positive-definite cross term as real internal radiation kinetic energy (forcing Pvis < 1)
- **Zitterbewegung connection** (Section V.B): v_zb ≈ 0.04047 c via RMS-corrected Lorentz contraction + a_e^exp input — directly links visibility ceiling to internal Zitterbewegung dynamics

## Experimental anchors

The topic is grounded in four experimental program families:

1. **Tonomura 1989** (electron biprism, Hitachi): single-electron buildup of interference pattern, observed Pvis < 1 with non-zero trough intensity. Tonomura's 2010 email correspondence (cited in #4 Section II via Ezawa 2016 ref [3]) explicitly raises the **theoretical-vs-experimental** question that #4 answers affirmatively.
2. **Arndt 1999** (C₆₀ molecules, Vienna): wave-particle duality of fullerenes, also Pvis < 1.
3. **Carnal & Mlynek 1991** (helium atoms, ETH Zürich): Young's double-slit with atoms, Pvis < 1.
4. **Magaña-Loaiza 2016** (photons, three-slit interference): cited in #4 ref [4], anchors the photon-side of the dichotomy where Pvis ≈ 1 is approached.

## Methodological position

Two interpretive layers coexist:

- **Mechanistic**: Pvis < 1 originates from the positive-definite kinetic energy term (1/2)sin²(2θ) representing real internal radiation circulation between kernels. This term cannot vanish (it is real KE), thus complete destructive interference is impossible.
- **Geometric**: Under the SU(2) double-cover, scalar observables require quartic invariance. Photons (no internal kernel structure, only a single complex amplitude) satisfy quadratic identity cos²θ + sin²θ = 1 with no cross term. Electrons (two-kernel spinorial structure) satisfy quartic identity with intrinsic cross term.

Both layers are equivalent and articulated in #38 Sections III.D + IV.A-C.

## Structural relation pattern (curatorial note)

#38 main.tex bibliography does **not** formal-cite #4 (refs [1]-[14] include Tonomura 1989, Hanamura 2025/2024/2023 papers but exclude #4). However, #38 README.txt explicitly acknowledges "The visibility bound ⟨V⟩ = √2 − 1 was originally noted in paper #4 (2019, Zenodo 10.5281/zenodo.17759699); the present work derives it systematically." This is the **structural-lineage vs citational-lineage separation** pattern, structurally analogous to #34 ↔ #33 (title sharing without bibliography citation), formalized via `companion_to: 4` in #38 frontmatter based on user explicit instruction (HANDOFF v6 → v7 session).

## Future content scope

- **Phase-controlled emission falsifiability**: when attosecond electron emission control becomes feasible, V(θ) prediction of #38 Fig. 1 right panel (concentration at V ≈ 0 endpoint + V ≈ 1 endpoint with broad intermediate distribution) becomes directly testable per-electron
- **Quantitative comparison with experimental data**: #38 opens_tasks (i) — Tonomura 1989 / Arndt 1999 / Carnal 1991 specific Pvis values vs framework prediction, requires source characteristics + detection geometry data
- **Internal polarization-resolved radiative structure**: #38 opens_tasks (ii) — dynamical formulation
- **Path-resolved propagation**: #38 opens_tasks (iii) — relation between internal polarization-resolved radiative structure and external path-resolved electron propagation in double-slit configurations
- **Extension to heavier matter waves**: macromolecule interferometry (current Arndt group reach), prediction is universal Pvis < 1 for any internal-structure-bearing matter wave; Pvis → 1 in classical (high-mass) limit would falsify

## Reading guidance

- **Primary entry**: read #4 (2019) for the founding articulation + Tonomura email historical context, then #38 (2026) for systematic completion with closed-form results
- **Adjacent topics**: `topics/spin/0sm.md` (SU(2) spinorial structure machinery), `topics/zitterbewegung/0sm.md` (v_zb derivation), `topics/thomas-precession/0sm.md` (relativistic compatibility check)
- **Thread context**: this topic is the empirical-phenomenon-family anchor for the **C-30 thread** (visibility ceiling); the thread member status is currently {#4 founder, #38 sole current member}, expansion expected when phase-controlled experimental verification becomes feasible
