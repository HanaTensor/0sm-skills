---
subject: line-integrals
layer: 0sm
title: "Line Integrals as 0-Sphere Ontological Primitive"
applies_to: [17, 23, 29, 30, 31, 32, 33, 34, 35, 36, 37, 39, 40, 41, 42, 43, 44, 45, 46, 51, 52, 53, 54, 55, 56, 57, 59, 60]
status: active
created: 2026-05-05
updated: 2026-05-08
related_topics:
  - subject: line-integrals
    layer: textbook
  - subject: thermal-geodesic
    layer: 0sm
  - subject: synge-world-function
    layer: 0sm
  - subject: background-independence
    layer: 0sm
  - subject: berry-phases
    layer: 0sm
  - subject: gauge-theory
    layer: 0sm
  - subject: topology
    layer: 0sm
  - subject: emergent-spacetime
    layer: 0sm
example_readings: []
tags: [line-integrals, ontology, wilson-line, 0sphere-model, line-integral-trilogy, connection-one-form, holonomy, parallel-transport]
---

# Line Integrals as 0-Sphere Ontological Primitive

The 0-Sphere Model treats **line integrals of connection one-forms along proper-time worldlines** as physical primitives — the relevant geometric quantity is `∫_γ ω · dτ` rather than surface integral of curvature `∫∫ R dA` or integration of fiber bundles themselves. This **methodological inversion** from curvature-centric to connection-line-integral-centric framing is the defining commitment of the C-3 (線積分存在論) thread.

## Founder paper

This topic's **explicit founder is `#29`** (Geometric Structure of Spinorial Phase Accumulation along Thermal Geodesics, 2025-12-27, DOI 10.5281/zenodo.18067760), Part I of the Line Integral Trilogy. Section II of #29 articulates the central methodological commitment:

> *the relevant geometric quantity is the line integral of a connection, rather than the curvature of the spatial path or the integration of a fiber bundle itself.*

Earlier seed-level content exists in `#1` (implicit origin), `#17`, `#20`, `#23` (A-B kernel geodesic concept), but **#29 is the first paper to make the line-integral primitive ontology explicit and programmatic**.

## The Line Integral Trilogy (#29 → #30 → #31)

The defining structural unit of this topic:

| Part | Paper | Role |
|---|---|---|
| **Part I** | **#29** | Foundational framework: line-integral-of-connection as primary observable; Thomas precession spinorial connection along thermal geodesic; Poincaré-Thomas correspondence (Eq. II.2); dimensional independence; Table I discrete-continuous mapping |
| **Part II** | **#30** | Curvature to Connection: Einstein field equations reframed as global consistency conditions on aggregated line integrals; `Φ = ∫_γ ω` as primary observable, `T_µν` as derived; microscopic flexibility ↔ macroscopic coherence |
| **Part III** | **#31** | Line Integrals as Fundamental Observables: generalization to AB effect, Berry phase, Wilson loops; line-integral primitive applied across physics (forward dangling, not yet curated) |

## Topic content scope

This layer documents the 0-Sphere-native treatment of line integrals, distinguishing it from textbook gauge-theoretic treatment:

- **Fixed-endpoint line integrals as primitives** (#29, #30, #31, #40)
- **Spinorial connection along thermal geodesic** (#29) — Thomas precession `Ω_T ∝ a × v` as central machinery
- **Poincaré-Thomas correspondence** (#29 Eq. II.2) — `∫_γ ω_hyp ↔ (1/2) ∫ (a × v) dτ` mapping hyperbolic geometry to internal connection
- **Two-lobe structure of `a × v`** (#29) — π each between kernel endpoints, totaling 2π (one-way) / 4π (round-trip = SU(2))
- **Dimensional independence** (#29 Section III) — geodesic plane argument, Lorentz connection in SO(n,1)
- **Discrete ↔ continuous correspondence Table** (#29 Section III, Table I) — transition operator T ↔ connection Γ realizing #23's emergent-spacetime program in continuum
- **Curvature to Connection / Einstein eq as global checksum** (#30) — `Φ = ∫_γ ω` primary, `T_µν` derived, microscopic-flexibility ↔ macroscopic-coherence duality
- **Helical trajectory + line integral → metric emergence** (#51) — internal helical motion + fixed-endpoint line integrals → spacetime metric reconstruction
- **Maxwell from line integrals as low-energy limit** (#54) — Maxwell electromagnetism as derived (NOT postulated) sector of underlying line-integral ontology
- **Wilson line as four-function ontological object** (#55) — single Wilson line generates Maxwell sector (path-derivative) and metric sector (endpoint-derivative) simultaneously
- **Framework boundary** (#56) — scale at which local-field and directed-path descriptions diverge
- **Methodological principle "single object, multiple functions"** (#55) — applies broadly throughout the 0-Sphere Model

## The connecting thread

**Line integrals carry directional information** (chirality, time orientation, holonomy class) that local field descriptions discard. The 0-Sphere Model treats this directional information as physically primary, not emergent. This is the structural reason the model's predictions (e.g., `χ = sign(da/dt)` chirality from #50) cannot be obtained from local-field-theory framings.

## Line integrals as the shared observational layer (dialogue-articulated central thesis)

A series-level meta-articulation surfaced in dialogue (User + commentator) places the line-integral primitive in a broader curatorial role:

> *Observable quantities appear not in local fields but in accumulated geometric histories.*

This statement names what the Trilogy (#29–#31) accomplishes at the foundational level and what later papers ride on. The vocabulary that recurs across the series — **observables / accumulated phase / line integral / transport / holonomy / history dependence** — is the lexicon of this central thesis. Where standard physics often reaches for *force / symmetry / quantization / scale*, the 0-Sphere series reaches for the history-structure analogs.

### Three-boundary-regions framework (where the line integral is invoked as bridge)

The line-integral observational layer functions as the shared element across three boundary regions in which the 0-Sphere series reorganizes existing theoretical structure:

| Boundary region | Bridging carrier | Adjacent topic with detailed treatment |
|---|---|---|
| Geometry ↔ quantum (spinor transport) | Spinorial connection along thermal geodesic; Poincaré–Thomas correspondence; Berry phase and holonomy as transport histories | `spin/`, `berry-phases/`, `thomas-precession/` |
| Gauge theory ↔ gravity (derivative-order mismatch) | `Φ = ∫_γ ω` with `ω = A` (gauge) or `ω = Γ` (gravity); pre-divergence layer of physical observables | `derivative-order-mismatch/0sm.md` (detailed treatment) |
| Macroscopic gravity ↔ microscopic oscillation | Accumulated phase / closed or semi-closed history / finite path integrals as common substrate; **history-structure unification, not scale-unification** | `zitterbewegung/`, `gravity-mediation/`, `compton-scale-geometry/` |

The methodological move shared across the three regions, articulated in dialogue:

> *境界を消すのではなく、観測層を共有化する。力の統一ではなく、観測の統一に近い。*  
> *Not erasing the boundaries — sharing the observational layer above them. Closer to unification of observation than to unification of forces.*

The local distinctions are preserved (gauge curvature ≠ gravitational connection; Aharonov–Bohm ≠ Shapiro delay; quantum spin ≠ classical rotation). The line-integral layer is shared. This **non-reductionist** structure is what distinguishes the line-integral primitive from standard "unification" attempts: the primitive does not collapse the underlying theories into one another; it identifies a layer at which their observational content can be compared without that collapse.

**Curatorial note (formal Move 8 entry, v7.22)**: the three-boundary-regions framework was held in **modest articulation status across HANDOFF v7.17 → v7.21** (5 transitions) and was formally articulated as **Move 8 (`observational-layer-sharing-meta-pattern`)** in `derived/conceptual-moves.md` at HANDOFF v7.22, on User explicit decision. The framework now functions as the **methodological meta-pattern** companion to Move 7 (epistemic meta-pattern), together forming the two-axis meta-pattern navigation chassis. Related dialogue-articulated framings reside in `queries/q-001` (four-level "unification" disambiguation), `queries/q-002` (Einstein realism three-layer rearrangement), and `queries/q-003` (derivative-order-mismatch as ontological reading); the present `line-integrals/0sm.md` subsection remains the **master-layer anchor** for the framework while its formal taxonomy commitment lives in `conceptual-moves.md::Move 8`.

**Einstein realism との関係 (moved to queries layer)**: the line-integral observational layer can be read as a **rearrangement of Einstein realism's three layers**. This dialogue-articulated curatorial framing was migrated to the queries layer at v7.20 as part of database normalization. **See**: `queries/q-002-einstein-realism-rearrangement.md` for the full three-layer mapping (local realism / geometric realism / background independence).

## Key technical results across the topic

- **Line integral of connection one-form** as primary observable (vs surface integral of curvature) — #29 explicit articulation, #30/#31 elaboration
- **Spinorial 2π / Bosonic π asymmetry** along one-way thermal geodesic traversal — #29 two-lobe derivation
- **SU(2) holonomy nontrivial when SO(3) appears trivial** — representation-dependent line integral observability — #29 Section II
- **Poincaré upper half-plane as universal geometric prototype** — connection-driven phase accumulation independent of ambient dimension — #29 Section III
- **Higher mode excitation as same-geodesic phase winding** (NOT new geometric path) — energy quantization geometric realization — #29 Section II
- **Einstein field equations as global checksum on aggregated line integrals** — #30 (Part II)
- **Helical trajectory generating spacetime metric via fixed-endpoint line integrals** — #51

## Reading guidance

**Foundation (Line Integral Trilogy)**:
- `#29` (Part I, founder) — line-integral-of-connection primary observable, Thomas precession spinorial connection, Poincaré-Thomas correspondence, dimensional independence
- `#30` (Part II) — Einstein equations as global consistency, microscopic flexibility ↔ macroscopic coherence
- `#31` (Part III, forward) — generalization to AB / Berry / Wilson loops

**Geometric realization**:
- `#40` (early helical hint, forward)
- `#51` (full helical structure + metric emergence)

**Maxwell sector**:
- `#54` (Maxwell as derived low-energy limit)

**Ontological elevation**:
- `#55` (Wilson line as ontological primitive, four-function object)
- `#56` (framework boundary divergence)

**Adjacent topics**:
- `berry-phases/0sm.md` — Berry phase formalism (#26 founder); line-integral framework provides Berry phase machinery via connection one-form line integrals
- `topology/0sm.md` — topological protection, fiber bundles; line-integral observables determine holonomy class, a topological invariant
- `gauge-theory/0sm.md` — Aharonov-Bohm gauge connection, Wilczek-Zee non-Abelian phase, gauge structure as emergent from line-integral primitives
- `emergent-spacetime/0sm.md` — Table I discrete ↔ continuous (#29 Section III) realizes #23's program

## Curatorial caveats

- **Line integral of connection vs surface integral of curvature**: this distinction is central but easily conflated. The 0-Sphere Model insists on the line-integral-of-connection-one-form formulation; surface integrals of curvature (Stokes-Gauss-style) are derived rather than primary.
- **AI-collaboration provenance**: #29 Acknowledgments specifies that **Eq. II.2 (Poincaré-Thomas correspondence) was formulated with GPT-5.2 collaboration** — this is one of two known papers in the migrated set with explicit AI-collaboration acknowledgment for specific equation formulation (the other is #27, ChatGPT 5.0 dimensional analysis). Curatorially significant for understanding scientific authorship transparency in this work.
- **Forward extension**: #31 (Part III) is forward-dangling at the time of #29's curation. Curation of #31 will close several dangling references and complete the line-integral framework's foundational documentation.
