---
subject: line-integrals
layer: textbook
title: "Line Integrals in Gauge Theory: Standard Treatment"
applies_to: [17, 29, 30, 31, 40, 41, 42, 43, 44, 45, 51, 52, 53, 54, 55, 56, 57, 59, 60]
status: stub
created: 2026-05-05
updated: 2026-05-08
related_topics:
  - subject: line-integrals
    layer: 0sm
  - subject: gauge-theory
    layer: textbook
example_readings: []
tags: [line-integrals, gauge-theory, wilson-line, parallel-transport]
---

# Line Integrals in Gauge Theory: Standard Treatment

**Status:** Stub. To be populated when the standard textbook treatment of line integrals (path integrals over gauge connections, Wilson lines, parallel transport) needs a dedicated reference.

## Future content scope

- Wilson loop W[γ] = Tr P exp(i ∮ A · dx) and its role in gauge theories
- Parallel transport on principal bundles
- Holonomy and curvature: Stokes' theorem in non-Abelian gauge theory
- Open vs closed paths: physical interpretation
- The Aharonov-Bohm effect as a line-integral phenomenon

When at least 5 0-Sphere papers explicitly require comparison against standard gauge-theoretic line-integral formalism, this stub will be elevated to active.

## Reading guidance

Until populated, line-integral references should be answered from the relevant 0-Sphere papers directly (#29, #30, #31, #40, #51, #54, #55, #56) and the companion file `topics/line-integrals/0sm.md`.
