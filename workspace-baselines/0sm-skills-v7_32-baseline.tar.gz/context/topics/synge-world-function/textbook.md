---
subject: synge-world-function
layer: textbook
title: "Synge World Function: Standard General-Relativistic Treatment"
applies_to: [51, 60]
status: stub
created: 2026-05-05
updated: 2026-05-05
related_topics:
  - subject: synge-world-function
    layer: 0sm
example_readings: []
tags: [synge-world-function, geodesic-interval, 2-point-function, biscalar, dewitt-brehme, vilkovisky, world-function]
---

# Synge World Function: Standard General-Relativistic Treatment

**Status:** Stub. To be populated when the standard general-relativistic textbook treatment of the Synge world function is required as a comparison reference distinct from the 0-Sphere-native interpretation in `synge-world-function/0sm.md`.

## Future content scope

Standard literature on the Synge world function and its applications:

- **Synge 1960** (*Relativity: The General Theory*, North-Holland) — original definition of the world function `σ(x, x') = (1/2) λ ∫_geodesic g_µν (dx^µ/dλ)(dx^ν/dλ) dλ` (half the squared geodesic interval). Cited in #51 and #60.
- **DeWitt-Brehme 1960** ("Radiation damping in a gravitational field", Annals of Physics 9, 220) — foundational use of the world function in radiation reaction calculations; introduced the **biscalar formalism** (`σ(x,x')` as biscalar transforming as scalar at both points).
- **Poisson-Pound-Vega 2011** ("The Motion of Point Particles in Curved Spacetime", Living Reviews in Relativity 14, 7) — comprehensive modern review of the world function and its applications to gravitational self-force.
- **Vilkovisky 1984** — geometric quantization using world function machinery.
- **Ottewill-Wardell 2011** — semi-classical applications in curved spacetime.

Future content may include:

- **Definition and basic properties**: `σ(x,x') = (1/2) λ ∫_geodesic ds²` along the unique geodesic from `x` to `x'`; biscalar character; symmetry `σ(x,x') = σ(x',x)`; vanishing on coincidence `σ(x,x) = 0`.
- **The metric formula**: `g_µν(x) = -∂_µ ∂_ν' σ(x, x') |_{x'→x}` — the spacetime metric emerges as the **Hessian of the world function evaluated at coincidence**. This is the formula realized in #51 via fixed-endpoint line integrals in the 0-Sphere framework.
- **Tangent vectors `σ_µ(x,x') = ∂_µ σ`** and `σ_µ'(x,x') = ∂_µ' σ`: their geometric interpretation as tangents to the geodesic at the endpoints.
- **The Hadamard parametrix**: `σ(x,x')` features prominently in the Hadamard expansion of two-point Green's functions in curved spacetime.
- **Coincidence limits**: rules for evaluating `σ` and its derivatives in the limit `x' → x`.
- **Geometric interpretation**: why `σ` is the natural geometric distance function (vs squared coordinate distance, which is not invariant).
- **Lorentzian vs Euclidean**: the world function in Lorentzian signature has timelike-vs-spacelike sign distinctions absent in Euclidean signature.
- **Quantum corrections**: At length scales below the Compton wavelength, the smooth-geodesic assumption underlying the world function breaks down; this is relevant to the 0-Sphere quantum discreteness program.

## Distinction from 0sm layer

The companion file `synge-world-function/0sm.md` documents the **0-Sphere-native treatment**: two kernels (Kernel A and Kernel B) function as the two events `x` and `x'`, the world function operates on the thermal geodesic between them, and the metric `g_µν` emerges from second derivatives of fixed-endpoint line integrals (#51). The Berry-Synge-Bonnet-Myers triangle (#60) places the world function as one vertex of a three-structure unification proposal.

The 0-Sphere identification differs from the standard treatment in that:
- The two events are **not generic spacetime points** but specifically the two kernel positions (a discrete `S^0` structure)
- The geodesic is **thermal**, not GR-spacetime (operates on `G_µν(T)` rather than `g_µν` directly)
- The metric is **emergent**, not pre-given (the standard Synge formula assumes a pre-existing `g_µν`; 0-Sphere derives `g_µν` from the formula)

This textbook layer, when populated, will document the standard treatment to support readers comparing the 0-Sphere realization against canonical formulations.

## Threshold for elevation

This stub is elevated to **active** status when at least 5 0-Sphere papers explicitly require detailed comparison against standard textbook Synge world function formalism. Current count: **2** substantive papers (#51, #60). The 11-paper forward-reference network in `synge-world-function/0sm.md` does not count toward this threshold because those papers do not require the standard textbook treatment — they reference the 0-Sphere realization directly.

## Reading guidance

Until populated, Synge world function questions about the standard treatment should be answered from the cited standard literature directly (Synge 1960, DeWitt-Brehme 1960, Poisson-Pound-Vega 2011) and the companion file `synge-world-function/0sm.md` provides the 0-Sphere-native interpretation.
