---
subject: synge-world-function
layer: 0sm
title: "Synge World Function in the 0-Sphere Model: Two Kernels as Two Events, Metric Emergence, and GR-Quantum Discreteness Bridging"
applies_to: [51, 60]
status: active
created: 2026-05-05
updated: 2026-05-05
related_topics:
  - subject: synge-world-function
    layer: textbook
  - subject: line-integrals
    layer: 0sm
  - subject: thermal-geodesic
    layer: 0sm
  - subject: emergent-spacetime
    layer: 0sm
  - subject: gravity-mediation
    layer: 0sm
  - subject: background-independence
    layer: 0sm
example_readings: []
tags: [synge-world-function, two-point-function, metric-emergence, gr-quantum-bridge, 0sphere-model, fixed-endpoint-line-integral, geodetic-interval, world-function]
---

# Synge World Function in the 0-Sphere Model

The **Synge world function** `σ(x, x')` — half the squared geodesic interval between two spacetime events `x` and `x'` — is a standard general-relativistic 2-point geometric tool (Synge 1960). The 0-Sphere Model invokes it for a specific structural purpose: the **two kernels (A at `x = -a` and B at `x = +a`) function as the two events**, and the world function provides the geometric distance machinery from which the **spacetime metric `g_µν` emerges** via second derivatives of fixed-endpoint line integrals.

This identification is the **central machinery for bridging general relativity and the 0-Sphere quantum discreteness**: the discrete `S^0` (zero-sphere = two kernels) provides the two-point structure, the world function supplies the geodesic interval, and the metric emerges from the line-integral framework established in the Line Integral Trilogy (#29-#31).

## Strategic significance (per HANDOFF v4 user note)

> *特に、２つのカーネルから２点間として Synge world function を適用し、計量を導き出し、一般相対性理論と量子的な離散性を架橋するときに、クエリを生成したいカテゴリとして必須になるだろう。*

The user's strategic point is curatorially confirmed by the broad **forward-reference network**: 11 earlier curated papers reference `#51`'s Synge framework as the closure mechanism for their open tasks on metric emergence, GR-bridge questions, and quantum-discreteness reconciliation. The Synge world function functions as a **central network node** in the curated set — not because it is invoked substantively in many papers, but because **many papers' open tasks point to it as their resolution path**.

## Founder paper

This topic's **substantive founder is `#51`** (Helical Trajectory, Fixed-Endpoint Line Integrals, and the Emergence of the Spacetime Metric in the 0-Sphere Model, 2026-04-XX, DOI 10.5281/zenodo.19000000-range). #51 explicitly identifies:

- **Synge 世界関数 σ(x, x')**: 端点間の幾何学的距離 (geometric distance between endpoints)
- **g_µν の創発**: 端点固定線積分の二階微分から (metric emergence from second derivatives of fixed-endpoint line integrals)
- **Bonnet-Myers 閉じ込め**: sectional curvature 下界から経路有限化 (Bonnet-Myers confinement: path finiteness from sectional curvature lower bound)

The other substantive paper is `#60` (The Berry-Synge-Bonnet-Myers Triangle), which formulates a **central mathematical structure** with three vertices: Berry connection, Synge world function, Bonnet-Myers bound — proposing their mutual constraints as the closure condition for unifying gauge and gravitational sectors.

## Two-Layer applies_to Structure

The `applies_to` list reflects two distinct invocation patterns:

### Substantive invocations — listed in `applies_to: [51, 60]`

| Paper | Role |
|---|---|
| **#51** (founder) | Explicit identification of Synge world function in 0-Sphere context; metric emergence via fixed-endpoint line integral second derivatives; helical trajectory geometric framework |
| **#60** | **Berry-Synge-Bonnet-Myers Triangle**: three geometric structures (Berry connection #48, Synge world function #51, Bonnet-Myers bound #51) form a triangle whose mutual constraints would close the unification of gauge and gravitational sectors |

### Forward-reference convergence network — NOT in `applies_to`, documented here

Eleven earlier curated papers' **open tasks or status_notes** point to `#51`'s Synge mechanism as the closure path for their open questions on metric emergence, GR-bridge, and quantum-discreteness reconciliation. These papers do **not** invoke Synge world function as substantive content — they reference #51 as the resolution mechanism. They are therefore **not** added to `applies_to` (which would imply substantive engagement), but the convergence network is curatorially significant:

| Paper | Forward-reference role |
|---|---|
| #7 | "#51 (Synge world function on internal worldline)" — momentum reinterpretation `p → p_γ*` reused via #51 (status_notes) |
| #10 | "#50 (helical/Synge reframe of spin generation)" — angular momentum from phase-staggered scalar oscillations on helical (Synge) trajectory (status_notes) |
| #11 | C-23 thread description: "#51 Synge world function で完全形式化" — proper time emergence formalized via #51 |
| #12 | "後の #51 の Synge world function の早期視覚化" — Fig. 1b yellow arrow as early visualization of #51 Synge geodesic (analogies_first note) |
| #17 | Open task: "addressed in #51 (Synge world function as geodesic)" |
| #19 | "Long-range descendants: #50 (helical/Synge reframe of spin generation)" |
| #22 | "#51 Synge world function への foundational framing" — ZB internal clock + gravitational modulation as foundation for #51 |
| #23 | "後の #51（Synge world function、helical trajectory）の foundational framing" — emergent-spacetime program foundation for #51 |
| #25 | Open task partial closure: "#51 (helical trajectory + Synge world function、curated、migrated; spacetime metric emergence)" |
| #26 | Partial relation: "#24 G_µν(T) thermal metric (curated 2026-05) と #51 Synge world function" |
| #49 | "#51 addresses open task (v) by providing the metric-emergence framework via the Synge world function" |

This **forward-reference convergence network of 11 papers** demonstrates that the Synge world function is not just one paper's tool — it is a **convergence point** for multiple foundational papers' open questions about metric emergence and GR-bridge. The curatorial significance is that **`#51`'s Synge framework is the resolution path for many earlier-paper open tasks**, even though those earlier papers do not engage Synge as substantive content.

## The Central Machinery — Two Kernels as Two Events

The 0-Sphere identification:

| Synge GR formalism | 0-Sphere identification |
|---|---|
| **Event `x`** | Kernel A at `x = -a` |
| **Event `x'`** | Kernel B at `x = +a` |
| **Geodesic between `x` and `x'`** | Thermal geodesic between Kernel A and Kernel B (see `thermal-geodesic/0sm.md`) |
| **World function `σ(x, x') = (1/2) ∫_geodesic ds²`** | Half the squared thermal geodesic interval between the two kernels |
| **Metric `g_µν(x) = -∂_µ ∂_ν' σ(x, x')\|_{x'→x}`** | Metric emergent from second derivatives of fixed-endpoint line integrals (#51) |

The **two-kernel structure is the discrete substrate** on which the Synge world function operates. This is the specific point at which 0-Sphere quantum discreteness (kernel A + kernel B as `S^0`) connects to GR continuum geometry (metric tensor `g_µν` from world function).

## The GR-Quantum Discreteness Bridge

The bridge structure realized via Synge world function:

```
[Quantum discreteness]                       [GR continuum]
       ↓                                            ↑
   Two kernels (S⁰)  →  Synge σ(x, x')  →  Metric g_µν
       ↓                                            ↑
  Discrete TPE oscillation                Continuous geometric structure
       ↓                                            ↑
  cos⁴/sin⁴ identity (#1)                Einstein equations as derived (#30)
```

This bridge is the **central mathematical mechanism** by which the 0-Sphere Model realizes the user's stated goal: "一般相対性理論と量子的な離散性を架橋する" (bridging general relativity and quantum discreteness).

## The Berry-Synge-Bonnet-Myers Triangle (#60)

`#60` formulates a **three-vertex geometric structure** whose closure would unify gauge and gravitational sectors:

| Vertex | Source | Role |
|---|---|---|
| **Berry connection** | #48 (U(1) fiber bundle topological g=2) | Internal phase accumulation generating gauge structure |
| **Synge world function** | #51 (helical trajectory + metric emergence) | 2-kernel 2-point machinery generating spacetime metric |
| **Bonnet-Myers bound** | #51 (compact domain bound: `diam(S^n) ≤ π λ_C` from positive Ricci curvature `Ric ≥ K ~ λ_C⁻²` of photon sphere) | Compactness condition ensuring finite spatial extent of internal geometry |

The **three sides** of the triangle (mutual constraints between the vertices) are formulated as **open problems** whose closure would unify the gauge sector (Maxwell `→` derived in #54, Wilson line ontology in #55) with the gravitational sector (metric emergence in #51, Einstein equation as global checksum in #30).

## Topic content scope

This layer documents the 0-Sphere-native treatment of Synge world function:

- **Two-kernel 2-event identification** (#51): Kernel A and Kernel B as the two events for `σ(x, x')`
- **Metric emergence formula** (#51): `g_µν` from second derivatives of fixed-endpoint line integrals (the standard Synge formula `g_µν = -∂_µ ∂_ν' σ` realized in 0-Sphere context)
- **Bonnet-Myers compactness bound** (#51): `diam(S^n) ≤ π λ_C` for positive Ricci curvature; ensures internal geometry is compact
- **Berry-Synge-Bonnet-Myers triangle** (#60): three-vertex unification structure
- **Forward-reference network**: 11 earlier papers whose open tasks point to Synge mechanism as resolution path
- **GR-quantum discreteness bridge** (strategic): central mechanism for bridging GR continuum and 0-Sphere `S^0` discreteness

## Distinction from related topics

- **`thermal-geodesic/0sm.md`**: The geodesic on which the Synge world function is computed. Synge `σ(x,x')` requires a geodesic; in 0-Sphere context that geodesic is a thermal geodesic.
- **`line-integrals/0sm.md`**: Fixed-endpoint line integrals are the technical machinery from which Synge world function (and hence `g_µν`) is computed. The two are related by integration: `σ` is a specific integral, `g_µν` is its second derivative.
- **`gravity-mediation/0sm.md`**: Gravitational coupling and mediation in the 0-Sphere Model; Synge world function provides the geometric framework on which gravity acts.
- **`emergent-spacetime/0sm.md`**: The broader program of which Synge metric emergence is a specific realization.
- **`background-independence/0sm.md`**: BI methodological criterion that the Synge mechanism preserves (Synge world function is background-independent in the 0-Sphere implementation; the two kernels and their geodesic are not pre-given but emerge from internal dynamics).

## Strategic role as query node

For future paper analysis and brainstorming (HANDOFF v4 user-confirmed primary motivation), this topic functions as a **GR-bridge convergence node**:

- **For new GR-bridge proposals**: Does the proposal route through Synge world function machinery, or invoke a different mechanism? If different, why?
- **For metric emergence questions**: How does the proposed metric emerge — from Synge `σ(x,x')` second derivatives (the #51 path), from Einstein equation consistency (the #30 path), or from another mechanism?
- **For 2-point function analyses**: When the model needs to discuss correlations or distances between two events, the Synge world function is the canonical 0-Sphere tool.
- **For unification analyses**: The Berry-Synge-Bonnet-Myers triangle (#60) is the central mathematical structure; new proposals should clarify their relationship to it.

This is the topic the user explicitly identified as **「クエリを生成したいカテゴリとして必須」** (essential as query-generation category) when bridging GR and quantum discreteness.

## Reading guidance

- **Start with `#51`** for the substantive identification of Synge world function in 0-Sphere context (helical trajectory + metric emergence).
- **Then `#60`** for the Berry-Synge-Bonnet-Myers triangle and the unification proposal.
- **For background**: see `thermal-geodesic/0sm.md` (the geodesic on which σ is computed) and `line-integrals/0sm.md` (the integral machinery).
- **For textbook treatment**: see companion file `synge-world-function/textbook.md` (stub) — Synge 1960, DeWitt-Brehme 1960, Poisson-Pound-Vega 2011.
- **For forward-reference context**: the 11 earlier papers in the forward-reference network show how Synge mechanism converges multiple lines of inquiry.

## Open structural questions

The Synge framework leaves several structural questions open:

- **The three sides of the Berry-Synge-Bonnet-Myers triangle** (#60): Each side is a mutual-constraint condition between two vertices that has not been closed. Closure would constitute the unification of gauge and gravitational sectors.
- **Connection to thermal metric `G_µν(T)`** (#24): The Synge world function in the 0-Sphere context operates on the thermal metric, not directly on the spacetime metric. The relation between `G_µν(T)` (thermal) and the emergent `g_µν` (spacetime) requires further articulation.
- **Quantum corrections to Synge formula**: At length scales below the Compton wavelength, the smooth-geodesic assumption underlying Synge's formula breaks down; the 0-Sphere quantum discreteness should produce corrections that have not yet been formulated.
- **Lorentzian vs Euclidean signature**: Synge's original formulation is Lorentzian; the 0-Sphere thermal metric on which Synge is realized has signature questions that should be clarified.
