---
subject: berry-phases
layer: textbook
title: "Berry Phase / Geometric Phase: Standard Treatment"
applies_to: [26, 29, 31]
status: stub
created: 2026-05-05
updated: 2026-05-05
related_topics:
  - subject: berry-phases
    layer: 0sm
  - subject: line-integrals
    layer: textbook
  - subject: gauge-theory
    layer: textbook
example_readings: []
tags: [berry-phase, geometric-phase, holonomy, adiabatic-evolution, anandan-aharonov, wilczek-zee]
---

# Berry Phase / Geometric Phase: Standard Treatment

**Status:** Stub. To be populated when the standard textbook treatment of Berry phase and geometric phases needs a dedicated reference distinct from the 0-Sphere-native interpretation in `berry-phases/0sm.md`.

## Future content scope

Standard textbook material referenced across the curated 0-Sphere papers:

- **Berry 1984** ("Quantal phase factors accompanying adiabatic changes", Proc. R. Soc. Lond. A 392, 45) — original adiabatic Berry phase formulation. Cited in #26, #29.
- **Wilczek-Zee 1984** ("Appearance of gauge structure in simple dynamical systems", Phys. Rev. Lett. 52, 2111) — non-Abelian Berry phase / degenerate state generalization. Cited in #26, #29.
- **Anandan-Aharonov 1990** ("Geometry of Quantum Evolution", Phys. Rev. Lett. 65, 1697) — non-adiabatic geometric phase, projective Hilbert space formulation. Cited in #26.
- **Aharonov-Bohm 1959** ("Significance of electromagnetic potentials in the quantum theory", Phys. Rev. 115, 485) — gauge-connection line-integral phenomenon, prototype of Berry phase. Cited in #29.
- **Shapere-Wilczek 1989** (*Geometric Phases in Physics*, World Scientific) — classic edited volume. Cited in #26.
- **Vanderbilt 2018** (*Berry Phases in Electronic Structure Theory*, Cambridge) — modern textbook reference. Cited in #26.
- **Xiao-Chang-Niu 2010** ("Berry Phase Effects on Electronic Properties", Rev. Mod. Phys. 82, 1959) — comprehensive review. Cited in #26.

Future content may include:
- Adiabatic Berry phase derivation: γ = i ∮_C ⟨ψ|∇_x ψ⟩ · dx
- Berry connection A_n(R) = i⟨n(R)|∇_R n(R)⟩ and Berry curvature F = dA
- Relation to Chern numbers and topological invariants (bridge to `topology/textbook.md`)
- Non-Abelian Wilczek-Zee generalization for degenerate state spaces
- Aharonov-Bohm phase as paradigmatic line-integral observable
- Gauge invariance of Berry phase modulo 2π

## Threshold for elevation

This stub is elevated to **active** status when at least 5 0-Sphere papers explicitly require comparison against standard textbook Berry phase formalism. Current count: **4** (#26, #29, #31, #38), so the stub remains in placeholder state but approaching the threshold.

## Distinction from 0sm layer

The companion file `berry-phases/0sm.md` documents the **0-Sphere Model native interpretation**: Berry connection / curvature / phase derived from internal thermodynamic processes (Stefan-Boltzmann + temperature gradient + sinusoidal state function), with the state function ψ(x) understood as a **thermogeometric descriptor of internal energy flow** rather than a quantum probability amplitude. The 0sm interpretation also treats Berry curvature as the **generative mechanism for spin** (causal hierarchy reversal: Berry → spin), in inversion of the standard textbook reading (spin → Berry phase as adiabatic side-effect).

This textbook layer, when populated, will document the **standard reading** to support readers comparing the 0-Sphere-native treatment against canonical formulations.

## Reading guidance

Until populated, Berry phase questions about the standard treatment should be answered from the cited standard literature directly (Berry 1984, Wilczek-Zee 1984, Anandan-Aharonov 1990, Vanderbilt 2018, etc.) and the companion file `berry-phases/0sm.md` provides the 0-Sphere-native interpretation.
