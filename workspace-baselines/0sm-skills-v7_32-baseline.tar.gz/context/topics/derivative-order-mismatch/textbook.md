---
subject: derivative-order-mismatch
layer: textbook
title: "Derivative-Order Mismatch Between Gauge Theory and Gravity: Standard / Historical Treatment"
applies_to: [40, 41, 43, 45]
status: active
created: 2026-05-07
updated: 2026-05-07
related_topics:
  - subject: derivative-order-mismatch
    layer: 0sm
  - subject: gauge-theory
    layer: textbook
  - subject: line-integrals
    layer: textbook
  - subject: berry-phases
    layer: textbook
  - subject: topology
    layer: textbook
example_readings: []
tags: [derivative-hierarchy, connection, curvature, gauge-theory, general-relativity, christoffel-symbols, riemann-tensor, field-strength, einstein-field-equations, geodesic-equation, weyl-1918, cartan-1923, yang-mills-1954, aharonov-bohm-1959, wu-yang-1975, shapiro-delay, historical-supplement]
---

# Derivative-Order Mismatch Between Gauge Theory and Gravity: Standard / Historical Treatment

**Status:** Active. This layer documents the **structural distinction by one derivative order** between the way gauge theories and general relativity assign physical meaning to geometric objects — a distinction that is mathematically transparent in standard treatments but **rarely articulated as an organizing principle**. The companion `0sm.md` layer documents the 0-Sphere Model's line-integral-based bridging of this mismatch.

The discussion below tracks #41's historical narrative (Einstein → Weyl → Cartan → Yang-Mills) and the standard derivative-counting argument that is used in passing throughout the gauge-gravity literature without being given a name.

## The mismatch in one sentence

In gauge theory, **curvature** corresponds directly to physical force; the connection serves primarily through its derivatives. In general relativity, the **connection** itself governs particle motion; curvature plays a source-related role through the Einstein field equations. The correspondence between geometric object and physical quantity differs by **one derivative order** between the two theories.

## Standard derivative counting

In gauge theory (Abelian case for clarity), the field strength is

```
F_μν = ∂_μ A_ν − ∂_ν A_μ
```

— a first derivative of the connection A_μ. The non-Abelian extension adds a commutator [A_μ, A_ν] but the first-order differential character is preserved. F_μν is the carrier of force: electric and magnetic fields are components of F_μν, and local energy density and radiation are expressed in F_μν.

In general relativity, the Christoffel symbols are

```
Γ^ρ_μν = (1/2) g^ρσ (∂_μ g_νσ + ∂_ν g_μσ − ∂_σ g_μν)
```

— a first derivative of the metric. The Riemann tensor is

```
R^ρ_σμν = ∂_μ Γ^ρ_νσ − ∂_ν Γ^ρ_μσ + Γ^ρ_μλ Γ^λ_νσ − Γ^ρ_νλ Γ^λ_μσ
```

— a first derivative of the connection, hence a second derivative of the metric (with nonlinear terms in first derivatives). The geodesic equation `d²x^μ/dτ² + Γ^μ_νρ (dx^ν/dτ)(dx^ρ/dτ) = 0` shows that **particle acceleration is governed by the connection**, not by curvature; curvature enters at the next derivative level via the equation of geodesic deviation and the Einstein field equations `G_μν = 8πG T_μν`.

The asymmetry: gauge theory locates physical force at the **same derivative level as F_μν** (one derivative of the connection). General relativity locates physical (force-like) effects at the **same derivative level as Γ^μ_νρ** (zero derivatives of the connection, equivalently one derivative of the metric). The two theories sit one derivative apart in their assignment of "where force lives."

## Historical narrative (after Sec 3 of #41)

The mismatch did not emerge from a single insight. It crystallized through a sequence of developments, none of which articulated it explicitly as a principle:

| Stage | Author / Year | Contribution | What was — and was not — said |
|---|---|---|---|
| GR foundation | Einstein 1916 | General relativity; curvature in field equations, connection in geodesic equation | Internally consistent and empirically successful, but no mature gauge theory existed for comparison; the assignment of force-like role to the connection remained implicit |
| First unification attempt | Weyl 1918 | Scale connection alongside metric, anticipating gauge-theoretic ideas | Weyl treated the gauge–gravity asymmetry as **a problem to eliminate**, not a structural feature to preserve. His theory failed on physical grounds (spectral stability) and the geometric insight was not pursued further |
| Mathematical clarification | Cartan 1923 | Affine connection / theory of generalized relativity; clean separation of connection, curvature, torsion | Provided the tools to distinguish derivative orders cleanly, but **did not assign observational priority** to line integrals, holonomy, or accumulated phase. The mismatch was visible mathematically but unarticulated as a physical principle |
| Gauge theory established | Yang–Mills 1954 | Non-Abelian gauge theory; curvature unambiguously identified with field strength | Cemented "curvature = force" identification in gauge theory. As a side effect, GR's contrasting assignment came to be regarded as **an idiosyncrasy**, not a systematic difference |
| Topological global effects | Aharonov–Bohm 1959 | Phase shift in field-free region from line integral of A_μ around a flux | Established that line integrals of connections carry physically real information **even when curvature vanishes locally**. Did not articulate the gauge–gravity comparison |
| Global formulation of gauge fields | Wu–Yang 1975 | Nonintegrable phase factors `exp(ie ∮ A_μ dx^μ)` as global gauge observables | Established the global / topological observational layer of gauge theory. Did not extend the framework to gravity |
| Gravitational line integral | Shapiro 1964 | Time delay of radar signal from connection-governed proper-time accumulation | Confirmed that line-integral-of-connection observables exist in gravity (clock comparison, redshift). Not framed as the gauge-counterpart of Aharonov–Bohm |

## Why the mismatch remained unspoken (after Sec 4 of #41)

Three factors plausibly account for the long silence:

1. **No common observational language.** Without a framework that places line integrals on equal footing with local field strengths, the mismatch appeared either trivial (a matter of formal convention) or irrelevant (each theory works internally). The comparison required language neither tradition foregrounded.

2. **Empirical success obscures structural asymmetry.** Both gauge theory and general relativity achieved remarkable predictive success without requiring an explicit comparison of geometric hierarchies. Asymmetries that did not lead to contradictions were rarely isolated as independent objects of analysis.

3. **Tacit observational bias toward locality.** Standard practice assumes physical observables are local and differential. Quantities defined through finite-path integration (holonomy, accumulated phase, gravitational time dilation) were treated as secondary, derived constructs. This tacit bias hid the layer at which gauge and gravitational descriptions actually meet observationally.

## Comparative observational structure

A useful concrete contrast: **Shapiro time delay (GR)** vs **Aharonov–Bohm phase (gauge theory)**, both expressible as line integrals along distinct paths.

| Feature | Shapiro delay (GR) | Aharonov–Bohm (gauge) |
|---|---|---|
| Field type | Metric `g_μν` (and its connection Γ) | Gauge connection `A_μ` |
| Local curvature along path | Non-zero (mass-energy curves spacetime along the null geodesic) | Can vanish (`F_μν = 0` everywhere along the electron paths) |
| Observable | Proper-time difference Δτ | Phase difference Δφ |
| Mathematical form | `∫_γ ds` (metric-dependent) | `∮ A_μ dx^μ` |
| Closed loop required | No (two open geodesics suffice) | Typically yes (open-path phase is gauge-dependent) |
| Local force | Present along each path | Absent in the path region |
| Origin of the effect | Local geometry (curvature) | Global gauge structure (topology) |

Both observables are line integrals of connection-type quantities. Both require comparing two extended histories. They are structurally parallel in observational architecture, yet differ in origin: Shapiro arises from **local curvature accumulating along each path**; Aharonov–Bohm arises from a **global / topological feature of the connection** that no local measurement along the paths can reveal. This is the derivative-order mismatch reappearing **inside the line-integral observational layer itself**, not eliminated by it.

## Standard physics references for this layer

- **A. Einstein**, "The Foundation of the General Theory of Relativity," *Annalen der Physik* **49**, 769 (1916)
- **H. Weyl**, "Gravitation und Elektrizität," *Sitzungsberichte der Preussischen Akademie der Wissenschaften* (1918)
- **É. Cartan**, "Sur les variétés à connexion affine et la théorie de la relativité généralisée," *Annales Scientifiques de l'École Normale Supérieure* **40**, 325 (1923); English translation, Bibliopolis (1986)
- **C. N. Yang and R. L. Mills**, "Conservation of Isotopic Spin and Isotopic Gauge Invariance," *Physical Review* **96**, 191 (1954)
- **Y. Aharonov and D. Bohm**, "Significance of Electromagnetic Potentials in the Quantum Theory," *Physical Review* **115**, 485 (1959)
- **I. I. Shapiro**, "Fourth Test of General Relativity," *Physical Review Letters* **13**, 789 (1964)
- **T. T. Wu and C. N. Yang**, "Concept of Nonintegrable Phase Factors and Global Formulation of Gauge Fields," *Physical Review D* **12**, 3845 (1975)
- **T. Frankel**, *The Geometry of Physics: An Introduction*, Cambridge University Press (2011)
- **M. Nakahara**, *Geometry, Topology and Physics*, Taylor & Francis (2003)

These are the standard touchstones referenced by both #40 and #41 in articulating the mismatch.

## Position relative to the 0-Sphere Model

The textbook treatment establishes the mismatch as a structural fact, but stops short of reframing it as an organizing observational principle. The 0-Sphere Model goes further: it treats **line integrals between discrete two points as the primary observational layer common to both frameworks**, accommodating the derivative-order mismatch without attempting to eliminate it. See `derivative-order-mismatch/0sm.md` for that reinterpretation.

## Relation to other textbook topics

- **`gauge-theory/textbook.md`**: provides the standard QFT / fiber-bundle treatment of A_μ, F_μν, Wilson lines that this layer's gauge-side machinery refers to
- **`line-integrals/textbook.md`**: provides the standard treatment of holonomy, parallel transport, Wilson loops — the gauge-side instances of the line-integral observational layer
- **`berry-phases/textbook.md`**: Berry phase as the geometric phase analog of Aharonov–Bohm; relevant for the holonomy / connection-line-integral lineage
- **`topology/textbook.md`**: the topological character of the Aharonov–Bohm phase (and, by extension, of all gauge holonomy observables)

## Historical caveat: why the existing literature does not name this mismatch

The phrasing **"derivative-order mismatch"** is not standard. The underlying observation — that gauge theory's force lives in F (a derivative of A), while gravity's force-like effects live in Γ (algebraically in g) — is so widely known that it functions as background. Repeatedly mentioned in passing in textbooks (Frankel, Nakahara, MTW), but not raised to the level of an organizing principle. Papers #40 and #41 articulate this background observation as a **named structural feature** for the first time in the 0-Sphere Model series, and use it to motivate the line-integral-based bridging in `0sm.md`.

## Forward direction

The user's curatorial guidance positions this textbook layer as a **preserved organizational record** of a problem-statement that has been raised but rarely organized in the standard literature. Future entries in this layer may track additional historical material on connection-based reformulations of gravity (Einstein–Cartan theory, teleparallel gravity, Ashtekar variables, loop quantum gravity), which represent earlier attempts to relocate the mismatch — without naming it — by changing gravity's geometric formulation rather than relocating the observational layer.
