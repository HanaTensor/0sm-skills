---
subject: thomas-precession
layer: 0sm
title: "Thomas Precession: 0-Sphere Model Native Reinterpretation"
applies_to: [25, 26, 27, 29, 36, 38]
status: stub
created: 2026-05-05
updated: 2026-05-07
related_topics:
  - subject: thomas-precession
    layer: textbook
  - subject: spin
    layer: 0sm
example_readings: []
tags: [thomas-precession, 0sphere-model, native-interpretation]
---

# Thomas Precession: 0-Sphere Model Native Reinterpretation

**Status:** Stub. To be populated when 0-Sphere–native reframings of Thomas precession diverge enough from the textbook (Tomonaga) interpretation to warrant a separate file.

## Future content scope

Candidate content for this layer:

- **Reformulation as a window, not a generator** (introduced in Paper #50): Thomas precession does not *create* angular momentum; the topological S¹ phase flow does. Thomas precession is the relativistic projection through which this topologically existing angular momentum becomes observable in the lab frame. This is a 0-Sphere–native reframing absent from textbook treatments.

- **π-period structure as ontological signature** (introduced in Paper #48): the π-periodicity of Ω_T(2ωt) is read in 0-Sphere as a candidate spin-2 indicator within the cycle-counting framework, not merely a kinematic curiosity. **Future bridge to Riemann surface bivalent function (HANDOFF v7.7、user explicit articulation で record)**: User 明示 (HANDOFF v7.7 transition で articulate) 「**スピンの２価性を表現するためのリーマン面は、今後の幾何学アプローチでは必要であろう。これは、数式により、のちの考察で、トーマス歳差の再考察によって2倍角が出てきたためである。**」 ─ #48/#50 で Thomas 歳差再考察 (角速度 Ω_T(2ωt) の **2倍角 emergence**) が **#3 Sec III.A Riemann 面 spin 二価性 (720° period)** との geometric bridge 候補として articulated、Riemann 面 framework は #3 v1 baseline で 「敷衍されていない」 と articulate されたが、HANDOFF v7.7 で **future geometric approach での continued relevance** に refine。Mathematical formalism (Thomas precession 2ωt) と geometric formalism (Riemann surface bivalence) の formal bridge は現状未到達 (open task)、user explicit value judgment として 「**そちらの数式アプローチによる考察の方が、登用価値が高いと現在のところ判断している**」 (現状 caveat 付き) で 数式アプローチ priority の articulation

- **Direction–algebraic correspondence** (introduced in Paper #52, formalized in Paper #53): ê_z = ê_x × ê_y assigns the Thomas precession axis as a derivative of the gravity (ê_x) and EM (ê_y) sectors, rather than a primitive direction.

- **Connection to the radiation gradient** as the *physical* (not geometric) cause: Thomas precession is downstream of the radiation gradient, which is itself rooted in the kernel asymmetry cos⁴(θ/2) − sin⁴(θ/2). This physical chain is 0-Sphere specific.

When at least 2 of the above achieve formal treatment in the paper series (currently in progress), this stub will be elevated to `status: active`.

## Reading guidance

Until this layer is populated, all Thomas precession queries should consult `topics/thomas-precession/textbook.md`, which already incorporates the most important 0-Sphere-specific framing (Tomonaga's kinematic interpretation applied within the photon-sphere dynamics).

---

*Last updated: 2026-05-06 (v7.7: 2倍角 ↔ Riemann 面 future bridge articulation added)*
