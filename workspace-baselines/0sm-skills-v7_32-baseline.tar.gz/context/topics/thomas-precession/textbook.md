---
subject: thomas-precession
layer: textbook
title: "Thomas Precession: Physical Framing via Tomonaga's Lectures"
based_on: "Tomonaga, 'The Story of Spin' (スピンはめぐる, 1974)"
applies_to: [10, 11, 13, 14, 15, 19, 20, 21, 22, 28, 47, 48, 49, 50, 52, 53, 58]
status: active
created: 2026-04-03
updated: 2026-05-05
related_topics:
  - subject: spin
    layer: textbook
  - subject: spin
    layer: 0sm
example_readings:
  - paper: 10
    aspect: "kinematic necessity of v×a ≠ 0 (initially assumed, not derived)"
  - paper: 19
    aspect: "vector form correction (ê_z restored)"
  - paper: 49
    aspect: "inversion of cause–effect: acceleration causes precession, not path curvature"
  - paper: 50
    aspect: "precession as relativistic window, not generator of angular momentum"
  - paper: 52
    aspect: "ê_z = ê_x×ê_y assignment of the Thomas precession axis"
tags: [spin, kinematics, thomas-precession, lorentz-frame]
---

# Thomas Precession: Physical Framing via Tomonaga's Lectures

This topic file codifies the **textbook-layer interpretation** of Thomas precession as it applies to the 0-Sphere Model. The framing is based on Sin-Itiro Tomonaga's exposition in "The Story of Spin" (スピンはめぐる, 1974). It serves as the canonical reference for how Thomas precession is understood across Papers #10, #19, #47, #48, #49, #50, #51, and #52.

---

## 1. The Tomonaga Source

Sin-Itiro Tomonaga's description of Thomas precession provides the physical foundation for how the 0-Sphere model treats this effect:

> 『トーマスのやった計算は恐ろしくややこしいので、ここでお話しするにはしんどすぎます。しかしとにかく、"電子が静止していて核が回っている座標系"というのをそう簡単に扱ってはいかん、ということなのです。電子が等速運動をしているなら、そういう座標系は実験室系からローレンツ変換で簡単に与えられます。しかし電子に加速度があると面倒なことが起こる。確かに電子がじっとしている座標系は存在しています。詳しくいうと、電子の上に原点を載せながら電子と一緒に動いてゆく座標系がそれです。しかし、原点が電子と一緒に動いている、というだけでは座標系は一つに決まりません。つまりその時、x, y, z 軸の向きをどうとるかが問題です。そこで、原点が電子と一緒に動いてゆく、という条件の他に、x, y, z 軸が常に並行に移動してゆく、といった条件をつける必要があるでしょう。ところがこの "平行" ということは、等速運動の電子に対しては明白なのですが、電子に加速度があると、それほど明白なことではない。こういう点にトーマスは気づいたのです。
>
> そこでまずトーマスは、座標軸の平行な移動とは何か、ということを論じました。そして、軸の平行な移動とは、各瞬間ごとに、その瞬間での軸が無限小時間前の軸と平行になっていることだ、と結論しました。電子と一緒に動く原点を持ち、かつこの意味において並行に移動してゆく軸を持つ座標系は、電子の固有座標系とでもいうべきものです。トーマスは、この系の軸を実験室系からみると、電子に加速度があるときには、それは決して平行に移動していなくて、そこには "回転" が伴っていることを導いたのです。彼はしんどい計算をやって、固有座標系の軸が、実験室系からみると
>
> Ω = (1/2c²)[a × v]
>
> という角速度で回転していることを見つけたのです。』

—Tomonaga, S. *The Story of Spin* (Translation by T. Oka, University of Chicago Press, 1997), pp. 42–43.

---

## 2. Core Principle (Tomonaga's Key Insight)

Thomas precession is **NOT** caused by the spatial path being curved. It is a kinematic inevitability of relativistic *accelerated* motion:

- For uniform motion: the rest frame is unambiguously given by a Lorentz transformation from the lab frame.
- For accelerated motion: even when the coordinate axes are transported "in parallel" (each instant parallel to the infinitesimally preceding instant), the axes as seen from the lab frame are NOT in parallel transport — they rotate.
- This rotation appears whenever v × a ≠ 0, i.e., whenever acceleration has a component perpendicular to the velocity.

The angular velocity of this rotation as seen from the lab frame is:

$$
\Omega_T = -\frac{1}{2c^2}(\mathbf{a} \times \mathbf{v})
$$

**Note on the 1D case:** For a purely rectilinear oscillator (e.g., a pendulum or a spring along a single axis), v ∥ a at all times, so v × a = 0 and Ω_T vanishes identically. This is why simple harmonic motion along one axis produces no Thomas precession. The A→B thermal geodesic of the 0-Sphere model differs because it curves in 3D space, yielding a centripetal acceleration component perpendicular to the velocity.

---

## 3. Causal Chain in the 0-Sphere Model

The correct order of physical reasoning (established in Paper #49):

1. **Radiation gradient** F = E₀ sin(θ) → photon sphere is continuously *accelerated* throughout the A→B traversal (Paper #1).
2. **Zitterbewegung** sustains this oscillation at v_ZB ≈ 0.04c (relativistic regime).
3. Because the photon sphere is perpetually accelerated at relativistic speed, **Thomas precession — in the sense explained by Tomonaga — naturally arises** as a structural feature of the 0-Sphere internal dynamics, rather than being introduced as an additional assumption.
4. The radiation gradient acts within the geometry of the internal thermal phase space:
   - $\mathbf{a}(t) = -v_0 \omega \sin(\omega t) \hat{e}_y$ (transverse)
   - $\mathbf{v}(t) = v_0 \cos(\omega t) \hat{e}_x$
   - $\mathbf{v} \times \mathbf{a} = -(v_0^2 \omega / 2) \sin(2\omega t) \hat{e}_z \neq 0$
5. Substituting into the Thomas formula:
   - $\Omega_T = -(v_0^2 \omega / 4c^2) \sin(2\omega t) \hat{e}_z$ (established in Paper #19)
6. Quantitative derivation of the transverse geometry of the thermal geodesic from first principles: **OPEN TASK** (item viii, Paper #49 Section 7).

---

## 4. Anti-Pattern (AVOID this explanation order)

**WRONG** (geometric-curvature-first framing):

> The path is arc-connected in 3D space → thermal geodesic has geometric curvature → acceleration has transverse component → v × a ≠ 0 → Thomas precession

**CORRECT** (Tomonaga's physical interpretation):

> The photon sphere undergoes accelerated motion (radiation gradient) → Thomas precession naturally arises (kinematic inevitability, as explained by Tomonaga): proper frame rotates in lab frame even under parallel-axis transport → v × a ≠ 0 expresses this concretely → $\Omega_T = -(v_0^2 \omega / 4c^2) \sin(2\omega t) \hat{e}_z$

---

## 5. Reference Implementation — Verbatim from Paper #49

Verbatim passages from Paper #49 (DOI: 10.5281/zenodo.19393391) establishing the canonical phrasing.

### From Section 1 (Introduction)

> "The justification is provided by Thomas precession, understood in the sense made precise by Tomonaga: whenever a body undergoes *accelerated* motion in a relativistic regime, its proper coordinate frame rotates relative to the laboratory frame — even under the condition that the axes are transported 'in parallel.' This rotation is not a consequence of the spatial path being curved; it is a kinematic inevitability of relativistic accelerated motion."

### From Section 3.2.1

> "In a pure one-dimensional oscillator (e.g., a pendulum), the velocity v and acceleration a are always parallel or antiparallel; their cross product v × a = 0, and the Thomas angular velocity vanishes identically. The 0-Sphere model is categorically different: the photon sphere is continuously accelerated throughout the A→B traversal by the radiation gradient, and Zitterbewegung sustains this oscillation at v_ZB ≈ 0.04c. Because the photon sphere is perpetually accelerated at relativistic speed, Thomas precession — in Tomonaga's sense — naturally arises as a structural feature of the 0-Sphere internal dynamics, rather than being introduced as an additional assumption."

### Canonical Phrases Established in #49

- "Thomas precession, understood in the sense made precise by Tomonaga"
- "Thomas precession — in Tomonaga's sense — naturally arises as a structural feature of the 0-Sphere internal dynamics, rather than being introduced as an additional assumption"
- "a kinematic consequence of the radiation-gradient-driven ZB acceleration, not of circular rotation"
- "This rotation is not a consequence of the spatial path being curved; it is a kinematic inevitability of relativistic accelerated motion"

---

## 6. Bibliographic Reference

Tomonaga, S. *The Story of Spin*. Translated by T. Oka. Chicago: University of Chicago Press, 1997, pp. 42–43. Originally published in Japanese as *スピンはめぐる* (Spin wa Meguru), Tokyo: Misuzu Shobo, 1974; new edition 2010.

Zenodo citation key: `Tomonaga1997`

---

## 7. Example readings: applying this lens to specific papers

The Tomonaga textbook lens generates distinct readings of each applicable paper:

### Reading #10 through this lens

Paper #10 introduces SHM-modified Thomas precession. Through the Tomonaga lens, the substitution v(t) = cos(ωt), a(t) = −sin(ωt) is read as a **kinematic necessity**, not a geometric assumption: accelerated motion at v_ZB ≈ 0.04c forces frame rotation in the lab frame; v × a ≠ 0 is the algebraic expression of this fact, not its cause. However, #10 wrote Ω as a scalar — the missing ê_z direction was a notational gap closed by #19.

### Reading #19 through this lens

Paper #19 restores the vector form Ω_T(t) = −(v₀²ω/4c²) sin(2ωt) · ê_z. The Tomonaga lens makes clear that ê_z is not arbitrary: it is the geometrically determined cross-product of the transverse acceleration ê_y and longitudinal velocity ê_x. The vectorial nature is physically necessary, not a notational choice.

### Reading #49 through this lens

Paper #49 makes the Tomonaga framing **explicit and canonical**. The kinematic reading inverts the older interpretation: rather than "the path curves and therefore precession occurs," the reading is "acceleration occurs at relativistic speed and therefore the proper frame rotates as a kinematic consequence." The π-periodicity of Ω_T then becomes a structural feature of the radiation-gradient dynamics, not a contingent geometric outcome. Open task (viii) explicitly records that the transverse geometry of the thermal geodesic itself has not yet been derived from first principles.

### Reading #50 through this lens

Paper #50's χ = sign(da/dt) is read as: the second time derivative of position determines the orientation of the phase flow on S¹. The Tomonaga lens makes χ Lorentz-invariant — *acceleration changes* are intrinsic to the trajectory, not frame-dependent quantities. Crucially, #50 reframes Thomas precession itself: it is no longer the **generator** of angular momentum (as #10–#49 implicitly assumed), but the **relativistic window** through which a topologically existing angular momentum (rooted in S¹ phase flow chirality) becomes observable in the lab frame.

### Reading #52 through this lens

Paper #52 assigns ê_z (the Thomas precession axis) as the spin/AMM sector in its three-axis directional decomposition (ê_x = velocity → gravity, ê_y = acceleration → EM, ê_z = ê_x×ê_y → spin). The Tomonaga lens validates this assignment: the cross-product structure that Tomonaga identified as the kinematic origin of Ω_T is precisely the geometric construction of ê_z. The deterministic ZB-axis drift (Δφ = 2πa_e per cycle) is the lab-frame visibility of this kinematic rotation accumulating over many cycles.

---

## 8. Cross-references to global-concept.md

- Section B-3: Thomas precession equation index
- Section C-1: spin theory thread (#1 → #53)
- Section C-10: photon-sphere ejection thread (founder #49; opens at #34 ─ #34 does not carry C-10 directly but raises mediator question via opens_tasks i-iii that #49 closes via Thomas-precession-driven fragment ejection)

---

*Last updated: 2026-05-05*
