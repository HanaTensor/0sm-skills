---
subject: monopole
layer: textbook
title: "Magnetic Monopoles: Standard / Historical Treatment"
applies_to: [42]
status: active
created: 2026-05-07
updated: 2026-05-07
related_topics:
  - subject: monopole
    layer: 0sm
  - subject: gauge-theory
    layer: textbook
  - subject: topology
    layer: textbook
  - subject: line-integrals
    layer: textbook
example_readings: []
tags: [magnetic-monopole, dirac-1931, t-hooft-polyakov-1974, quantization-condition, topological-soliton, gauss-law, ampere-law, maxwell-equations, e-b-duality, charge-quantization, gut-prediction, moedal, experimental-status, standard-physics]
---

# Magnetic Monopoles: Standard / Historical Treatment

**Status:** Active. This layer documents the standard physics treatment of magnetic monopoles — the classical history (Dirac 1931, 't Hooft–Polyakov 1974), the quantization argument, the topological-soliton interpretation, and the experimental status — against which the 0-Sphere Model's structural-hypothesis position (companion `0sm.md` layer) is contrasted.

#42's Sec 1 (Motivation and Context), Sec 6 (Comparison with Dirac's Monopole Construction), and Sec 7 (Current Limitations and Open Directions) all explicitly engage the standard treatment. This layer aggregates the textbook content #42 invokes, in order to make the structural contrast in Sec 6 Table 1 self-contained for readers approaching the 0-Sphere argument.

## Maxwell's equations and the E ↔ B asymmetry

Classical Maxwell's equations in vacuum, in SI units:

```
∇ · E = ρ/ε₀                     (Gauss's law for electricity)
∇ · B = 0                        (Gauss's law for magnetism — no magnetic monopoles)
∇ × E = − ∂B/∂t                  (Faraday's law)
∇ × B = µ₀ J + µ₀ε₀ ∂E/∂t        (Ampère–Maxwell law)
```

The asymmetry is structural: electric charges are sources for E (∇·E ∝ ρ), but B has **no analogous source term**. Magnetic field lines are always closed loops; magnetic flux through any closed surface vanishes.

This asymmetry could in principle be removed by introducing magnetic charge ρ_m and magnetic current J_m:

```
∇ · B = µ₀ ρ_m
∇ × E = − ∂B/∂t − µ₀ J_m
```

Such a "duality-symmetric" Maxwell theory would treat E and B on equal footing under the duality transformation E → B, B → −E (with appropriate factors). The physical question is then whether ρ_m / J_m exists in nature — i.e., whether any particle carries a net magnetic charge.

## Dirac's quantization argument (1931)

Dirac's seminal observation [^Dirac1931]: if even a single magnetic monopole exists anywhere in the universe, then **electric charge must be quantized**, and the quantization condition takes the form

```
e g = (n / 2) ℏ c ,    n ∈ ℤ
```

(in Gaussian units; equivalent forms exist in SI). Here `e` is the electric charge of any particle and `g` is the magnetic charge of the monopole.

**Conceptual basis**: Dirac considered the electromagnetic field of a magnetic monopole, which is necessarily described by a vector potential **A** that is singular along a half-line emanating from the monopole — the *Dirac string*. Requiring that this string be physically unobservable (i.e., its location be a gauge artifact, not a physical feature) imposes the consistency condition above. The condition is independent of the monopole's mass, location, or any dynamical property: it is purely a kinematic / topological consistency requirement.

**Implication**: Dirac's argument provides one of the few known *theoretical motivations* for the empirically observed quantization of electric charge (the universal observation that all electric charges are integer multiples of `e`). If a monopole exists anywhere, charge quantization is automatic; if no monopole exists, charge quantization remains an unexplained empirical fact.

**Status of the argument**: Dirac's framework permits the existence of monopoles but does not require it. The quantization condition is necessary for consistency *if* monopoles exist; absence of monopoles is consistent with classical Maxwell theory but leaves charge quantization unexplained.

## 't Hooft–Polyakov topological solitons (1974)

A second route to magnetic monopoles, independent of Dirac's quantization argument, was discovered by 't Hooft [^tHooft1974] and Polyakov [^Polyakov1974]: in **non-Abelian gauge theories** with appropriate symmetry breaking, magnetic monopoles arise as **stable topological soliton solutions** of the classical field equations.

**Schematic structure**: consider an SU(2) gauge theory with a Higgs field in the adjoint representation. When the Higgs field acquires a vacuum expectation value that breaks SU(2) → U(1) (the "Georgi–Glashow model"), the residual U(1) is identified with electromagnetism. The Higgs vacuum manifold is then a 2-sphere, and field configurations that wrap the spatial 2-sphere at infinity onto the Higgs vacuum 2-sphere with nonzero winding number are topologically stable. These wrapping numbers are classified by the second homotopy group π₂(S²) = ℤ, and a configuration with winding number n carries magnetic charge `g = (4π/e) n`, in agreement with Dirac's quantization condition (up to a factor of 2 reflecting whether the relevant gauge group is SO(3) or SU(2)).

**Key features distinguishing 't Hooft–Polyakov from Dirac**:

| Aspect | Dirac (1931) | 't Hooft–Polyakov (1974) |
|---|---|---|
| Theoretical context | Pure electromagnetism (U(1)) | Non-Abelian gauge theory with SSB |
| Origin of the monopole | Mathematical possibility; consistency requires Dirac string | Solution of classical field equations; topologically stable |
| Mass | Free parameter | Predicted: M ~ M_W / α (~ 137 M_W in early models) |
| Dirac string | Required (gauge artifact) | Absent (smooth field configurations) |
| Generalization | — | Universal in GUTs (SU(5), SO(10), …): every grand unified theory predicts monopoles |

**Theoretical robustness**: 't Hooft–Polyakov monopoles arise in essentially every realistic grand unified theory, with masses in the range 10¹⁵–10¹⁷ GeV. The prediction is so generic that the **non-observation of monopoles in cosmological abundances** posed a problem for early universe cosmology (the "monopole problem"), which inflation was originally proposed in part to solve.

## Experimental status

**No magnetic monopole has ever been confirmed in any experiment.** Decades of dedicated searches — including:

- the **MoEDAL** detector at the LHC (Monopole and Exotics Detector at the LHC), which directly searches for monopoles produced in pp collisions
- Cabrera-style superconducting loop searches for monopole flux through SQUIDs
- searches in cosmic ray detectors, lunar samples, and bulk matter
- searches for monopole-catalyzed proton decay

— have all returned null results. Current experimental upper limits on monopole flux are far below the cosmologically expected GUT-monopole abundance (the cosmological "monopole problem"), confirming that whatever the theoretical framework, GUT-mass monopoles are far rarer than naïve abundance estimates predict.

The **non-observation** is consistent with multiple theoretical possibilities:

1. Monopoles do not exist (Dirac's argument permits but does not require their existence)
2. Monopoles exist but have masses far above current accessible energies
3. Inflationary cosmology drove the primordial monopole density to negligible values
4. Some structural argument precludes their existence in the underlying theory

The 0-Sphere Model's hypothesis (#42, see `0sm.md`) belongs to category 4: a structural-prohibition argument grounded in the energy-identity architecture of the model.

## Implications of monopole existence (or non-existence)

**If monopoles exist**:

- Electric charge quantization is automatic (Dirac)
- Maxwell's equations gain duality symmetry under E ↔ B
- GUT-mass monopoles would be cosmologically significant
- New dynamical phenomena (Callan–Rubakov effect, monopole-catalyzed proton decay) become possible

**If monopoles do not exist**:

- Charge quantization remains an empirical fact requiring a different theoretical explanation (anomaly cancellation, group-theoretic constraints, structural prohibition, etc.)
- The E ↔ B asymmetry of Maxwell's equations is preserved
- ∇·B = 0 holds globally, with magnetic field lines forming closed loops or extending to infinity

The empirical question — does a monopole exist anywhere in the observable universe? — remains open after roughly nine decades of theoretical and experimental investigation.

## Why standard textbooks expect monopoles

Most graduate-level textbooks in particle physics, gauge theory, and topology (e.g., Nakahara, *Geometry, Topology and Physics* [^Nakahara2003]; Coleman; Weinberg) present monopoles as a **robust theoretical prediction**, for several converging reasons:

1. **Mathematical naturalness**: in any gauge theory with broken symmetry leaving a residual U(1), the topology of the vacuum manifold typically permits topologically stable monopole configurations
2. **GUT inevitability**: the simplest grand unified theories (SU(5), SO(10)) all predict monopoles
3. **Charge quantization**: the universally observed quantization of electric charge has Dirac monopoles as one of the few known theoretical mechanisms
4. **Duality**: many modern frameworks (Montonen–Olive duality, Seiberg–Witten theory) treat monopoles as essential ingredients in non-perturbative gauge dynamics

Against this near-consensus expectation, the absence of experimental observation is itself a puzzle, and theoretical frameworks that **structurally preclude** monopoles (rather than merely permitting their absence) are unusual and worth recording. The 0-Sphere Model's hypothesis is one such framework.

## Open-path vs closed-loop line integrals (textbook context for #42 Sec 5)

In standard electromagnetism, the line-integral structure underlying Maxwell's equations is:

| Law | Integral form | Path | Source |
|---|---|---|---|
| Gauss (E) | ∮_S E·dA = Q_enc/ε₀ | Closed surface | Volume charge |
| Gauss (B) | ∮_S B·dA = 0 | Closed surface | (No magnetic charge) |
| Faraday | ∮_C E·dl = − dΦ_B/dt | Closed loop | Time-varying flux |
| Ampère–Maxwell | ∮_C B·dl = µ₀ I_enc + µ₀ε₀ dΦ_E/dt | Closed loop | Current + displacement |

The asymmetry is again visible: ∮_S E·dA can be nonzero (when charge is enclosed); ∮_S B·dA always vanishes (no enclosable magnetic charge). Existence of magnetic monopoles would change ∮_S B·dA = 0 to ∮_S B·dA = µ₀ Q_m,enc.

#42's Sec 5 invokes this textbook structure to draw a structural correspondence between the energy identity's term architecture and the integral asymmetry, but **the textbook framework itself does not preclude monopoles** — it merely encodes their absence as a separate empirical input (∇·B = 0). The 0-Sphere `0sm.md` layer offers a structural reading in which the absence is an internal consequence of the model's two-kernel geometry.

## References

[^Dirac1931]: P. A. M. Dirac, "Quantised singularities in the electromagnetic field," *Proc. Roy. Soc. Lond. A* **133**, 60–72 (1931). https://doi.org/10.1098/rspa.1931.0130

[^tHooft1974]: G. 't Hooft, "Magnetic monopoles in unified gauge theories," *Nucl. Phys. B* **79**, 276–284 (1974). https://doi.org/10.1016/0550-3213(74)90486-6

[^Polyakov1974]: A. M. Polyakov, "Particle spectrum in quantum field theory," *JETP Lett.* **20**, 194–195 (1974).

[^Nakahara2003]: M. Nakahara, *Geometry, Topology and Physics*, 2nd ed. (IOP Publishing, Bristol, 2003). https://doi.org/10.1201/9781315275826
