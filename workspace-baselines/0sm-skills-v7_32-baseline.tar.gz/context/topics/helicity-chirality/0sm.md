---
subject: helicity-chirality
layer: 0sm
title: "Helicity and Chirality: 0-Sphere Native Treatment"
applies_to: [13, 50, 61]
status: stub
created: 2026-05-05
updated: 2026-05-05
related_topics:
  - subject: spin
    layer: 0sm
example_readings: []
tags: [helicity, chirality, 0sphere-model, lorentz-invariance]
---

# Helicity and Chirality: 0-Sphere Native Treatment

**Status:** Stub. Paper #50 introduced the chirality χ = sign(da/dt) as a Lorentz-invariant quantity, distinct from helicity h = χ · sign(p_x) which is frame-dependent. To be populated when more papers extend the framework.

## Future content scope

- **χ = sign(da/dt) as Lorentz-invariant** (#50): the orientation of the phase flow on S¹ is preserved under Lorentz boosts, since boosts preserve the orientation of directed curves
- **h = χ · sign(p_x) as frame-dependent**: helicity flips when an observer overtakes the particle, but chirality does not
- **Electron/positron from traversal direction** (#50): χ = +1 → forward geodesic A→B → electron; χ = −1 → backward geodesic → positron
- **Four Dirac spinor components = χ × spin = 2 × 2** (#50): structural identification of the Dirac space
- **Connection to He-4 BEC** (#61, draft): two-electron chirality cancellation may be the kinematic origin of bosonic behavior in helium

## Reading guidance

Currently grounded in #50. Read in conjunction with `topics/spin/0sm.md` for context on the broader spin framework. Expected expansion when #61 is finalized.
