---
subject: thermal-geodesic
layer: 0sm
title: "Thermal Geodesics in the 0-Sphere Model: Variational Principle in Proper Time on Temperature-Dependent Metric"
applies_to: [5, 11, 18, 23, 24, 26, 29, 30, 31, 32, 33, 34, 35, 37, 44, 45, 51]
status: active
created: 2026-05-05
updated: 2026-05-06
related_topics:
  - subject: line-integrals
    layer: 0sm
  - subject: emergent-spacetime
    layer: 0sm
  - subject: background-independence
    layer: 0sm
  - subject: synge-world-function
    layer: 0sm
  - subject: thermodynamics
    layer: 0sm
  - subject: gravity-mediation
    layer: 0sm
example_readings: []
tags: [thermal-geodesic, thermal-metric, proper-time, variational-principle, 0sphere-model, internal-thermodynamic-geometry]
---

# Thermal Geodesics in the 0-Sphere Model

The **thermal geodesic** is a 0-Sphere-native dynamical object: a trajectory connecting two localized energy kernels (Kernel A and Kernel B), obtained by extremizing an effective action formulated with respect to a **temperature-dependent thermal metric** `G_µν(T)` and parametrized by **proper time τ** rather than coordinate time. In homogeneous and isotropic regions, the thermal geodesic reduces to a straight path in coordinate space while remaining a geodesic with respect to the effective thermal metric (vanishing covariant acceleration in the thermal connection).

The thermal geodesic is structurally distinct from the GR geodesic: it operates on a **thermodynamic-geometric metric** weighted by energetic and thermal considerations of the kernel system, not on the spacetime metric of general relativity directly. This makes it a 0-Sphere-specific object with no canonical textbook analog.

## Founder paper

This topic's **founder is `#24`** (Thermal Geodesics in the 0-Sphere Model: Extending General Relativity through Internal Thermodynamic Structure, 2025-08-XX, DOI 10.5281/zenodo.17765349). #24 introduces the **thermal geodesic equation** with thermal Christoffel symbols `Γ^µ_νρ(T)` derived from `G_µν(T)`, establishing the formal foundation that subsequent papers (the Line Integral Trilogy and beyond) build upon.

The **conceptual origin** is in `#11` (Quantum Oscillations in the 0-Sphere Model, 2024), which introduced the thermal geodesic concept as "a variational principle governing energy transfer between localized kernels" formulated in terms of proper time. #24 then provides the formal geometric structure (`G_µν(T)`, `Γ^µ_νρ(T)`, geodesic equation).

## Conceptual precursor (#5, 2019-09)

**User explicit articulation (HANDOFF v7.4)**: 「**のちにこの移動先はランダムではなく、測地線に沿って最小作用の原理により移動先を見つけるという、確率論から因果がある場所への移動、つまり熱測地線への議論や実在性へと昇華する。**」

`#5` ("Transition Theory of An Electron Traveling from Uncertain to Causal Basis", 2019-09) は本 topic の **6+ 年早い conceptual precursor**:

- **Sec III.C 「No random events」**: random walk から causal walk への transition、thermal potential energy gradient による direction selection (p = 1)、second law of thermodynamics 適用 ─ **シリーズ initial 「random → causal」 elevation articulation**
- **Sec III.D Landau-quote + Lagrangian applicability speculation**: Landau-Lifshitz 1971 「The Classical Theory of Fields」 p.131 quote (geometric optics への least action principle impossibility argument) を flip、photon sphere accelerating SHM motion なら Lagrangian applicability の future research direction
- **Sec IV Fermat's principle applicability articulation**: 「What we will expect following this research is a formal unification of the subject and Fermat's principle」 ─ Fermat's principle (variational principle) を electron trajectory への適用可能性 articulate

#5 は formal thermal geodesic equation の articulation を持たないが、**「電子移動先が random ではなく causal (thermal gradient by least-action-like principle で決定)」 という central conceptual move** をシリーズで最初に formal articulate、後の #11 conceptual origin → #24 founder → #29-#31 Trilogy lineage の direct lineage 起点。Topic-level でこの conceptual precursor 役割を articulate (thread membership は claim せず、C-28 thermal-geodesic thread founder は #24 のまま)。

## The Ten Papers Invoking Thermal Geodesics

| Paper | Role |
|---|---|
| **#5** (conceptual precursor, 2019-09) | **Random walk → causal transition + Fermat's principle / least action applicability の最初の articulation; シリーズ最初期の proto-thermal-geodesic seed (User 明示 「確率論から因果がある場所への移動 ... 熱測地線への議論や実在性へと昇華する」 lineage 起点)** |
| **#11** (conceptual origin) | First introduces thermal geodesic concept as variational principle for radiative energy transfer; proper-time-based dynamics |
| **#18** (Time-Dependent Mass) | `m(t) = m_0(1 - (1/2)sin²(ωt))` on thermal-modulated trajectory; thermal geodesic context |
| **#23** (Emergent Spacetime) | Section III.G articulates "energy-defined geodesic between A-B kernels" as part of emergent-spacetime program |
| **#24** (founder) | **Thermal geodesic equation** `d²x^µ/dτ² + Γ^µ_νρ(T) dx^ν/dτ dx^ρ/dτ = 0`; thermal metric `G_µν(T)`; thermal Christoffels; spherical harmonic representation `ρ(θ,φ) = Σ a_ℓm Y_ℓm` (Eq. V.1) |
| **#26** (Spin from Geometry) | Berry phase derivation uses thermal geodesic as adiabatic closed path |
| **#29** (Trilogy I) | **Thermal geodesic + Thomas precession spinorial connection**; `∫_γ ω_hyp ↔ (1/2) ∫(a × v) dτ` Poincaré-Thomas correspondence along thermal geodesic |
| **#30** (Trilogy II) | Eq. IV.1 thermal geodesic equation; microscopic flexibility ↔ macroscopic coherence on thermal geodesics |
| **#31** (Trilogy III) | Eq. VIII.1 thermal geodesic equation; Bianchi identity reinterpreted as "geometric consistency condition enforcing conservation of energy and momentum along thermal geodesics" |
| **#32** (Vacuum Energy) | References thermal geodesics as part of integral-ontology program |

## The Central Equation — Thermal Geodesic Equation

The defining equation from `#24` (and recurrent in `#30 Eq. IV.1`, `#31 Eq. VIII.1`):

$$\frac{d^2 x^\mu}{d\tau^2} + \Gamma^\mu_{\nu\rho}(T) \frac{dx^\nu}{d\tau} \frac{dx^\rho}{d\tau} = 0$$

where:

- **τ**: proper time (the integration parameter, ensuring reparametrization invariance and tying observables to clock readings)
- **`G_µν(T)`**: temperature-dependent thermal metric (the effective metric weighted by the kernel TPE structure)
- **`Γ^µ_νρ(T)`**: thermal Christoffel symbols derived from `G_µν(T)`
- **`x^µ(τ)`**: trajectory of the photon sphere (the bosonic energy carrier between Kernel A and Kernel B)

In homogeneous regions, this reduces to a straight trajectory in real space, but the path remains a geodesic in the **thermal-metric sense** (vanishing covariant acceleration with respect to `Γ^µ_νρ(T)`).

## The Two-Kernel Configuration

The configuration in which thermal geodesics are typically deployed:

- **Kernel A** at `x = -a` (one of the two zero-sphere points)
- **Kernel B** at `x = +a` (the other zero-sphere point)
- **Photon sphere** as bosonic excitation propagating between them
- **TPE oscillation**: `T_e1 = E_0 cos⁴(ωt/2)` (Kernel A), `T_e2 = E_0 sin⁴(ωt/2)` (Kernel B)
- **Thermal gradient**: `∇(T_e2 - T_e1) = E_0 sin θ` (drives the photon sphere harmonic motion)
- **Endpoint conditions**: `v = 0` at `x = ±a` (kernel locations); `a = 0` at `x = 0` (midpoint)

The thermal geodesic is the **extremal path** connecting these endpoints under the variational principle.

## The Two-Lobe Structure of `a × v` along the Geodesic

A central geometric feature, articulated in **#29** (Trilogy I): on the thermal geodesic from `x = -a` to `x = +a`, the cross product `a × v` (acceleration × velocity) vanishes at all three points `x = -a, 0, +a` but develops **two smooth lobes** between them — one on `(-a, 0)`, one on `(0, +a)`. Each lobe contributes π to the Thomas-precession-induced spinorial phase, totaling **2π per one-way traversal** (4π per round-trip = SU(2) double-valued character).

This two-lobe structure is the **geometric origin of the SU(2) factor of 2** in the 0-Sphere derivation of spin.

## Topic content scope

This layer documents the 0-Sphere-native treatment of thermal geodesics:

- **Variational principle in proper time** (#11, #24): Energy transfer extremizes an effective action formulated with τ as integration parameter
- **Thermal metric `G_µν(T)`** (#24): Temperature-dependent metric encoding the kernel TPE structure
- **Thermal Christoffel symbols `Γ^µ_νρ(T)`** (#24): Derived from `G_µν(T)`, governing parallel transport on the thermal manifold
- **Thermal geodesic equation** (#24, #30 Eq. IV.1, #31 Eq. VIII.1): Central dynamical equation
- **Two-lobe structure of `a × v`** (#29): Geometric origin of SU(2) factor of 2
- **Poincaré-Thomas correspondence** (#29 Eq. II.2): Schematic mapping `∫_γ ω_hyp ↔ (1/2) ∫(a × v) dτ` — hyperbolic upper-half-plane geometry as universal prototype for connection-driven phase accumulation along thermal geodesics
- **Spherical harmonic representation `ρ(θ,φ) = Σ a_ℓm Y_ℓm`** (#24 Eq. V.1): Angular dependence of energy distribution along thermal geodesics; develops into #57 Y_ℓ^m imprinting program
- **Bianchi identity as consistency condition** (#31 Eq. VIII.2): `∇_µ G^µν ≡ 0` reinterpreted as "geometric consistency condition enforcing conservation of energy and momentum along thermal geodesics"
- **Microscopic flexibility ↔ macroscopic coherence** (#30 Section 6.C): Many microscopic thermal geodesics aggregate to produce macroscopic Einstein-equation-level coherence

## Distinction from related concepts

- **Thermal geodesic vs GR geodesic**: GR geodesic is on spacetime metric `g_µν`; thermal geodesic is on thermal metric `G_µν(T)`. The thermal geodesic does not directly inherit from GR but is structurally analogous.
- **Thermal geodesic vs Wilson line (#55)**: Wilson lines are abstract gauge-connection line integrals; thermal geodesics are specific physical trajectories of energy carriers. The two are related (Wilson lines along thermal geodesics yield phase accumulation `Φ = ∫_γint ω`) but distinct.
- **Thermal geodesic vs thermal metric `G_µν(T)`**: The geodesic is the extremal path; the metric is the geometric structure on which extremization is defined.
- **Thermal geodesic vs Synge world function `σ(x,x')`**: The Synge world function provides the geometric distance between two events on the thermal geodesic; in 0-Sphere context, the two events are the two kernel positions. See `synge-world-function/0sm.md`.

## The connecting thread: thermal geometry ↔ line integrals ↔ metric emergence

Thermal geodesics function as the **primary substrate** on which the Line Integral Trilogy (#29-#31) and subsequent applications (#32, #51, #54, #55, #57) build:

- **Line Integral Trilogy** (#29-#31): Line integrals are taken **along thermal geodesics** (`∫_γ ω · dτ` with γ = thermal geodesic in proper time)
- **#32 Vacuum Energy**: Phase accumulation `Φ = ∫_γint ω` is along internal thermal geodesics
- **#51 Helical Trajectory**: Helical motion along thermal-geodesic-like trajectories; metric emergence via fixed-endpoint line integrals over Synge world function
- **#54 Maxwell as Derived**: Electromagnetic sector emerges as low-energy limit of line integrals along thermal geodesics
- **#57 Y_ℓ^m Imprinting**: Spherical harmonic mode imprinting along thermal geodesic angular structure

## Strategic role as query node

For future paper analysis and brainstorming, this topic functions as a **dynamical-object diagnostic node**:

- **For new technical proposals**: Does the proposal use thermal geodesics, GR geodesics, or generic worldlines? What is the metric on which extremization is defined?
- **For derivation hierarchy**: Many derivations in the 0-Sphere Model proceed `thermal geodesic → line integral → physical observable`; tracking thermal geodesic invocation helps locate the derivation step.
- **For thermal-vs-GR distinction**: When the model bridges to GR (via #51 Synge world function, #57 gravitational coupling, #58 spin-2 mediator), tracking how the thermal geodesic relates to the GR geodesic is essential.

## Reading guidance

- **Start with `#11`** for the conceptual origin of thermal geodesics in radiative energy transfer.
- **Then `#24`** (founder) for the formal thermal metric `G_µν(T)`, thermal Christoffels `Γ^µ_νρ(T)`, and thermal geodesic equation.
- **Then `#29`** (Trilogy I) for the two-lobe `a × v` structure and Poincaré-Thomas correspondence.
- **Then `#30`** (Trilogy II) for the microscopic flexibility ↔ macroscopic coherence on thermal geodesics.
- **Then `#31`** (Trilogy III) for the Bianchi identity as consistency condition along thermal geodesics.

For applications:
- **`#32`** for vacuum energy dissolution context
- **`#51`** (forward) for helical trajectory + Synge world function metric emergence
- **`#57`** (forward) for Y_ℓ^m angular structure on thermal geodesics

## No textbook layer

The thermal geodesic is a **0-Sphere-specific construct** without canonical textbook treatment. While GR geodesic textbooks (Wald 1984, Misner-Thorne-Wheeler 1973) describe the geometric formalism that the 0-Sphere thermal geodesic adapts, the specific concept of a geodesic on a temperature-dependent thermal metric is unique to the 0-Sphere program. Hence no `thermal-geodesic/textbook.md` companion file is created. Standard GR geodesic theory should be referenced directly via the cited literature when needed.
