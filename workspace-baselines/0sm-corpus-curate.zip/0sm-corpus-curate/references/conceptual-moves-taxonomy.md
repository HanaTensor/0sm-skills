# Conceptual Moves Taxonomy

> Skill A の conceptual-moves taxonomy reference。Move 1-8 active entries + Move 9 candidates + modest articulation 規律 + Move-type future articulation candidates。`context/derived/conceptual-moves.md` の content + curatorial discipline。

---

## 1. Conceptual Moves とは

「Conceptual Move」 は 0-Sphere Model paper series 全体で reuse される **ontological / methodological 操作** を identify する curatorial taxonomy。各 Move は:

- **Carrier papers**: Move を embodiment する papers
- **Move pattern**: 操作の structural description
- **Move type**: epistemic / methodological / structural / ontological 等

Conceptual moves は paper-level conceptual machinery の reusable atoms として function。後続 paper drafting / cross-reference 分析の handle として使用される。

## 2. Active Move entries (Move 1-8)

`context/derived/conceptual-moves.md` で formal taxonomy として記録される 8 entries (HANDOFF v7.26 baseline):

### Move 1: 観測量を線積分 (経路上の積分) として再定義する

- **Carrier papers**: #29 (Trilogy I), #30 (Trilogy II), #31 (Trilogy III)
- **Pattern**: 物理量の primary observable 性を local field strength から **path-ordered line integral** へ shift。Aharonov-Bohm / Berry phase / Wilson loop の unifying framework として function。
- **Move type**: ontological + methodological
- **Subsequent extensions**: #34 (gravity-mediation context), #37 (mgh interpretation), #40-#41 (derivative-order-mismatch), #44 (closed-loop ontology), #45 (open-path framework), #55 (four-function decomposition)

### Move 2: 力学的問題を熱力学的経路問題に還元する

- **Carrier papers**: #11 (entropic-action thermal-geodesic), #29 (Trilogy I)
- **Pattern**: dynamical equation を thermal-geodesic ontology に reframe、熱力学的 minimum-action principle (entropic action) を mechanical Lagrangian の上位 principle として position。
- **Move type**: ontological + reductive

### Move 3: 古典的・量子論的 dichotomy を「同一物の二つの記述」 に解消する

- **Carrier papers**: #14 (electron classical-vs-quantum), #20 (proton structure), #29-#31 (Trilogy)
- **Pattern**: 「classical」 vs 「quantum」 区別を shared underlying ontology の二つの **observational layer** として reframe。Move 8 (observational-layer-sharing meta-pattern) の ancestor。

### Move 4: 場 (field) を直接量化せず、「経路 + 熱力学」 から場を導出する

- **Carrier papers**: #17 (U(1) from clock synchronization), #54 (Maxwell electrodynamics derived limit)
- **Pattern**: gauge field A_µ を fundamental field として置かず、internal phase + thermal-geodesic principle から **derived secondary structure** として construct。

### Move 5: 等価原理 (Equivalence Principle) を 0-Sphere 内部構造の geometric-thermodynamic consequence として導出する

- **Carrier papers**: #34 (Geometric Confinement: Emergent Gravitational Dynamics), #52 (λ_C cancellation theorem)
- **Pattern**: Einstein equivalence principle を 0-Sphere internal structure の thermodynamic constraint として derive、separately-postulated principle ではなく consequence として position。

### Move 6: 質量 / 慣性 を「閉じた光子球軌道の time-averaged momentum reservoir」 として再解釈する

- **Carrier papers**: #1 (foundational Two Perfect Black Bodies), #11, #14, #33 (Geometrical Confinement)
- **Pattern**: rest mass + inertia を photon-sphere closed-orbit time-averaged momentum reservoir として reinterpret。E_0 Hamiltonian identity (cos⁴(θ/2) + sin⁴(θ/2) + (1/2)sin²θ = 1) と paired。

### Move 7: 質量 / Compton scale 不変性を **observational layer 共通性** として表明する

- **Carrier papers**: #46 (Geometric Origin of One-Half Factor)
- **Pattern**: dimensional analysis result が specific dynamical mechanism なしで成立することを「observational layer 共通性」 (observational-layer-sharing) として明示。dimensional / structural / observational layers の中で **observational layer のみ shared** が論じられる pattern。
- **Formal addition**: HANDOFF v7.13 で formal taxonomy 追加。

### Move 8: Observational-layer-sharing meta-pattern (epistemic move)

- **Carrier papers**: #46 (origin), #44 (three-classical-problems unified resolution)
- **Pattern**: 異なる ontological layers (geometric / thermodynamic / observational) で同 observable が emerge する meta-pattern。Move 7 の generalization。
- **Formal addition**: HANDOFF v7.22 で formal taxonomy 追加 (5 transitions modest articulation 後、User explicit articulation gate 通過)。

## 3. Move 9 candidates (modest articulation 段階)

HANDOFF v7.26 baseline で Move 9 slot に 2 distinct candidates が surface している (両者は competing ではなく independent Move-type candidates):

### Move 9 candidate (a): 'unification' type

- **Carrier paper**: #44 (Internal Energy Stabilization, Charge Localization, Superradiant Rephasing)
- **Pattern**: three-historically-separate-problems (ZB persistence + radiative decay absence + charge localization) を **single ontological revision** (closed line-integral processes constrained to thermal geodesics) で unified-resolve。Sec 1 + Sec 5 explicit 「**all three difficulties admit a unified resolution... arise from the same underlying principle**」。
- **Move-type**: 'unification' (multiple problems unified by single ontological revision)
- **Modest articulation status**: HANDOFF v7.24 で initial articulate、formal commit pending User explicit articulation gate

### Move 9 candidate (b): 'reframe' type

- **Carrier paper**: #45 (Open-Path Spinorial Transport, Holonomy Sufficiency thesis)
- **Pattern**: torsion-implying-reading を holonomy-sufficient-reading に **reframe**、4π periodicity + ordered-path asymmetry が standard SU(2) holonomy + non-Abelian curvature framework で完全 accommodate されることを demonstrate、torsion を logical necessity ではなく open conjecture として position。Sec V + Sec VI + Sec VII の triple articulation。
- **Move-type**: 'reframe' (existing reading structure を新 reading structure に shift)
- **Modest articulation status**: HANDOFF v7.25 で initial articulate、formal commit pending User explicit articulation gate

### Move 9 candidates の relationship

両 candidates は **同 Move 9 slot に competing** ではない。conceptual-moves.md taxonomy 内 future-articulation-candidates として **independent records**、formal addition 順序は User explicit articulation gate triggered:

```
Move 9 slot
├── candidate (a) 'unification' (#44 carrier, v7.24 surface, 1 transition)
└── candidate (b) 'reframe' (#45 carrier, v7.25 surface, 1 transition)
```

両 candidates が独立に sustained worth を確認できれば、Move 9 ('unification') + Move 10 ('reframe') として両者 separate formal addition の path がある。あるいは一方が superseded されればもう一方のみ formal commit。

## 4. Modest articulation discipline

**HANDOFF v7.14 'welding-hub sub-type' 取下げ precedent**:

v7.14 で 'welding-hub' という Methodological-honesty sub-type 候補が initial articulate されたが、後続 transitions で sustained worth が確認できず、最終的に **取り下げ**。本 precedent は curatorial discipline の foundational reference。

### Discipline rules

1. **観察された pattern は formal taxonomy に直行しない**:
   - 第 1 instance observed → modest articulation 段階で frontmatter (series_role) に record
   - 第 2-4 instances sustained → modest 維持
   - 第 5 instance + User explicit articulation gate 通過 → formal taxonomy promotion 候補

2. **Premature commitment は workspace 質を degrade**:
   - 一度 formal taxonomy に追加した Move / sub-type は retraction が painful
   - 未確定 patterns を formal commit すると後続 dialogue で confusion 発生
   - workspace は **conservative formal taxonomy** + **liberal modest articulation pool** の組み合わせ

3. **Modest articulation pool の役割**:
   - 累積 60 candidates (HANDOFF v7.26 baseline) は **formal taxonomy candidates の reservoir**
   - 多くは natural に supersede される / fade out / superseded by later articulation
   - Survive する candidates が formal taxonomy entry 候補

### Examples of modest articulation candidates (HANDOFF v7.26 累積 60 selection)

#### Subtitle pattern variants
- `"A [adjective] Supplement on [aspect]"` form (#36, #40, #41, #42, #43, #46)
- `"Supplementary Note on [aspect] in the 0-Sphere Model"` sub-variant (#39, #44)
- `"(Structural Clarification Note)"` parenthetical-suffix-form (#45, v7.25 第 1 instance)

#### AI-collaboration phrasing variants (lineage 第 12 instance candidate)
- "supportive role for textual organization" (#36 family, 6 instances)
- "pedagogical and editorial aid" (#39 family)
- "compact 2-item form" (#42, #43)
- "interactive conversational tool" (#45, NEW 第 1 instance v7.25)

#### Methodological-honesty sub-types (累積 7 candidates)
- (a) #35 author-uncertainty acknowledgment
- (b) #36 program-level scope-delimitation
- (c) #39 specific-question-pair logical-separation
- (d) #42 specific-claim-level hypothesis-status
- (e) #43 substantial-mathematics-without-physical-claim ('proof of concept')
- (f) #44 principled-vs-practical-distinction (v7.24)
- (g) #45 open-conjecture-explicit-articulation (v7.25)

#### Companion / sister-paper articulations
- #40+#41 derivative-order-mismatch dual-founder companion pair (subtitle-parallel, v7.17)
- #36+#42 title-prefix-parallel companion pair with-citation (v7.18)
- #43+#45 March 2026 torsion-supplement-pair (different angles, v7.25)

#### Multi-relation declarations (v7.25 + v7.26)
- v7.25 dual-relation-single-target (#40 in #45 supplements + continues)
- v7.26 quadruple-relation-single-target (#56 in #57 Cites + Continues + Is part of + Requires)

#### Forward-reference patterns (v7.26)
- `forward-companion-bibliographic-reference for deferred items` (#57 → #58/#59/#60, 第 1 instance)
- `5-paper-coordinated-release foundational-mechanism-of-sequence` (#57-#61, 第 1 instance)

#### Pedagogical-appendices-systematic-deployment (v7.25)
- #45 で 第 1 instance: App A (SU(2)/4π primer) + App B (connection/curvature/torsion primer with Table III) + App C (Wilson loops vs open-path)

## 5. Move-type future articulation candidates

`context/derived/conceptual-moves.md` で future articulation candidate types として stub される possible Move types:

| Type | Description | Carrier candidate |
|---|---|---|
| `unification` | multiple problems unified by single ontological revision | #44 Move 9 candidate (a) |
| `reframe` | existing reading structure shift to new reading structure | #45 Move 9 candidate (b) |
| `welding-hub` | (取下げ済み, v7.14 precedent) | (none) |

formal addition 候補は (1) sustained worth confirmed + (2) User explicit articulation gate 通過 + (3) Move number assignment confirmed の triple condition 満たし時。

## 6. Move taxonomy formal addition workflow

新 Move を formal taxonomy に追加する際の workflow (Move 7 v7.13 / Move 8 v7.22 precedent):

### Step M1: Sustained worth confirmation

- 5 transitions modest articulation 後 (HANDOFF v7.22 Move 8 precedent), または
- User explicit articulation gate 通過 (e.g., 「Move 8 entry の正式追加で良いと判断する」)

### Step M2: Move number assignment

次の available Move number を assign (現状 Move 9 slot が next available)。

### Step M3: Update `context/derived/conceptual-moves.md`

新 Move entry を formal taxonomy section に追加:
- Move number
- Move name (concise)
- Carrier papers (paper number list)
- Pattern description (1-2 paragraphs)
- Move type (epistemic / methodological / structural / ontological / unification / reframe / etc.)
- Subsequent extensions (任意)

### Step M4: Update papers' frontmatter (carrier papers)

各 carrier paper の frontmatter (series_role) で formal Move membership を articulate。

### Step M5: Update HANDOFF.md

v(N+1) transition narrative に Move addition を記録:
- formal addition date
- modest articulation history (何 transitions の modest 後 formal commit か)
- Move addition rationale + sustained worth criteria

### Step M6: Run validators

`validate_conceptual_moves.py` で 0-error 確認 (paper references resolve, no forward-dangling)。

## 7. Cross-reference query handling

User が Move 関連 query を出した場合:

### 7.1 「Move N の carrier paper は?」

```
→ context/derived/conceptual-moves.md の Move N entry を参照
→ Carrier papers list を answer
→ 必要に応じて各 carrier paper の context/papers/0XX.md frontmatter で
  Move N invocation の specific role を確認
```

### 7.2 「#XX が invoke する Move は?」

```
→ context/papers/0XX.md の series_role / body content で Move references を grep
→ Move N memberships を answer
→ peripheral / substantive / central の strength で qualify
```

### 7.3 「Move 9 はいつ formal addition?」

```
→ HANDOFF.md latest version で Move 9 candidates の current modest articulation status 確認
→ candidate (a) 'unification' + candidate (b) 'reframe' の双方 status を answer
→ User explicit articulation gate を待っている status であることを記述
```

### 7.4 「新 Move taxonomy に追加すべき pattern を探して」

```
→ HANDOFF.md latest version で 累積 modest articulation candidates を review
→ Move-type candidates (unification / reframe / 他) に該当する patterns を identify
→ sustained worth 候補を suggest (ただし formal addition は User decision)
```

## 8. References (本 SKILL 内)

- `references/threads-and-topics.md`: thread invocations は Move embodiment と関連 (carrier papers が同一 thread を共有することがある)
- `references/curatorial-disciplines.md`: modest articulation discipline の詳細 + HANDOFF v7.14 'welding-hub' 取下げ precedent の full record
- `references/queries-layer.md`: queries layer は Move との関係 (q-001 〜 q-004 が Move embodiment を invoke する)
