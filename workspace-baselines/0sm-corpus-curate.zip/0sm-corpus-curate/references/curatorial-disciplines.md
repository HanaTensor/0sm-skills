# Curatorial Disciplines

> Skill A の curatorial discipline 集約 reference。Modest articulation discipline (HANDOFF v7.14 'welding-hub' 取下げ precedent) + Validator state preservation + Number-based references (single source of truth) + Multi-relation declarations + Mixed-form coexistence pattern + AI-collaboration acknowledgment lineage tracking。

---

## 1. Modest articulation discipline

### 1.1 Founding precedent: HANDOFF v7.14 'welding-hub sub-type' 取下げ

HANDOFF v7.14 で Methodological-honesty pattern の sub-type として 'welding-hub' が initial articulate された。後続 transitions で sustained worth が確認できず、最終的に **取り下げ**。

本 precedent は curatorial discipline の foundational reference として後続全 transitions で繰り返し参照される (modest articulation 段階維持の論拠として)。

### 1.2 Discipline rules

#### Rule 1: 観察された pattern は formal taxonomy に直行しない

- 第 1 instance observed → modest articulation 段階で frontmatter (series_role) に record
- 第 2-4 instances sustained → modest 維持
- 第 5+ instances + User explicit articulation gate 通過 → formal taxonomy promotion 候補

#### Rule 2: Premature commitment は workspace 質を degrade

- 一度 formal taxonomy に追加した Move / sub-type は retraction が painful
- 未確定 patterns を formal commit すると後続 dialogue で confusion 発生
- workspace は **conservative formal taxonomy** + **liberal modest articulation pool** の組み合わせ

#### Rule 3: Modest articulation pool は formal taxonomy candidates の reservoir

- 累積 60 candidates (HANDOFF v7.26 baseline) が pool に persist
- 多くは natural に supersede される / fade out / superseded by later articulation
- Survive する candidates が formal taxonomy entry 候補

### 1.3 Modest articulation pool (HANDOFF v7.26 累積 60 selection)

#### Subtitle pattern variants
- `"A [adjective] Supplement on [aspect]"` form (#36, #40, #41, #42, #43, #46) — 6 instances
- `"Supplementary Note on [aspect] in the 0-Sphere Model"` sub-variant (#39, #44) — 2 instances
- `"(Structural Clarification Note)"` parenthetical-suffix-form (#45, v7.25 第 1 instance) — 1 instance

#### AI-collaboration phrasing variants (lineage 第 12 instance candidate)
- `"supportive role for textual organization"` (#36 family, 6 instances: #36, #46, #42, #43, #44 readme.txt, #45 readme.txt)
- `"pedagogical and editorial aid"` (#39 family, 3 instances: #39, #44 paper-internal)
- `"compact 2-item form"` (#42, #43)
- `"linguistic polishing"` (#47)
- `"interactive conversational tool"` (#45 paper-internal, NEW 第 1 instance v7.25, lineage 第 12 instance)

#### Methodological-honesty sub-types (累積 7 candidates)
- (a) #35 author-uncertainty acknowledgment (v7.14)
- (b) #36 program-level scope-delimitation (v7.15)
- (c) #39 specific-question-pair logical-separation (v7.16)
- (d) #42 specific-claim-level hypothesis-status (v7.18)
- (e) #43 substantial-mathematics-without-physical-claim ('proof of concept', v7.19)
- (f) #44 principled-vs-practical-distinction (v7.24)
- (g) #45 open-conjecture-explicit-articulation (v7.25)

#### Companion / sister-paper articulations
- #40+#41 derivative-order-mismatch dual-founder companion pair (subtitle-parallel, v7.17)
- #36+#42 title-prefix-parallel companion pair with-citation (v7.18)
- #43+#45 March 2026 torsion-supplement-pair (different angles, v7.25)

#### Multi-relation declarations
- v7.25 dual-relation-single-target (#40 in #45 supplements + continues, 第 1 instance)
- v7.26 quadruple-relation-single-target (#56 in #57 Cites + Continues + Is part of + Requires, 第 2 strengthening instance)

#### Forward-reference / sequence patterns (v7.26)
- `forward-companion-bibliographic-reference for deferred items` (#57 → #58/#59/#60, 第 1 instance)
- `5-paper-coordinated-release foundational-mechanism-of-sequence` (#57-#61, 第 1 instance)

#### Pedagogical-appendices-systematic-deployment (v7.25)
- #45 で 第 1 instance: App A (SU(2)/4π primer) + App B (connection/curvature/torsion primer with Table III) + App C (Wilson loops vs open-path)

#### Mixed-form coexistence (v7.19 / v7.24 / v7.25)
- #43 v7.19 で initial articulate
- #44 v7.24 strengthening 第 1 instance
- #45 v7.25 sustained-operation-confirmation 第 1 instance (functional separation habit confirmed across 2 consecutive papers)

#### Move 9 candidates (HANDOFF v7.24 / v7.25)
- candidate (a) 'unification' (#44, 1 transition)
- candidate (b) 'reframe' (#45, 1 transition)

### 1.4 Promotion gate criteria

modest articulation candidate が formal taxonomy promotion 候補となる条件:

1. **Sustained worth confirmation**: 3+ instances across multiple HANDOFF transitions、または specific conceptual significance (e.g., Move 8 v7.22 で 5 transitions 後 formal commit)
2. **User explicit articulation gate**: User explicit decision (e.g., 「Move 8 entry の正式追加で良いと判断する」 v7.22)
3. **Workspace integration assessment**: formal addition が workspace structure と整合 (Move number assignment available, topic file location available, etc.)

3 conditions 全 satisfied で formal taxonomy promotion 実施。HANDOFF v(N+1) transition narrative で promotion 履歴 (modest 段階 transitions 数 + sustained worth criteria + promotion rationale) を記録。

## 2. Validator state preservation

### 2.1 Validator overview

`scripts/validate_frontmatter.py`:
- YAML parsing (quote balance, indentation, etc.)
- Required fields presence check
- `predictions[].status` enum compliance
- `topics_invoked` directory existence
- Topic frontmatter (`applies_to` paper number existence + status enum)

`scripts/validate_conceptual_moves.py`:
- `context/derived/conceptual-moves.md` 内 paper references が curated set 内
- Forward-dangling references なし

### 2.2 All-clear maintenance discipline

HANDOFF v7.26 baseline で **第 11 instance all-clear maintained**。各 transition で:

```
== Final v(N+1) verification ==
python3 scripts/validate_frontmatter.py
  → expected: "OK: NN paper(s), MM topic file(s) validated successfully"
python3 scripts/validate_conceptual_moves.py
  → expected: "✓ All paper references resolve to existing curated papers."
```

両 validator が **0-error 出力** することが all-clear 条件。

### 2.3 Common validator errors and resolutions

#### Error: YAML quote balance (HANDOFF v7.26 #57 precedent)

長い quoted string (series_role 等) で **closing `"` 欠落**。

```
YAML Error: while parsing a block mapping
expected <block end>, but found '<scalar>'
```

**Resolution**: closing `"` を追加。`str_replace` で部分編集する際、最後の `。"` を確実に保つ。

#### Error: predictions status 不正値 (HANDOFF v7.25 #44 draft precedent)

```
Topic <topic>: prediction status 'structural' not in VALID_PREDICTION_STATUS
```

VALID_PREDICTION_STATUS = `{"unmeasured", "partial", "confirmed", "refuted", "open", "technically-difficult"}`

**Resolution**: framework-level claim には `open` を使用、`structural` は schema 外。

#### Error: Topic directory missing

```
Paper #XX: topics_invoked includes '<topic-name>' but context/topics/<topic-name>/ does not exist
```

**Resolution**: topic 名 typo 確認、または新 topic 新設 workflow (HANDOFF v7.17 / v7.18 precedent) 実施。

#### Error: Forward dangling reference

```
Topic <topic>: applies_to includes nonexistent paper #YY
```

**Resolution**: paper #YY が curate されているか確認、forward references の場合 paper #YY を pre-curate (#57 で #58/#59/#60 を pre-curate した v7.26 case)。

#### Error: Conceptual moves forward-dangling

```
Move M references paper #YY but #YY is not in curated set
```

**Resolution**: 該当 paper を curate するか、Move entry の paper reference を update。

### 2.4 Validator running discipline

curate / refinement の各 step 完了後、必ず両 validator を実行:

1. New paper curate: Step 11 (validators) で実行 + Step 12 (derived regenerate) 前に 0-error 確認
2. Relations refinement: Step R5 (validators) で実行
3. Topic 新設: applies_to update 後 + HANDOFF transition update 前
4. Move taxonomy update: `conceptual-moves.md` edit 後

**0-error 維持失敗時の対応**:
- 直近 edit を revert / fix
- HANDOFF transition update を 0-error 達成まで保留
- baseline package を中断、修正後 reimplement

## 3. Number-based references (single source of truth)

### 3.1 Founding precedent: HANDOFF v7.21 #30 DOI audit

HANDOFF v7.21 で `#30` (From Curvature to Connection) について audit:
- v1 DOI: 10.5281/zenodo.18135855 (旧版、initial publication)
- v2 DOI: 10.5281/zenodo.18819682 (現行版、2026-03-01 revision)

User explicit decision: 「**v2 を消してもらってよい**」 (workspace canonical DOI を v2 に統一)。

### 3.2 Discipline rules

#### Rule N1: Workspace canonical reference は paper number

```
relations: 
  supplements: [33, 35, 38, 40]   # paper numbers, 各 paper の最新 canonical DOI が source of truth
  references: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41]
```

**paper 番号** が単一 truth source、DOI は各 paper の `papers/0XX.md` frontmatter の `doi:` field で取得。

#### Rule N2: Historical bibitem DOI は body text で document

paper の bibitem が old DOI (v1) を cite する場合、workspace では:

- frontmatter `doi:` field は **canonical (latest) DOI** に統一
- body text comments で historical DOI revision を document
- 例: #45 frontmatter で `references: [..., 30, ...]` (paper number) と記録、bibitem [8] が v1 DOI 18135855 を cite することは body text で言及

#### Rule N3: DOI revision tracking

paper が revised される際 (rare):
- 旧 frontmatter DOI を新 DOI に update
- update_history entry 追加 (DOI revision の context + canonical DOI 統一 rationale)
- 該当 paper を cite する 後続 papers の bibitem は旧 DOI 残存可能 (publication chronology の reflect)、workspace canonical は新 DOI

### 3.3 Multi-paper DOI audit precedent

HANDOFF v7.21 #30 audit が現状唯一の DOI revision case。後続 papers で revised papers が surface した場合、本 v7.21 precedent に従う。

## 4. Multi-relation declarations

### 4.1 Precedent timeline

#### v7.25 dual-relation-single-target (#40 in #45)

paper #45 で:
- `supplements: [33, 35, 38, 40]` — #40 は thematic-extension role
- `continues: [29, 31, 40]` — #40 は sequential-continuation role

同 target paper (#40) が両 relation fields に登場、シリーズ initial 同 target paper への dual-relation declaration。supplements と continues は distinct articulation で同 target paper に対する dual relation。

#### v7.26 quadruple-relation-single-target (#56 in #57)

paper #57 zenodo_relations.txt で #56 が:
- `[1] Cites`
- `[3] Continues`
- `[5] Requires`
- `[6] Is part of`

の 4 relations で simultaneously declare。Workspace 内では `continues + requires` 2 fields で capture (v7.26 NEW pattern (d) workspace schema is_part_of gap)。

### 4.2 Discipline rules

#### Rule R1: Multi-relation declarations are supported pattern

Same target paper への複数 relation types declaration は **支持される pattern**。各 relation field が distinct semantic role を担うため、conceptually 矛盾しない。

#### Rule R2: relation field の semantic distinction

| Field | Semantic role |
|---|---|
| `supplements` | thematic-extension role (本論文が他論文の analysis を extend) |
| `continues` | sequential-continuation role (本論文が他論文の next-question を articulate) |
| `requires` | logical-prerequisite role (本論文の理解に必須 prerequisite) |
| `references` | bibitem cite (但し supplements/continues/requires には含まれない) |

各 relation field は独立 semantic role、同 target paper が複数 fields に登場することは **information loss なし**。

#### Rule R3: Workspace schema 'is_part_of' field gap acknowledgment

HANDOFF v7.26 NEW pattern (d) で identify された workspace schema gap:

- Zenodo metadata の `[6] Is part of` は workspace `papers/0XX.md` schema に直接 field なし
- 本 relation は `continues + requires` で indirect capture (information loss なし)
- Skill B (Zenodo upload skill) で zenodo_relations.txt 生成時、`Is part of` を **immediate predecessor in chronological/numerical sequence** から derive する rule を define
- workspace 側に `is_part_of` field 追加は currently 不要 (gap の認識のみ)

### 4.3 Multi-relation rationale documentation

各 relation field invocation の rationale を frontmatter コメントで明記:

```yaml
relation:
  supplements: [33, 35, 38, 40]   # 4 papers への explicit supplement (zenodo_relations [2]):
                                    # (1) #33 ...rationale...
                                    # (2) #35 ...rationale...
                                    # (3) #38 ...rationale...
                                    # (4) #40 ...rationale... (本 #45 で supplements + continues 双方に登場、dual-relation 第 1 instance)
  continues: [29, 31, 40]   # 3 papers への continuation declaration:
                              # (1) #29 ...
                              # (2) #31 ...
                              # (3) #40 ...rationale... (dual-relation 第 2 ロール continues)
```

## 5. Mixed-form coexistence pattern

### 5.1 Precedent timeline

readme.txt vs paper-internal Acknowledgments で AI-collaboration phrasing が異なる pattern:

#### v7.19 #43 initial articulation

#43 で readme.txt と paper-internal の AI-collaboration phrasing が distinct であることを initial articulate。

#### v7.24 #44 strengthening 第 1 instance

#44:
- readme.txt: #36 phrasing instance ("limited supportive role for textual organization")
- paper-internal: NEW QFT-verification scope variant ("pedagogical and editorial aid... verify standard QFT presentation")

両者の coexistence が strengthening 第 1 instance。

#### v7.25 #45 sustained-operation-confirmation 第 1 instance

#45:
- readme.txt: #36 phrasing 6th instance
- paper-internal: NEW "interactive conversational tool" variant

#44 + #45 双方が同 structural pattern (external = #36 phrasing established, paper-internal = NEW variant) を示し、author の **functional separation habit** が **2 consecutive instances で sustained operation 確認**。

### 5.2 Discipline rule

#### Rule M1: Functional separation habit recognition

- external metadata (readme.txt) → standardized prior phrasing instance (archive function)
- paper-internal Acknowledgments → NEW variant introduction (specific-paper-content-tailored function)

両者は curatorial signal として **distinct functional roles**。Mixed-form coexistence は author の deliberate functional separation habit を表す。

#### Rule M2: Modest articulation 維持

本 pattern は modest articulation 段階維持 (HANDOFF v7.25 baseline)、formal taxonomy 追加は post-v7.25 で 第 3 sustained instance 確認候補。

## 6. AI-collaboration acknowledgment lineage tracking

### 6.1 Lineage タイムライン

各 paper の AI-collaboration phrasing を historical lineage 内 position する discipline:

| # | Date | Phrasing | Variant | Lineage instance |
|---|---|---|---|---|
| #9 | 2023-04 | (initial Appendix A) | (founding) | 1 |
| #34 | 2026-01-31 | "supportive tools for paragraph structuring..." | Python code generation specific | 2 |
| #35 | 2026-02-07 | "consultative tool" + "explanatory flow" | 4-item negative scope | 3 |
| #36 | 2026-02-11 | "limited supportive role for textual organization" | first instance, full 3-item form | 4 |
| #37 | 2026-02-14 | "structure/clarity + math-expression" | (continuation) | 5 |
| #39 | 2026-02-22 | "pedagogical and editorial aid" | NEW phrasing 2-item negative | 6 |
| #40 | 2026-02-23 | "textual organization and clarity" | (continuation) | 7 |
| #41 | 2026-02-28 | (verbatim #40) | (continuation) | 8 |
| #42 | 2026-03-04 | (#36 phrasing 3rd) + compact 2-item | NEW post-modifier compact | 9 |
| #43 | 2026-03-07 | (#36 phrasing 4th) + compact 2-item | (continuation) | 10 |
| #44 | 2026-03-08 | "pedagogical and editorial aid" + QFT-verification | NEW QFT-specific scope variant | 11 |
| #45 | 2026-03-11 | "extended series of discussions" + "interactive conversational tool" | NEW dialogue-character variant | 12 |
| #46 | 2026-03-14 | (#36 phrasing 2nd) | (continuation) | 13 |
| #47 | 2026-03-20 | "linguistic polishing and paragraph composition; no conceptual content" | NEW minimal scope | 14 |

### 6.2 Discipline rule

新 paper curate 時、Acknowledgments の AI-collaboration phrasing を identify + lineage 内 position:

```yaml
provenance:
  ai_collaboration_acknowledged: true   # **paper Acknowledgments で explicit articulation**:
                                        # 「<verbatim quote>」
                                        # **Lineage 内 position (HANDOFF v(N) update)**:
                                        # - #9 (2023-04 founding)
                                        # - ...
                                        # - **#XX (date variant description)** ─ NEW phrasing variant 第 N instance
                                        # - ...
                                        # **重要 distinction**: 本 #XX phrasing は previous #YY と異なり...
```

各 paper の lineage entry で:
- 既知 phrasing の継承 (例: #36 phrasing 6th instance) か NEW variant か qualify
- specific compositional features (positive scope items + negative scope items) を articulate
- mixed-form coexistence pattern (readme.txt vs paper-internal) を check

## 7. Modest articulation pool maintenance

### 7.1 累積 candidates の review timing

- 各 transition で新 candidates 追加 → 累積数 update
- 5+ transitions 経過 candidate は sustained worth review 候補
- HANDOFF v(N) の transition narrative で modest articulation pool size を report

### 7.2 Pruning rules

modest articulation pool から remove する条件 (rare):
- candidate が後続 articulation で superseded された場合
- candidate が論理的に not-applicable と判明した場合 (HANDOFF v7.14 'welding-hub' precedent)

User explicit decision 必要 (silent pruning は workspace 質を degrade)。

### 7.3 Promotion candidates surface timing

modest articulation pool から formal taxonomy candidates を identify する review:
- 各 transition で 5+ instances sustained patterns を highlight
- HANDOFF transition narrative で promotion candidate を suggest (User decision 待ち)

## 8. References

- `references/conceptual-moves-taxonomy.md`: Move taxonomy formal addition workflow + Move 9 candidates の modest articulation status
- `references/threads-and-topics.md`: Topic 新設 workflow (HANDOFF v7.17 / v7.18 precedent)
- `references/queries-layer.md`: Query layer での modest articulation discipline (sources.papers update gate)
- `references/frontmatter-schema.md`: predictions status enum 等 validator-enforced fields
