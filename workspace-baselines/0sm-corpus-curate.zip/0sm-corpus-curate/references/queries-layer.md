# Queries Layer

> Skill A の queries layer architecture + q-001 〜 q-004 entries reference。Forward research direction registrations の workspace-internal layer 説明。

---

## 1. Queries layer とは

「Queries layer」 は HANDOFF v7.20 で新設された workspace 内 layer。**forward research direction を formal に register する** mechanism として function。

従来の workspace layers:
- **Master papers** (`context/papers/`): 既 published papers の curate
- **Master topics** (`context/topics/`): topic-level conceptual indexing
- **Conceptual moves** (`context/derived/conceptual-moves.md`): formal Move taxonomy

Queries layer (HANDOFF v7.20 新設):
- **Queries** (`context/queries/`): forward research direction registrations

Master layers は **既存 papers の analysis result** を encode、queries layer は **未来の direction の hypothesis / research programme** を encode。両者は workspace 内 distinct semantic role。

## 2. Queries layer architecture

```
context/queries/
├── README.md                    # queries layer 全体 description
├── q-001-<short-name>.md
├── q-002-<short-name>.md
├── q-003-<short-name>.md
└── q-004-<short-name>.md
```

各 q-XXX file は forward research direction の structured registration。

### Frontmatter schema (q-XXX-*.md)

```yaml
---
id: q-XXX
name: "<short query name>"
date_registered: <YYYY-MM-DD>
status: <"active" / "branched" / "absorbed" / "superseded">

# === Central thesis ===
thesis: "<central question / forward direction articulation>"

# === Sub-aspects ===
sub_aspects:
  - id: "(a)"
    description: "<sub-aspect text>"
  - id: "(b)"
    ...

# === Sources (papers contributing to this query) ===
sources:
  papers: [<int>, <int>, ...]
  rationale: "<why these papers contribute>"

# === Related layers ===
related_threads: [C-X, C-Y, ...]
related_topics: [<topic1>, <topic2>, ...]
related_moves: [<int>, ...]   # Move numbers

# === Forward connections ===
forward_paper_candidates:
  - paper: <int>
    role: "<expected role in query>"

# === Articulation history ===
articulation_history:
  - version: 1
    date: <YYYY-MM-DD>
    note: "<articulation note>"
---

# Query q-XXX: <Full Name>

(body: extended explanation, examples, related context)
```

## 3. Active queries (HANDOFF v7.26 baseline)

### q-001: <名称, HANDOFF v7.20 で initial 登録>

- **Status**: active
- **Date registered**: HANDOFF v7.20 baseline
- **Thesis**: (q-001 の central thesis、HANDOFF v7.20 transition narrative 参照)
- **Sources**: 関連 papers (HANDOFF v7.20 で specified)
- **Related layers**: relevant threads / topics / Moves

### q-002: <名称>

- **Status**: active
- **Date registered**: HANDOFF v7.20 baseline
- (詳細は `context/queries/q-002-*.md` 参照)

### q-003: <名称>

- **Status**: active
- **Date registered**: HANDOFF v7.20 baseline
- (詳細は `context/queries/q-003-*.md` 参照)

### q-004: Phenomenological gauge-relativity unification via line integral

- **Status**: active
- **Date registered**: HANDOFF v7.23 (2026-05-08)
- **Thesis**: 線積分を起点にしてゲージ理論と相対性理論を「現象論的に統一」する frame。**唯一経路 (unique path) commitment** が現象論として確立される vs QM 経路積分 (path integral) の dichotomy が central question。

#### q-004 sub-aspects (HANDOFF v7.23 baseline)

| Sub-aspect | Description |
|---|---|
| (a) | 2 点カーネル (two-point kernel) → Synge's world function 連結 + 計量 framework との関係 |
| (b) | 熱勾配の経路 (thermal gradient path) + ポテンシャル → 運動エネルギー転化 mechanism |
| (c) | スネルの法則 + 唯一経路 phenomenology (snell's law + unique path commitment) |

#### q-004 paper-level execution instances (HANDOFF v7.24-v7.26 baseline)

- **第 1 instance**: **#44** (HANDOFF v7.24, Internal Energy Stabilization, closed-loop case specific articulation)
  - Sec 5 「physically meaningful observables to closed line-integral processes」
  - Sec 6 differential-integral correspondence (Maxwell-equation-form-analog, q-004 sub-aspect 関連)
  - Sec 2 「energy is not a locally stored quantity but a history-dependent transport process」
  - q-004 closed-loop case を specific articulate
  
- **第 2 instance**: **#45** (HANDOFF v7.25, Open-Path Spinorial Transport, open-path explicit treatment + dichotomy clarification)
  - Sec III open-path framework (q-004 line-integral primitive direct extension)
  - Sec V directed-arc-length conjecture (q-004 唯一経路 commitment direct articulation)
  - Sec VI.A spacetime-vs-internal-gauge dichotomy (q-004 phenomenological unification mechanism question)
  - 3-fold direct connection
  
- **第 3 instance candidate**: **#57** (HANDOFF v7.26, Spherical Harmonic Imprinting)
  - Sec on "physical identity of phase information" (Y_ℓ^m imprinting = directed-path framework)
  - q-004 sub-aspect (a) two-point kernel + Synge's world function 関連
  - Status: HANDOFF v7.26 で modest articulation, q-004 sources.papers update pending User explicit gate

#### q-004 sources.papers (現状)

```yaml
sources:
  papers: [5, 11, 18, 23, 24, 26, 29, 30, 31, 32, 34, ...]   # HANDOFF v7.20 initial registration の base
  # v7.24-v7.26 で paper-level execution instances 識別された (#44, #45, #57?) が
  # sources.papers update は User explicit articulation gate 待ち (modest articulation 維持)
```

#### q-004 → master layer workflow

queries layer → master layer の workflow が #44 + #45 で 2 consecutive instances confirmed:

```
[queries layer]                [master layer (papers)]
q-004 (forward direction       paper draft / curate
register, HANDOFF v7.20)  ───→ #44 (Sec 5/6 references q-004 thesis)
                          ───→ #45 (Sec III/V/VI.A direct treatment)
                          ───→ #57 (modest, HANDOFF v7.26)
```

本 workflow は **research direction registration → paper-level execution** という precedent を establish、後続 paper drafting で q-004 (or 他 queries) を context として直接 invoke 可能。

## 4. Queries layer の役割

### 4.1 Author personal-research-assistant role での utility

queries layer は **author の forward research direction の externalized memory** として function:

- author が「線積分から phenomenological unification を構築する」 という方向を発想した時点で q-004 として register
- 後続 paper drafting (#44, #45, #57+) で q-004 を context として直接 invoke
- 各 paper-level execution instance が q-004 thesis を refine + sources.papers を expand

これにより **multi-paper-coordinated forward research programme** が workspace 内 explicit に track される。HANDOFF v7.X transitions で q-004 paper-level executions が cumulative に identify されている。

### 4.2 Skill A での queries layer 取り扱い

Skill A は queries layer に対して以下 operations を行う:

#### 4.2.1 Read-only consultation

- 「q-004 の sources.papers は?」 等 query
- 「最近の paper #57 が q-004 forward research direction connection をもつ?」 等 cross-reference
- HANDOFF.md transition narrative での q-X paper-level execution identification

#### 4.2.2 Modest articulation maintenance

- 新 paper が q-X と structural resonance を持つ場合、modest articulation 段階で series_role に record
- formal sources.papers update は User explicit articulation gate 通過後 triggered (HANDOFF v7.X 範囲では未 trigger)

#### 4.2.3 Branching (rare, User explicit)

- q-X の sub-aspect が独立 query (q-X+1) として branch 価値を持つ場合
- User explicit articulation gate 通過後 triggered

### 4.3 Skill B (Zenodo upload) での queries layer 取り扱い

Skill B は queries layer を direct には touch しないが、以下 indirect 利用:

- zenodo_relations.txt の References (thematic) section で query-related papers を identify する際 query sources.papers を参照
- zenodo_description.html の「Series Context」 部分で programmatic forward direction の言及

## 5. Query layer 新設 workflow (rare)

新 query (q-005+) を register する場合 (HANDOFF v7.20 q-001-003 / v7.23 q-004 precedent):

### Step Q1: User explicit articulation

User が新 forward research direction を articulate (e.g., 「線積分から phenomenological unification を構築する frame を q-004 として register」)。

### Step Q2: q-XXX-*.md 作成

`context/queries/q-XXX-<short-name>.md` を作成、frontmatter (id, name, date, thesis, sub_aspects, sources, related layers, forward candidates, articulation history) を populate。

### Step Q3: HANDOFF transition narrative

v(N+1) HANDOFF transition で query layer addition を記録:
- 新 query identifier + name
- thesis + sub-aspects
- initial sources.papers
- related threads / topics / Moves

### Step Q4: Validators (任意)

queries layer の validation は v7.X 範囲では light (specific validator なし、HANDOFF transition で manual review)。

## 6. q-X branching workflow (rare)

q-X の sub-aspect が独立 query として branch 価値を持つ場合 (HANDOFF v7.X 範囲で precedent なし、design 上の possibility):

### Step B1: Sustained worth identification

q-X sub-aspect が **3+ paper-level execution instances を独自に持つ** + sub-aspect-internal sources.papers が q-X 全体と significantly overlap しない、等の条件。

### Step B2: User explicit articulation gate

User explicit decision で branching 承認。

### Step B3: q-X+M (新 query) creation

q-X sub-aspect content を q-X+M として新 register、q-X 内 sub-aspect は「branched to q-X+M」 status に update。

## 7. Cross-reference query handling (Skill A invocation)

User が queries layer 関連 query を出した場合の handling:

### 7.1 「q-XXX とは?」

```
→ context/queries/q-XXX-*.md の frontmatter + body を read
→ thesis + sub-aspects + sources + related layers を summarize
→ paper-level execution instances (HANDOFF transitions で identify されたもの) を list
```

### 7.2 「q-004 の sources.papers update timing は?」

```
→ HANDOFF.md latest で q-004 paper-level execution instances 累積数 確認
→ 現状 (HANDOFF v7.26) #44 + #45 + #57? = 2-3 instances modest articulation
→ formal sources.papers update は User explicit articulation gate 待ち status であることを report
```

### 7.3 「#XX が invoke する queries は?」

```
→ context/papers/0XX.md の series_role / body content で q-X references を grep
→ q-X paper-level execution instance としての position を answer
```

### 7.4 「新 query として branch 候補は?」

```
→ HANDOFF.md latest + q-X sub_aspects review
→ sub-aspect 単独で 3+ paper-level execution instances を持つもの identify
→ branch 候補 suggest (formal branching は User decision)
```

## 8. Queries layer maturation roadmap

queries layer は HANDOFF v7.20 新設後 v7.26 baseline で 4 entries に成長。後続 maturation の possible directions:

### 8.1 q-001-003 paper-level execution tracking

q-001 / q-002 / q-003 の paper-level execution instances を q-004 と同様に systematic に identify + sources.papers update。

### 8.2 q-004 sources.papers formal expansion

User explicit articulation gate 通過時、modest articulation 段階の paper-level execution instances (#44, #45, #57?) を formal sources.papers に absorb。

### 8.3 q-005+ 新 query addition

新 forward research direction が surface した場合、q-005 として register。HANDOFF v7.X 範囲では candidate なし。

### 8.4 Cross-query connections

複数 queries 間の relationship を articulate (例: q-004 が q-001 sub-aspect を more specific に articulate する関係 等)。HANDOFF v7.X 範囲では未 articulation。

## 9. References

- `references/threads-and-topics.md`: queries が related threads + topics を declare する関係
- `references/conceptual-moves-taxonomy.md`: queries が related Moves を declare する関係 (e.g., q-004 が Move 8 epistemic を関連)
- `references/curatorial-disciplines.md`: queries layer での modest articulation discipline (sources.papers update gate)
