# 0SM Paper Frontmatter Schema (papers/0XX.md)

> Skill A の papers/0XX.md frontmatter YAML schema 完全仕様。`scripts/validate_frontmatter.py` が enforce する schema。

---

## 1. File location and naming

- Path: `context/papers/NNN.md` (NNN = 3-digit zero-padded, e.g., `001.md`, `045.md`, `057.md`)
- Permanent gap: `#16` は欠番 (paper number 16 は使用しない、HANDOFF 既決定)

## 2. Top-level structure

```yaml
---
# === 識別情報 ===
number: <int>
title: "<string>"
date: <YYYY-MM-DD or YYYY-MM>
doi: <string, e.g., "10.5281/zenodo.NNNNNNNN">

# === 型分類 ===
type: <enum>
subtype: <enum or null>
is_foundational: <bool>

# === 関係グラフ ===
relation:
  companion_to: <int or null>
  supplements: <[int, ...] or null>
  corrects: <int or null>
  continues: <[int, ...] or null>
  requires: <[int, ...] or null>
  references: <[int, ...] or null>

# === 由来情報 ===
provenance:
  vixra_id: <string or null>
  vixra_archived: <bool>
  series_role: "<long string, comprehensive curatorial commentary>"
  ai_collaboration_acknowledged: <bool>
  update_history:
    - version: <int>
      date: <YYYY-MM-DD>
      session: "<string>"
      action: "<long string, narrative>"

# === スレッド帰属 ===
threads:
  - C-<int>     # <thread description, central / substantive / peripheral>

# === 呼び出される topics ===
topics_invoked:
  - <topic-name>     # <central / substantive / peripheral, with rationale>

# === 初出メタデータ ===
analogies_first:
  - name: "<string>"
    note: "<long string, explanation>"

equations_first:
  - "<equation in Unicode + brief context>"

concepts_first:
  - "<concept articulation>"

# === タスク管理 ===
opens_tasks:
  - id: "<string, e.g., 'i', 'A', 'task-01'>"
    description: "<string>"
    status: "<string>"

closes_tasks:
  - paper: <int>
    task_id: "<string>"
    note: "<string, optional>"

corrections_made: <[ ... ] or []>

# === 実験予測 ===
predictions:
  - claim: "<string>"
    status: <enum: "unmeasured" | "partial" | "confirmed" | "refuted" | "open" | "technically-difficult">

# === Body sections (frontmatter 外) ===
---

# Paper #NNN: <Title>

(curatorial commentary, body content)
```

## 3. Field-by-field specification

### 3.1 識別情報 (Identification)

| Field | Type | Required | Description |
|---|---|---|---|
| `number` | int | YES | Paper number (1-99 within current scope) |
| `title` | string | YES | Full paper title (subtitle included if present) |
| `date` | string | YES | Publication date (YYYY-MM-DD or YYYY-MM if day uncertain) |
| `doi` | string | YES | Zenodo DOI (10.5281/zenodo.NNNNNNNN format) |

### 3.2 型分類 (Type classification)

| Field | Type | Required | Values |
|---|---|---|---|
| `type` | string | YES | `research` / `supplement` / `clarification` / `correction` |
| `subtype` | string or null | YES | `null` / `conceptual` / `structural` / `conceptual-and-mathematical` / `conceptual-bridge` / その他 |
| `is_foundational` | bool | YES | true (Foundational set) / false (most papers) |

#### type 判断 criteria

- `research`: stand-alone primary research paper (default)
- `supplement`: explicitly framed as Supplement (subtitle / abstract で declaration)
- `clarification`: explicit Clarification character (subtitle "(Structural Clarification Note)" #45 precedent)
- `correction`: numerical / dimensional correction paper (rare, #28 precedent)

#### subtype 判断 criteria

- `null`: research papers (default, subtype 不要)
- `conceptual`: conceptual articulation focus (no new mathematics)
- `structural`: structural argument focus (#42 precedent)
- `conceptual-and-mathematical`: conceptual + substantial mathematics (#35 precedent)
- `conceptual-bridge`: bridge between formalisms

#### is_foundational 判断 criteria

- `true`: Foundational set 入り = paper が series の foundational concepts を establish
- 現 Foundational set: #1 (Two Perfect Black Bodies), #29-#31 (Trilogy), 一部選定基準
- 多くの supplement / clarification papers は `false`

### 3.3 関係グラフ (Relation graph)

| Field | Type | Description |
|---|---|---|
| `companion_to` | int or null | Direct companion pair partner (#36/#42 v7.18 precedent / #40/#41 v7.17 precedent) |
| `supplements` | [int, ...] or null | zenodo_relations [2] Is supplement to declaration |
| `corrects` | int or null | numerical correction target paper (#28 precedent) |
| `continues` | [int, ...] or null | zenodo_relations [3] Continues declaration |
| `requires` | [int, ...] or null | zenodo_relations [5] Requires declaration |
| `references` | [int, ...] or null | bibitem cite Hanamura papers minus (supplements / continues / requires) + zenodo_relations [4] References thematic |

#### Relation field mapping (zenodo_relations.txt → frontmatter)

```
[1] Cites           → 全 bibitem cite を統合的に capture (supplements + continues + requires + references の和集合)
[2] Is supplement to → relation.supplements
[3] Continues       → relation.continues
[4] References (thematic) → relation.references (Hanamura papers のみ、+ bibitem cite minus 他 categories)
[5] Requires        → relation.requires
[6] Is part of      → workspace schema gap (HANDOFF v7.26 NEW pattern (d))
                       → continues / requires で indirect capture、または別途記録
```

#### Multi-relation single target pattern

同 target paper が複数 relation field に登場するのは **支持される** pattern:
- v7.25 #45 dual-relation: #40 ∈ supplements + continues
- v7.26 #57 quadruple-relation (Zenodo level): #56 ∈ Cites + Continues + Is part of + Requires (workspace 内では continues + requires)

#### references field rule (重要)

bibitem cite される Hanamura paper のうち:
1. supplements に既出 → references に**含めない**
2. continues に既出 → references に**含めない**
3. requires に既出 → references に**含めない**
4. 上記いずれにも含まれない bibitem cite → **references に含める**
5. zenodo_relations [4] References (thematic, bibitem cite なし) → **references に含める**
6. forward references (publication date が paper 自身より後の bibitem cite) → **references に含める** (#57 → #58/#59/#60 case)

### 3.4 由来情報 (Provenance)

| Field | Type | Required | Description |
|---|---|---|---|
| `vixra_id` | string or null | YES | viXra archive ID (旧 papers のみ、新 papers は null) |
| `vixra_archived` | bool | YES | viXra archive 利用有無 |
| `series_role` | string | NO (推奨) | Comprehensive curatorial commentary (paper の series 内 position + specific roles + NEW patterns articulated) |
| `ai_collaboration_acknowledged` | bool | NO (推奨) | paper Acknowledgments の AI-collaboration 言及有無 |
| `update_history` | list | NO (推奨) | version history (preliminary → formal sync 等) |

#### update_history entry structure

```yaml
update_history:
  - version: 1
    date: <YYYY-MM-DD>
    session: "<HANDOFF version transition / session description>"
    action: "<comprehensive narrative of what was done>"
  - version: 2
    date: <YYYY-MM-DD>
    session: "<...>"
    action: "<...>"
```

### 3.5 スレッド帰属 (Threads)

```yaml
threads:
  - C-<int>     # <description with central / substantive / peripheral indication>
```

各 thread invocation の strength を comment に明記:
- **central**: paper の central thesis に直接関与
- **substantive**: paper 内 substantial 議論で invoke
- **peripheral**: 軽い言及のみ

詳細 thread enumeration は `references/threads-and-topics.md` 参照。

### 3.6 呼び出される topics (Topics invoked)

```yaml
topics_invoked:
  - <topic-name>     # <central / substantive / peripheral, rationale>
```

各 topic invocation も strength を明記。`context/topics/[topic-name]/` directory が存在する topic のみ invoke 可能。

詳細 topic enumeration は `references/threads-and-topics.md` 参照。

### 3.7 初出メタデータ (Initial occurrence metadata)

#### analogies_first

```yaml
analogies_first:
  - name: "<short analogy name>"
    note: "<extended explanation, シリーズ initial articulation の curatorial significance>"
```

#### equations_first

```yaml
equations_first:
  - "<equation in Unicode + brief context + シリーズ initial articulation note>"
```

equations は Unicode 表記 (例: `cos⁴(θ/2) + sin⁴(θ/2) + (1/2)sin²θ = 1`)。

#### concepts_first

```yaml
concepts_first:
  - "<concept articulation, paper-internal section reference, curatorial significance>"
```

各 entry は markdown bold で central concept 強調が許容 (例: `**∂D as causal boundary in geometric sense (Sec 2)**: ...`)。

### 3.8 タスク管理 (Task management)

#### opens_tasks

```yaml
opens_tasks:
  - id: "<string, free-form>"
    description: "<task description>"
    status: "<status string>"
```

`id` は free-form (例: "i", "A", "task-01", "iv")、paper 内 unique であること。

#### closes_tasks

```yaml
closes_tasks:
  - paper: <int, target paper number>
    task_id: "<target paper の opens_tasks id>"
    note: "<optional explanatory note>"
```

#### corrections_made

```yaml
corrections_made: []   # most papers は empty
# OR
corrections_made:
  - target: <paper number>
    corrected_value: "<value>"
    correction_rationale: "<string>"
```

### 3.9 実験予測 (Predictions)

```yaml
predictions:
  - claim: "<prediction text>"
    status: <enum>
```

`status` は **必須 fixed enum** (validator が enforce):
- `unmeasured`: 予測されているが測定試行なし
- `partial`: partial measurement (一部 confirmed)
- `confirmed`: experimentally confirmed
- `refuted`: experimentally refuted
- `open`: framework-level claim、specific empirical signature 未提示
- `technically-difficult`: 原理的に測定可能だが実用 difficult

**注意**: HANDOFF v7.24 で `structural` status を v7.25 #44 で initial draft で発生 → `open` に correct。`structural` は schema 外。

## 4. Validator enforcement

### 4.1 `scripts/validate_frontmatter.py`

以下を check:
- YAML parsing success (quote balance, indentation 等)
- Required fields presence: `number`, `title`, `date`, `doi`, `type`
- Top-level fields の type compliance
- `topics_invoked` で declare された topic directory が `context/topics/` に存在
- `predictions[].status` が `VALID_PREDICTION_STATUS` set 内
- topic frontmatter (別 schema) の applies_to / status 整合性
- topic file の `applies_to` で reference される paper number が `context/papers/` に存在

### 4.2 `scripts/validate_conceptual_moves.py`

以下を check:
- `context/derived/conceptual-moves.md` 内 paper references が curated set 内
- forward-dangling references (curate されていない paper への reference) なし

## 5. Common pitfalls (HANDOFF history より)

### 5.1 YAML quote balance (HANDOFF v7.26 precedent)

長い quoted string (series_role 等) で **closing `"` 欠落** が発生しやすい。`str_replace` で部分編集する際、最後の `。"` を確実に保つ。

### 5.2 `predictions[].status` 不正値

draft 段階で `structural` 等 schema 外の status が紛れ込みやすい。VALID_PREDICTION_STATUS set 厳守。framework-level claim には `open` を使用。

### 5.3 Forward reference dangling

#57 で #58/#59/#60 を references field に登録すると、#58/#59/#60 が curate されていない場合 dangling refs エラー。新 paper curate 時は forward references の curated 状態確認。

### 5.4 Topic applies_to numerical order

`applies_to: [17, 23, 29, 30, 31, 32, ...]` は **numerical ascending** で挿入。挿入位置間違いは validator では検出されないが、可読性 + 一貫性のため discipline 維持。

### 5.5 Type/subtype combination

- `type: research` + `subtype: null` (most cases)
- `type: supplement` + `subtype: conceptual` (#43, #44 precedent)
- `type: supplement` + `subtype: structural` (#42 precedent)
- `type: clarification` + `subtype: conceptual` (#45, #46 precedent)
- `type: correction` + `subtype: null` (#28 precedent)

`subtype` を populate する場合は judgment criteria を frontmatter コメントに記述。

## 6. Field interaction notes

### 6.1 supplements vs continues

両者は **distinct relation roles**:
- `supplements`: thematic-extension role (本論文が他論文の analysis を extend)
- `continues`: sequential-continuation role (本論文が他論文の next-question を articulate)

同 target paper が両 fields に登場する dual-relation は支持される (v7.25 / v7.26 precedent)。

### 6.2 requires vs references

- `requires`: 本論文の理解に必須の prerequisite paper
- `references`: bibitem cite だが必須 prerequisite ではない paper / thematic-only reference

### 6.3 series_role vs body content

- `series_role`: frontmatter 内 comprehensive commentary (curatorial signal)
- body content: frontmatter 後の `## Curatorial summary` 等 markdown sections

両者は overlap 許容、role 分担は:
- series_role: machine-readable curatorial metadata + dense pattern articulation
- body content: human-readable curatorial summary + worked-example documentation
