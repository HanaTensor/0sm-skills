# Threads and Topics Enumeration

> Skill A の thread (C-X) + topic enumeration reference。Active threads (#X concept threads) + 19 topics (各 1-2 layer files) の comprehensive listing。

---

## 1. Threads とは

「Thread」 は 0-Sphere Model paper series 全体で **継続的に invoke される concept lineage**。各 thread は:

- **Identifier**: C-N (N = 1, 2, 3, ...)
- **Founder paper(s)**: thread が initial articulate された paper
- **Continuation papers**: thread を invoke する後続 papers
- **Description**: thread の central thesis

Threads は paper-level conceptual continuity の lineage tracker として function。Thread invocation は **central / substantive / peripheral** の strength で qualify される。

## 2. Active threads enumeration (HANDOFF v7.26 baseline)

`context/derived/threads.md` は v7.X 範囲で stub 状態 (formal taxonomy 整備は SKILL.md production phase で treat 候補)。以下は HANDOFF transitions + frontmatter declarations から identify される active threads。

### C-1: スピン理論 (Spin Theory)

- **Founder papers**: #1 (Two Perfect Black Bodies foundational), #10 (Redefining Electron Spin and AMM), #13 (Unified Spin Dynamics)
- **Description**: SU(2) spin structure / 4π periodicity / Thomas precession / spin-1/2 character の 0-Sphere Model 内 articulation
- **Recent invocations**: #38 (Two-Kernel SU(2) structure), #45 (Open-Path Spinorial Transport, central)
- **Connected topics**: spin (0sm + textbook layers)

### C-3: 線積分存在論 (Line-Integral Ontology)

- **Founder paper**: #29 (Trilogy I, Spinorial Phase Accumulation along Thermal Geodesics)
- **Description**: 物理 observable を line integral として primary に扱う ontology programme。Move 1 と直接 paired。
- **Continuation papers**: #30 (Trilogy II), #31 (Trilogy III), #32 (vacuum dissolution), #34, #37 (mgh as line-integral), #40 (derivative-order-mismatch), #41 (historical supplement), #42, #43, #44 (closed-loop ontology), #45 (open-path framework, substantive), #51-#57, #59, #60
- **Recent invocations**: #57 (Y_ℓ^m imprinting line-integral microscopic mechanism)
- **Connected topics**: line-integrals (両 layers, 28 papers applies_to)

### C-5: 重力機構 (Gravity Mechanism)

- **Founder papers**: #22 (Gravitational Redshift), #34 (Geometrical Confinement: Emergent Gravitational Dynamics)
- **Description**: 重力 phenomenology の 0-Sphere model 内 mechanism articulation。photon-mediated synchronization / gravitational redshift of internal clocks / mgh as line-integral / Y_ℓ^m imprinting microscopic mechanism。
- **Continuation papers**: #28 (Dimensional Consistency), #37 (mgh), #49 (Photon-Sphere Fragmentation), #52 (λ_C cancellation), #57-#60 (sequence)
- **Connected topics**: gravity-mediation (0sm)

### C-13: Wilson line 存在論 (Wilson Line Ontology)

- **Founder paper**: #55 (Four Functions of the Open Wilson Line)
- **Description**: Open Wilson line を primary observable として treat、four-function decomposition (phase-history carrier, gauge localization, holonomy composition, boundary data with dual-sector derivation)。Wilson lines as ontological primitives。
- **Continuation papers**: #56 (Framework Boundary), #57 (Y_ℓ^m imprinting realizes Function 4)
- **Connected topics**: line-integrals, gauge-theory

### C-15: 重力結合微視機構 (Microscopic Mechanism of Gravitational Coupling)

- **Founder paper**: #57 (Spherical Harmonic Imprinting)
- **Description**: 重力結合の microscopic mechanism として Y_ℓ^m imprinting at photon-sphere ejection site (θ=π/2)、5-paper coordinated release sequence #57-#60 (#61 application paper) の central thread。
- **Continuation papers**: #58 (Spin-2 Structure), #59 (Bound-State Condition), #60 (Berry-Synge-Bonnet-Myers Triangle), #61 (application)
- **Status**: HANDOFF v7.26 で 第 1 instance articulation, formal threads.md entry pending
- **Connected topics**: gravity-mediation, line-integrals, thermal-geodesic

### C-21: Noetherian Inversion

- **Founder paper**: #17 (From Clock Synchronization to Electromagnetism: U(1) Gauge)
- **Description**: 通常の Noether's theorem (symmetry → conservation law) 方向を inverse して、conservation law を ontological primary とし symmetry を derived に置く reverse-direction approach。
- **Continuation papers**: #54 (Maxwell electrodynamics derived limit)
- **Connected topics**: gauge-theory

### C-22: ZB radiative dynamics (Zitterbewegung Radiative Dynamics)

- **Founder papers**: #11, #33 (Geometrical Confinement: Rest Mass and ZB)
- **Description**: Zitterbewegung velocity v_ZB ≈ 0.04c の radiative dynamics 機構 + photon-sphere oscillation between kernels A and B + Thomas precession spin connection 起源。
- **Continuation papers**: 多数 (#3, #8, #10-#15, #20-#27, #34, #35, #38, #42-#47 applies_to zitterbewegung topic)
- **Connected topics**: zitterbewegung (0sm, 26 papers applies_to)

### C-26: Einstein equation as global checksum / vacuum dissolution

- **Founder paper**: #32 (Dissolution of the Vacuum Energy Problem)
- **Description**: Einstein equation を a posteriori consistency condition として treat、vacuum energy problem を line-integral ontology で dissolve (closed gauge-like internal circulations は non-radiating + non-gravitating)。
- **Continuation papers**: #30 v2 (From Curvature to Connection v2), #36 (non-perturbative scope), #39 (logical status of Λ), #44 (closed-loop ontology vacuum extension)
- **Connected topics**: emergent-spacetime, gauge-theory

### C-29: Berry phase / Geometric phase / Holonomy

- **Founder papers**: #26 (Spin from Geometry: Internal Berry Phase)
- **Description**: SU(2) holonomy / Berry phase / Wilson loop / open-path transport / geometric phase の broader thread。
- **Continuation papers**: #29, #31, #33, #39, #43, #45 (central), #57+
- **Connected topics**: berry-phases (両 layers), gauge-theory

### Other threads (modest articulation, partial enumeration)

- **C-2** (?): 熱力学 thread (entropic-action ontology)
- **C-4** (?): emergent spacetime thread
- **C-6** (?): topology thread (manifold + bundle structure)
- **C-7-C-12** (?): various intermediate threads (HANDOFF v7.X 範囲では partial enumeration)
- **C-14** (?): proton structure thread (#20 founder)
- **C-16-C-20**, **C-23-C-25**, **C-27, C-28**, **C-30+**: 未 formal enumeration (formal threads.md 整備 pending)

**注**: 完全 thread enumeration は `context/derived/threads.md` formal articulation phase で treat 候補。現 v7.X 範囲では各 paper の frontmatter `threads:` field declarations + HANDOFF transitions が primary truth source。

## 3. Topics enumeration (19 topics, 30 layer files)

`context/topics/` 配下の各 directory が 1 topic を represent。各 topic は **2 layer files** を持つ場合がある:

- `0sm.md`: 0-Sphere Model perspective (本 series 内 articulation)
- `textbook.md`: textbook / classical perspective (任意、broader physics context)

### 3.1 Active topics list (HANDOFF v7.26 baseline)

| Topic | Directory | 0sm layer | Textbook layer |
|---|---|---|---|
| line-integrals | `context/topics/line-integrals/` | ✓ (28 papers applies_to) | ✓ (18 papers) |
| thermal-geodesic | `context/topics/thermal-geodesic/` | ✓ (17 papers) | (なし) |
| zitterbewegung | `context/topics/zitterbewegung/` | ✓ (26 papers) | (なし) |
| thermodynamics | `context/topics/thermodynamics/` | ✓ | (なし) |
| topology | `context/topics/topology/` | ✓ (10 papers) | ✓ (7 papers) |
| gauge-theory | `context/topics/gauge-theory/` | ✓ (24 papers) | ✓ (12 papers) |
| gravity-mediation | `context/topics/gravity-mediation/` | ✓ | (なし) |
| emergent-spacetime | `context/topics/emergent-spacetime/` | ✓ (18 papers) | (なし) |
| spin | `context/topics/spin/` | ✓ (33 papers) | ✓ (1 paper) |
| berry-phases | `context/topics/berry-phases/` | ✓ (7 papers) | ✓ (3 papers) |
| compton-scale-geometry | `context/topics/compton-scale-geometry/` | ✓ (19 papers) | (なし) |
| derivative-order-mismatch | `context/topics/derivative-order-mismatch/` | ✓ (4 papers) | ✓ (4 papers) |
| monopole | `context/topics/monopole/` | ✓ | (なし) |
| (他 6 topics) | (各 directory) | (各 layer) | |

**Note**: 上 listing は v7.26 baseline での主要 topics + applies_to 数 (一部抜粋)。完全 listing は `ls context/topics/` で確認。

### 3.2 Topic file frontmatter schema

各 topic file (`0sm.md` または `textbook.md`) は以下 frontmatter を持つ:

```yaml
---
topic: <topic-name>
layer: <"0sm" or "textbook">
status: <"established" or "draft" or "stub">
applies_to: [int, int, ...]
---

(body content with topic-level explanatory material)
```

| Field | Type | Required | Description |
|---|---|---|---|
| `topic` | string | YES | topic name (directory name と一致) |
| `layer` | string | YES | "0sm" / "textbook" |
| `status` | string | YES | "established" / "draft" / "stub" |
| `applies_to` | [int, ...] | YES | invoke する paper number list (numerical ascending order) |

### 3.3 Topic invocation strength

paper の frontmatter `topics_invoked:` で各 topic を invoke する際の strength:

- **central**: paper の central thesis に topic 概念が central に invoke される (例: #45 で gauge-theory + topology + spin が central)
- **substantive**: paper 内 substantial 議論で invoke (例: #45 で line-integrals + thermal-geodesic 等が substantive)
- **peripheral**: 軽い言及 / brief reference のみ (例: #45 で compton-scale-geometry が peripheral)

各 paper frontmatter の comment で strength を qualify:

```yaml
topics_invoked:
  - gauge-theory          # central — paper-internal central question 「Spacetime vs Internal Gauge Connection Dichotomy」
  - topology              # central — Cartan torsion two-form central object
  - line-integrals        # substantive — Sec III + V + VI で line-integral framework central tool
  - compton-scale-geometry # peripheral — Sec VI.A での brief mention のみ
```

### 3.4 Topic 新設 workflow (rare, User explicit articulation gate)

新 topic 追加は HANDOFF v7.17 (derivative-order-mismatch v7.17, monopole v7.18) precedent に従う:

#### Step T1: Sustained worth identification

- 既存 topics で fit しない specific concept thread が **3+ papers across multiple HANDOFF transitions** で repeatedly invoke される
- User explicit articulation gate (e.g., 「derivative-order-mismatch を topic として新設」)

#### Step T2: Directory + layer file creation

```bash
mkdir -p context/topics/<new-topic>
```

`0sm.md` (必須) + `textbook.md` (任意) を作成、frontmatter + body content を populate。

#### Step T3: Update applies_to in 全 relevant papers

各 invocation paper の frontmatter `topics_invoked:` field に新 topic を追加 + 新 topic file の `applies_to:` に paper number を numerical order 挿入。

#### Step T4: Validators + HANDOFF update

`validate_frontmatter.py` で 0-error 確認 + HANDOFF v(N+1) で topic 新設 narrative。

## 4. Cross-reference query handling

### 4.1 「Topic X に invoke する papers は?」

```
→ context/topics/X/0sm.md の applies_to を参照 (and textbook.md if exists)
→ paper number list を answer
→ 必要に応じて各 paper frontmatter で central / substantive / peripheral strength を qualify
```

### 4.2 「Thread C-X の continuation papers は?」

```
→ HANDOFF.md latest で C-X thread の active continuations を grep
→ 各 paper frontmatter `threads:` field の declaration で確認
→ Founder paper + continuation papers list を answer
```

### 4.3 「#XX はどの topics / threads を invoke?」

```
→ context/papers/0XX.md の topics_invoked + threads field 参照
→ 各 invocation の strength qualification を answer
```

### 4.4 「新 topic として追加候補は?」

```
→ HANDOFF.md latest で recent papers の topics_invoked 検査
→ 既存 topics に fit しない specific concept threads を identify
→ sustained worth criteria (3+ papers, multiple transitions) で filter
→ 候補 suggest (formal addition は User decision)
```

## 5. Topic vs Thread distinction

両者は overlap するが distinct curatorial constructs:

| | Topic | Thread |
|---|---|---|
| **Granularity** | broader concept area | specific concept lineage |
| **Layered structure** | 2 layers (0sm + textbook) | 1 dimension |
| **Cross-reference** | applies_to (paper list) | continuation chain |
| **Identifier** | name (line-integrals 等) | C-N number |
| **File** | `context/topics/<name>/[0sm or textbook].md` | (formal `derived/threads.md` pending) |
| **Use** | "broad concept area の applies_to lookup" | "specific lineage の trace" |

例: 「line-integrals」 は topic (broad area, 0sm + textbook layers, 28 papers applies_to)、一方「C-3 線積分存在論」 は thread (#29 founder からの specific lineage、Move 1 paired)。両者 conceptually 重なるが、topic は broad area indexing、thread は specific lineage tracing として役割分担。

## 6. References

- `references/conceptual-moves-taxonomy.md`: Moves と threads の関係 (Move carrier papers が thread を共有することがある)
- `references/queries-layer.md`: queries が threads / topics を invoke する仕組み
- `references/workspace-architecture.md`: `context/topics/` directory の物理 layout
