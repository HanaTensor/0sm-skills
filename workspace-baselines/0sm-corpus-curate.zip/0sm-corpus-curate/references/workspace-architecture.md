# Workspace Architecture

> Skill A の workspace file system layout + scripts + validator usage の comprehensive reference。`context/`, `scripts/`, `HANDOFF.md`, derived files の物理 architecture。

---

## 1. Top-level layout

```
0sm-corpus-workspace/
├── HANDOFF.md                  # Master state document, transition narratives
├── README.md                   # (任意) workspace overall description
├── context/                    # Master content
│   ├── papers/                 # Paper frontmatter files
│   ├── topics/                 # Topic indexing
│   ├── queries/                # Forward research direction registrations
│   └── derived/                # Auto-generated (manual edit 禁止)
└── scripts/                    # Validators + builders
```

`HANDOFF.md` は **必ず最初に読む** master state document。Validator state + 累積 modest articulation candidates + recent transitions narrative + active curatorial framing が含まれる。

## 2. `context/papers/` (Master papers)

### 2.1 File layout

```
context/papers/
├── 001.md                      # Paper #1 frontmatter
├── 002.md                      # Paper #2 frontmatter
├── ...
├── 015.md                      # Paper #15 (#16 は permanent gap, 欠番)
├── 017.md                      # Paper #17 frontmatter
├── ...
└── 061.md                      # Paper #61 (HANDOFF v7.26 baseline で latest)
```

**File naming**: `NNN.md` (3-digit zero-padded paper number)

**Permanent gap**: `#16` は使用しない paper number (HANDOFF 既決定)。`016.md` は存在せず、validator で missing 扱いされない。

### 2.2 Paper count by HANDOFF transition

| HANDOFF version | Paper count | Latest paper |
|---|---|---|
| v7.20 baseline | 56 | #43 |
| v7.21 (DOI audit) | 56 | (no paper change) |
| v7.22 (Move 8 formal addition) | 56 | (no paper change) |
| v7.23 (q-004 registration) | 56 | (no paper change) |
| v7.24 (#44 curate) | 57 | #44 (但し WIP curated #57-#61 既存) |
| v7.25 (#45 curate) | 60 | #45 + WIP #46-#61 |
| v7.26 (#57 relations refinement) | 60 | (no paper count change) |

**注**: WIP-curated papers (#46-#61) は v7.X earlier sessions で frontmatter 既存だが、formal data sync は v7.X transitions で逐次実施。HANDOFF v7.26 baseline で 60 papers 全 frontmatter 存在 + #57 が formal sync 完了。

### 2.3 Operations on papers/

#### 2.3.1 Read existing paper

```python
import yaml, re
with open('context/papers/045.md') as f:
    content = f.read()
match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
fm = yaml.safe_load(match.group(1))
# fm.relation.supplements, fm.topics_invoked, etc.
```

#### 2.3.2 Create new paper (Skill A workflow Step 9)

```bash
# Use create_file tool with comprehensive frontmatter content
# Refer to references/frontmatter-schema.md for schema specification
```

#### 2.3.3 Update existing paper (relations refinement, Skill A workflow Step R3)

```bash
# Use str_replace tool for targeted edits
# Avoid full file rewrite (preserves existing analytical content)
```

#### 2.3.4 List all papers with summary

```bash
ls context/papers/*.md | wc -l            # Total paper count
grep -h "^number:" context/papers/*.md    # All paper numbers
grep -h "^title:" context/papers/*.md     # All titles
```

## 3. `context/topics/` (Master topics)

### 3.1 Directory structure

```
context/topics/
├── line-integrals/
│   ├── 0sm.md                  # 0-Sphere Model perspective
│   └── textbook.md             # Textbook / classical perspective (任意)
├── thermal-geodesic/
│   └── 0sm.md
├── zitterbewegung/
│   └── 0sm.md
├── gauge-theory/
│   ├── 0sm.md
│   └── textbook.md
├── topology/
│   ├── 0sm.md
│   └── textbook.md
├── spin/
│   ├── 0sm.md
│   └── textbook.md
├── derivative-order-mismatch/
│   ├── 0sm.md
│   └── textbook.md
├── monopole/
│   └── 0sm.md
├── (他 11 topics)
```

Total: **19 directories**, **30 layer files** (一部 topics は textbook layer 持ち)。

### 3.2 Topic file structure

各 topic file (`0sm.md` または `textbook.md`) frontmatter:

```yaml
---
topic: <topic-name>
layer: <"0sm" or "textbook">
status: <"established" / "draft" / "stub">
applies_to: [int, int, ...]
---

# <Topic Title>

(body content with topic-level explanatory material, layered perspective)
```

### 3.3 `applies_to` discipline

- **Numerical ascending order** で paper numbers 列挙
- 新 paper curate 時、対応する topic file の `applies_to` field に paper number を **挿入位置で sorted insert**
- validator (`validate_frontmatter.py`) は `applies_to` の paper numbers が `context/papers/` に存在することを check

```yaml
# Before (新 paper #45 invoke 前):
applies_to: [26, 29, 33, 38, 39, 41, 42, 43, 44]

# After (新 paper #45 invoke 後, numerical order 維持):
applies_to: [26, 29, 33, 38, 39, 41, 42, 43, 44, 45]
```

### 3.4 Topic 新設 (rare, User explicit articulation gate)

HANDOFF v7.17 (derivative-order-mismatch), v7.18 (monopole) precedent。詳細は `references/threads-and-topics.md` Section 3.4 参照。

## 4. `context/queries/` (Forward research directions)

### 4.1 Directory structure

```
context/queries/
├── README.md                   # Queries layer overall description
├── q-001-<short-name>.md
├── q-002-<short-name>.md
├── q-003-<short-name>.md
└── q-004-phenomenological-gauge-relativity-unification.md
```

**File naming**: `q-XXX-<short-descriptive-name>.md` (3-digit zero-padded query number)

### 4.2 Queries count by HANDOFF transition

| HANDOFF version | Queries count |
|---|---|
| v7.19 (queries layer 新設前) | 0 |
| v7.20 (initial creation) | 3 (q-001, q-002, q-003) |
| v7.23 (q-004 registration) | 4 |
| v7.24-v7.26 baseline | 4 |

詳細は `references/queries-layer.md` 参照。

## 5. `context/derived/` (Auto-generated)

### 5.1 File layout

```
context/derived/
├── conceptual-moves.md         # 8 active Move entries + Move 9 candidates
├── index.md                    # 全 papers index (number, date, title, type, DOI)
├── analogies.md                # analogies_first 集約 (時系列)
├── equations.md                # equations_first 集約 (時系列)
├── first-occurrences.md        # concepts_first 集約 (時系列)
├── predictions.md              # predictions 集約 (時系列)
├── corrections.md              # corrections_made 集約 (時系列)
└── open-questions.md           # opens_tasks / closes_tasks 集約
```

**重要**: `derived/` files は **manual edit 禁止**。`scripts/` の builders で auto-generate される。Manual edit すると次回 build で上書きされる。

例外: `conceptual-moves.md` は manual + auto の hybrid (Move entries は manual、paper references は validator で check されるが build script なし)。

### 5.2 Regeneration commands (Skill A workflow Step 12)

```bash
python3 scripts/build_index.py
python3 scripts/build_aggregate.py --input context/papers --field analogies_first --output context/derived/analogies.md --title "アナロジー初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field equations_first --output context/derived/equations.md --title "方程式初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field first_occurrences --output context/derived/first-occurrences.md --title "シリーズ初出 articulations 索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field predictions --output context/derived/predictions.md --title "実験予測索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field corrections_made --output context/derived/corrections.md --title "訂正履歴索引（時系列）"
python3 scripts/build_open_questions.py
```

各 command:
- `build_index.py`: `papers/*.md` から index.md を generate (paper number, date, title, type, DOI link)
- `build_aggregate.py --field <field>`: 全 papers の指定 field を時系列 aggregate
- `build_open_questions.py`: opens_tasks (未 closed) + closes_tasks の cross-reference を generate

### 5.3 Manual edit が必要な derived files

- `context/derived/conceptual-moves.md`: Move taxonomy formal additions は manual edit (例: HANDOFF v7.13 Move 7 / v7.22 Move 8 addition)
- `context/derived/threads.md`: 現状 stub、formal articulation phase で manual addition

## 6. `scripts/` (Validators + Builders)

### 6.1 File layout

```
scripts/
├── validate_frontmatter.py        # 必須 (curate 後)
├── validate_conceptual_moves.py   # 必須 (Move references resolve check)
├── build_index.py
├── build_aggregate.py
└── build_open_questions.py
```

### 6.2 `validate_frontmatter.py` 詳細

#### Checks performed

1. **YAML parsing**: 各 paper file の frontmatter が valid YAML として parse 可能か
2. **Required fields**: `number`, `title`, `date`, `doi`, `type` が存在するか
3. **Type enum**: `type` が valid set 内 (`research`, `supplement`, `clarification`, `correction`)
4. **predictions status enum**: `predictions[].status` が VALID_PREDICTION_STATUS = `{"unmeasured", "partial", "confirmed", "refuted", "open", "technically-difficult"}` 内
5. **topics_invoked existence**: 各 invoke topic の directory が `context/topics/` に存在
6. **Topic frontmatter validity**: 各 topic file (`0sm.md`, `textbook.md`) frontmatter
7. **Topic applies_to references**: topic の applies_to で参照される paper numbers が curated set 内

#### Expected output (all-clear)

```
OK: 60 paper(s), 30 topic file(s) validated successfully
```

#### Error output examples

```
ERROR: papers/057.md - YAML parse failure: expected <block end>, but found '<scalar>'
ERROR: papers/044.md - prediction status 'structural' not in VALID_PREDICTION_STATUS
ERROR: topics/<unknown>/0sm.md - topic file references nonexistent directory
ERROR: topics/gauge-theory/0sm.md - applies_to includes nonexistent paper #99
```

### 6.3 `validate_conceptual_moves.py` 詳細

#### Checks performed

1. `context/derived/conceptual-moves.md` を read
2. 各 Move entry の **paper references** を extract
3. References が curated set (`context/papers/`) 内 に存在するか check
4. Forward-dangling references なし

#### Expected output (all-clear)

```
Existing papers in context/papers/: 60

✓ All paper references resolve to existing curated papers.
```

#### Error output example

```
ERROR: Move 5 references paper #99 but #99 is not in curated set
ERROR: Move 8 candidate references paper #61 but #61 is not in curated set
```

### 6.4 Build scripts 詳細

#### `build_index.py`

- Input: `context/papers/*.md`
- Output: `context/derived/index.md`
- Format: markdown table (number | date | title | type | DOI link)

#### `build_aggregate.py`

- Input: `context/papers/*.md`, `--field <field-name>`, `--output <path>`, `--title "<title>"`
- Output: 指定 path に時系列 aggregate
- Supports: `analogies_first`, `equations_first`, `first_occurrences` (= `concepts_first`), `predictions`, `corrections_made`

#### `build_open_questions.py`

- Input: `context/papers/*.md`
- Output: `context/derived/open-questions.md`
- Format: opens_tasks 集約 + closes_tasks cross-reference

## 7. `HANDOFF.md` (Master state document)

### 7.1 Structure

```markdown
# 0-Sphere Skill Curation — 引き継ぎプロンプト v(N)

**作成日**: <date>
**前回版**: HANDOFF v(N-1) <description>, v(N-2) <description>, ...

**v(N-1) → v(N) 差分**: <substantive paragraph describing transition>

**v(N) で articulate された <X> NEW curatorial pattern**: <numbered list>

**v(N) で実施されなかった items (modest articulation 維持)**: <list>

**User curatorial guidance verbatim record**: <quote blocks>

**Curatorial framing (v(N) articulation)**: <synthesis paragraph>

**Final v(N) baseline state**:
```
papers/    : NN files
topics/    : MM directories, KK layer files
queries/   : QQ entries
conceptual-moves: 8 Move entries + candidates
derived/   : 8 auto-regenerated files
scripts/   : 6 validators + builders
Validator state: 0 errors maintained 第 II instance
Modest articulation candidates: 累積 LL
```

---

## 旧 v(N-1) transition narrative (historical record, preserved)

(previous transition's full narrative)

---

## 旧 v(N-2) transition narrative
...
```

### 7.2 HANDOFF maintenance discipline

#### Rule H1: 各 transition で full narrative section 追加

新 v(N) section を file 先頭に追加、旧 v(N-1) を「historical record, preserved」 section へ移動。

#### Rule H2: Historical narratives は preserve

過去 transitions の narratives は decision precedents の record として維持 (HANDOFF v7.14 'welding-hub' 取下げ precedent 等の歴史 reference)。

#### Rule H3: Final baseline state は code block で明示

各 transition の final state を `Final v(N) baseline state` code block で標準 format で記録。

### 7.3 HANDOFF reading workflow (Skill A invocation)

新 invocation 時:

1. `head HANDOFF.md` で latest version 確認
2. v(N) → v(N-1) 差分 paragraph + NEW curatorial pattern section + Final baseline state を read
3. 必要に応じて旧 transitions narrative を read (historical context)

## 8. Output packaging

各 transition 完了時に baseline tarball を package:

```bash
tar czf /mnt/user-data/outputs/0sm-skills-v(N)-baseline.tar.gz HANDOFF.md context/ scripts/
```

Includes:
- `HANDOFF.md` (latest)
- `context/` 全 (papers/, topics/, queries/, derived/)
- `scripts/` 全

`README.md` (workspace top-level、任意) は include しても skip しても可。

## 9. Skill A workflow + workspace operations cross-reference

`SKILL.md` Section 3 の new paper curate workflow Steps 1-14 と本 architecture との correspondence:

| Step | Workspace operation | Files involved |
|---|---|---|
| 1. Read inputs | (no workspace edit) | (uploaded files) |
| 2. Read HANDOFF state | Read `HANDOFF.md` | `HANDOFF.md` |
| 3. Map relations | Read existing `papers/0XX.md` (if any) | `context/papers/` |
| 4. Extract initial contributions | Read PDF | (uploaded PDF) |
| 5. Determine threads + topics_invoked | Read `references/threads-and-topics.md` | (本 skill 内 reference) |
| 6. Type + subtype | Refer `references/frontmatter-schema.md` | (本 skill 内 reference) |
| 7. AI-collaboration lineage | Refer `references/curatorial-disciplines.md` Section 6 | (本 skill 内 reference) |
| 8. NEW pattern candidates | Refer modest articulation pool (this file Section 1.3) | (本 skill 内 reference) |
| 9. Create paper file | `create_file` | `context/papers/0XX.md` |
| 10. Update topics applies_to | `str_replace` | `context/topics/<topic>/[0sm or textbook].md` |
| 11. Run validators | `bash_tool` execute | `scripts/validate_*.py` |
| 12. Regenerate derived | `bash_tool` execute | `scripts/build_*.py` → `context/derived/` |
| 13. Update HANDOFF | `str_replace` | `HANDOFF.md` |
| 14. Package baseline | `bash_tool` execute | `/mnt/user-data/outputs/` |

## 10. References

- `references/frontmatter-schema.md`: papers/0XX.md frontmatter detailed schema
- `references/conceptual-moves-taxonomy.md`: Move taxonomy maintenance + Move 9 candidates
- `references/threads-and-topics.md`: thread enumeration + topic 19 directory listing
- `references/queries-layer.md`: queries layer architecture
- `references/curatorial-disciplines.md`: modest articulation + validator + multi-relation disciplines
