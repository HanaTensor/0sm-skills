---
name: 0sm-corpus-curate
description: 0-Sphere Model paper corpus (Hanamura Satoshi, 60+ papers) の curate skill。新規 paper PDF + zenodo_relations.txt の curate 依頼、特定 paper #XX の relations / threads / topics 質問、HANDOFF state 確認時に invoke。
---

# 0-Sphere Model Corpus Curate

Author Satoshi Hanamura の 0-Sphere Model 60+ paper corpus の workspace state を維持する skill。

## Full context (frontmatter description 短縮版の補足)

本 skill は以下の 5 use case で invoke する:

- (a) 0-Sphere Model paper の PDF + zenodo_relations.txt + readme.txt がアップロードされ curate を依頼された
- (b) 既 curated paper の relations refinement (preliminary → formal sync) が必要
- (c) 特定 paper #XX について relations / threads / topics / Move 関連の質問
- (d) HANDOFF.md state や validator state 確認
- (e) workspace 内 derived files の regenerate 要求

Workspace 構成: 60 papers (#1-#15 + #17-#45 + #46-#61, #16 permanent gap) + 19 topics + 4 queries + 8 conceptual moves。Author 個人の research assistant role が前提、外部 readers 向け教育 content や第三者 handoff は対象外。

Zenodo upload 準備が必要な場合は別 skill `0sm-zenodo-upload` を invoke する。

## 1. Trigger conditions

以下の状況で本 skill を invoke する:

### 1.1 New paper curate (most common)

User が新規 paper の以下 file set をアップロードした場合:
- 論文 PDF (例: `zenodo_NNNNNNNN.pdf`)
- `zenodo_relations.txt` (relations 全体 + reverse relations + multi-relation assignments)
- `readme.txt` (paper metadata + abstract + technical notes)
- 場合により `main.tex` (LaTeX source)

### 1.2 Relations refinement (WIP-curated paper の formal data sync)

既 WIP-curated paper について、後から formal `zenodo_relations.txt` が提供されて relations block を update する case (HANDOFF v7.26 #57 precedent)。

### 1.3 Cross-reference query

User が特定 paper / topic / thread / query / Move について情報を求めた場合:
- 「#34 はどの papers を supplement?」
- 「C-29 thread の active papers は?」
- 「Move 7 の carrier paper は?」
- 「q-002 sources.papers は?」

### 1.4 State management

- 「validator 通る?」
- 「derived files を regenerate して」
- 「HANDOFF v(N) → v(N+1) update」

### 1.5 Modest articulation candidate review

累積 modest articulation candidates (HANDOFF v7.26 baseline で 60 candidates) の review / promotion 判断。

## 2. Workspace structure (操作対象)

```
context/
├── papers/             # 60 frontmatter files (#XX.md, NNN.md format)
├── topics/             # 19 topics × 1-2 layer files
│   └── [topic-name]/
│       ├── 0sm.md          (0-Sphere Model perspective)
│       └── textbook.md     (textbook / classical perspective, 任意)
├── queries/            # forward research direction registrations
│   ├── README.md
│   └── q-XXX-*.md          (現 4 entries: q-001 〜 q-004)
└── derived/            # auto-generated (manual edit 禁止)
    ├── conceptual-moves.md  # 8 active Move entries + Move 9 candidates
    ├── index.md             # 全 papers index
    ├── analogies.md         # analogies_first 集約
    ├── equations.md         # equations_first 集約
    ├── first-occurrences.md # concepts_first 集約
    ├── predictions.md       # predictions 集約
    ├── corrections.md       # corrections_made 集約
    └── open-questions.md    # opens_tasks / closes_tasks 集約

scripts/
├── validate_frontmatter.py       # 必須 (curate 後)
├── validate_conceptual_moves.py  # 必須 (Move references resolve 確認)
├── build_index.py
├── build_aggregate.py
└── build_open_questions.py

HANDOFF.md   # Master state document - 必ず最初に確認
```

詳細は `references/workspace-architecture.md` 参照。

## 3. Curate workflow (新規 paper case)

### Step 1: Read inputs

User がアップロードした file 全部を読む:
- PDF: paper content (abstract, sections, equations, references, acknowledgments)
- zenodo_relations.txt: relations 全 6 categories ([1] Cites / [2] Is supplement to / [3] Continues / [4] References / [5] Requires / [6] Is part of) + reverse relations recommendations + multi-relation assignments
- readme.txt: title, date, DOI, abstract, document structure, acknowledgments (paper-internal vs readme.txt の比較が curatorial signal — mixed-form coexistence pattern HANDOFF v7.19 / v7.24 / v7.25 precedent 参照)

### Step 2: Read HANDOFF.md current state

最新 version (v7.X) の transition narrative を確認:
- Current paper count
- Validator state
- Active threads / topics / queries
- Modest articulation candidates 累積数
- Recent NEW patterns articulated

### Step 3: Map zenodo_relations.txt → workspace frontmatter

| zenodo_relations.txt | papers/0XX.md frontmatter |
|---|---|
| [2] Is supplement to | `relation.supplements: [...]` |
| [3] Continues | `relation.continues: [...]` |
| [5] Requires | `relation.requires: [...]` |
| [4] References (thematic) + [1] Cites - (上 3 categories) | `relation.references: [...]` |
| [6] Is part of | (workspace schema gap, v7.26 NEW pattern (d)、continues / requires で indirect capture) |

References field rule: bibitem cite Hanamura papers のうち supplements/continues/requires に**含まれない** paper を載せる。

### Step 4: Extract initial contributions from PDF

PDF の Sections 全体から initial articulations を抽出:
- `analogies_first`: 新規類比 (e.g., 「bicycle wheel circumference deficit」 #43)
- `equations_first`: 新規方程式または formal articulation (e.g., supp(E) ⊂ D #44 Eq. 1)
- `concepts_first`: 新規概念 articulation
- `opens_tasks`: 明示的な future direction
- `closes_tasks`: previous papers の opens_tasks を closure する場合
- `corrections_made`: 訂正 (rare、HANDOFF v7.21 precedent)
- `predictions`: 実験予測 (status: open / unmeasured / partial / confirmed / refuted / technically-difficult)

### Step 5: Determine threads + topics_invoked

- threads: paper が central / substantive / peripheral に invoke する thread (C-XX) を enumerate (`references/threads-and-topics.md`)
- topics_invoked: paper が central / substantive / peripheral に invoke する topic を enumerate (`references/threads-and-topics.md` + 既存 `context/topics/` directory listing)

### Step 6: Articulate type + subtype + is_foundational

- type: research / supplement / clarification / correction
- subtype: null / conceptual / structural / conceptual-and-mathematical / etc.
- is_foundational: true (foundational set 入り) / false (most papers)

判断 criteria は `references/frontmatter-schema.md` 参照。

### Step 7: AI-collaboration acknowledgment lineage tracking

paper Acknowledgments の AI-collaboration phrasing を lineage 内に position:
- どの phrasing variant か (#36 family / #39 family / compact 2-item / "interactive conversational tool" #45 / etc.)
- readme.txt vs paper-internal mixed-form coexistence pattern check (v7.19 / v7.24 / v7.25 precedent)

詳細 lineage は `references/curatorial-disciplines.md` 参照。

### Step 8: NEW v(N+1) pattern candidates articulation (modest)

curate 中に observed される pattern を modest articulation 候補として frontmatter `series_role` に record。

**重要 discipline**: HANDOFF v7.14 'welding-hub sub-type' 取下げ precedent — formal taxonomy promotion は User explicit articulation gate 通過後 triggered。premature commitment は workspace 質を degrade。

### Step 9: Create papers/0XX.md

Step 3-8 の internalize 結果を frontmatter として encoding。詳細 schema は `references/frontmatter-schema.md`。

### Step 10: Update topics/ applies_to

`topics_invoked` で declare した各 topic について、`context/topics/[topic]/0sm.md` (場合により `textbook.md`) の `applies_to:` field に paper number を numerical order で挿入。

### Step 11: Run validators (必須)

```bash
python3 scripts/validate_frontmatter.py
python3 scripts/validate_conceptual_moves.py
```

両 validator が **0-error 出力** することを確認。`OK: NN paper(s), MM topic file(s) validated successfully` + `✓ All paper references resolve to existing curated papers` 表示が ideal state。

エラー発生時の典型的原因:
- YAML quote balance (long quoted strings 内 closing `"` 欠落) — HANDOFF v7.26 precedent
- `predictions[].status` 不正値 (VALID_PREDICTION_STATUS = {unmeasured, partial, confirmed, refuted, open, technically-difficult})
- 未 curated paper への reference (forward references で発生 — papers/0XX.md が存在することを確認)

### Step 12: Regenerate derived/ files

```bash
python3 scripts/build_index.py
python3 scripts/build_aggregate.py --input context/papers --field analogies_first --output context/derived/analogies.md --title "アナロジー初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field equations_first --output context/derived/equations.md --title "方程式初出索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field first_occurrences --output context/derived/first-occurrences.md --title "シリーズ初出 articulations 索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field predictions --output context/derived/predictions.md --title "実験予測索引（時系列）"
python3 scripts/build_aggregate.py --input context/papers --field corrections_made --output context/derived/corrections.md --title "訂正履歴索引（時系列）"
python3 scripts/build_open_questions.py
```

### Step 13: Update HANDOFF.md (v(N) → v(N+1) transition narrative)

Comprehensive transition narrative を HANDOFF.md 先頭に追加:
- Date / version transition / 前回版継承
- 実施内容 (numbered list)
- NEW v(N+1) patterns articulated (modest articulation status)
- 実施されなかった items (modest 維持理由)
- User curatorial guidance verbatim record
- Curatorial framing
- Final v(N+1) baseline state

旧 v(N) transition narrative は historical record として preserve。

### Step 14: Package baseline tarball

```bash
tar czf /mnt/user-data/outputs/0sm-skills-v(N+1)-baseline.tar.gz HANDOFF.md context/ scripts/
```

User へ present:
- baseline tarball
- updated paper file (e.g., `0XX.md`)
- updated HANDOFF.md

## 4. Curate workflow (relations refinement case, HANDOFF v7.26 #57 precedent)

新規 paper ではなく既 WIP-curated paper の formal relations sync の場合:

### Step R1: Load existing papers/0XX.md

WIP-curated frontmatter を確認。

### Step R2: Compare with formal zenodo_relations.txt

discrepancy 識別:
- supplements / continues / requires / references の差分
- 旧 references で実際 bibitem cite されていないものの削除
- forward references の identification (#57 で #58/#59/#60 を bibitem cite するが conceptually #57 が predecessor の case)

### Step R3: Update relations block

`str_replace` で relations block のみを update。他 fields (analogies_first / equations_first / etc.) は preserve (User が preliminary curate で establish した分析 content)。

### Step R4: Add v(N+1) update_history entry

provenance.update_history に新 version entry 追加 (preliminary → formal の 2-stage history)。

### Step R5-R7: Validators / derived regenerate / HANDOFF update

新規 paper case の Step 11-13 と同じ。

## 5. Cross-reference query handling

User が特定 paper / topic / thread / query / Move について質問した場合の handling:

### 5.1 Paper query

```
User: "#34 が supplement するのは?"
→ context/papers/034.md の relation.supplements を参照
→ 答え: [supplement targets] + rationale (frontmatter コメントから)
```

### 5.2 Topic query

```
User: "gauge-theory topic に central で invoke する papers は?"
→ context/topics/gauge-theory/0sm.md の applies_to を参照
→ 各 paper の context/papers/0XX.md で gauge-theory が central か substantive か peripheral か確認
→ 答え: central の papers list
```

### 5.3 Thread query / Move query / Query layer query

`references/threads-and-topics.md` / `references/conceptual-moves-taxonomy.md` / `references/queries-layer.md` 各々を参照。

## 6. Curatorial disciplines (critical, must preserve)

詳細は `references/curatorial-disciplines.md` 参照。要点:

### 6.1 Modest articulation discipline

HANDOFF v7.14 'welding-hub sub-type' 取下げ precedent — observed patterns は modest 段階維持、formal commit は User explicit articulation gate 通過後。

### 6.2 Validator state all-clear preservation

すべての curate / refinement で validator 0-error を maintain。HANDOFF v7.26 で 11 instance maintained。

### 6.3 Number-based references (single source of truth)

DOI v1/v2 revision (例: #30 v1 18135855 → v2 18819682) があった場合、workspace は paper number で参照。bibitem の historical DOI cite は body text で document、workspace canonical DOI は v2。

### 6.4 Multi-relation declarations (HANDOFF v7.25 / v7.26 patterns)

Same target paper への multiple relation types declaration を支持:
- v7.25 dual-relation: #40 in #45 supplements + continues
- v7.26 quadruple-relation: #56 in #57 Cites + Continues + Is part of + Requires (Zenodo metadata level、workspace 内では continues + requires で capture)

## 7. NEW pattern articulation discipline

curate 中に observed される pattern 候補:

### 7.1 modest articulation 段階で record する pattern

- subtitle pattern variants (HANDOFF v7.10-v7.25 enumeration)
- AI-collaboration phrasing variants (lineage)
- methodological-honesty sub-types (現 7 candidates)
- companion / sister-paper articulations
- multi-relation declarations
- forward-reference patterns
- pedagogical-appendices-systematic-deployment

### 7.2 formal commit する pattern (User explicit gate 通過後)

- Move taxonomy formal additions (Move 7 v7.13 / Move 8 v7.22 precedent)
- Topic 新設 (HANDOFF v7.17 derivative-order-mismatch / v7.18 monopole precedent)
- Query layer 新設 (q-001 〜 q-004 precedent)

## 8. Cross-reference to Skill B (`0sm-zenodo-upload`)

curate 完了後、User が Zenodo upload 準備に進む場合は別 skill **`0sm-zenodo-upload`** を invoke する。本 skill (curate) で establish された frontmatter relations から zenodo_relations.txt content が auto-generation 可能 — 本 skill の output は Skill B の primary input。

Skill B prerequisite: `papers/0XX.md` が curate 済みで relations field (supplements / continues / requires / references) が populate されていること。

逆方向 redirect: Skill B が invoke されたが paper が未 curate の場合、User へ「先に `0sm-corpus-curate` skill で curate してください」 と redirect。

## 9. References (本 skill 配下)

詳細 reference material は本 skill の `references/` フォルダに分離:

| File | Content |
|---|---|
| `references/frontmatter-schema.md` | papers/0XX.md frontmatter YAML schema 完全仕様 |
| `references/conceptual-moves-taxonomy.md` | Move 1-8 active + Move 9 candidates + modest articulation 規律 |
| `references/threads-and-topics.md` | active threads (C-X) enumeration + 19 topics layer files |
| `references/queries-layer.md` | queries layer architecture + q-001 〜 q-004 entries |
| `references/curatorial-disciplines.md` | modest articulation / validator state / number-based / multi-relation 規律 |
| `references/workspace-architecture.md` | papers/topics/queries/derived/scripts file system layout 詳細 |

## 10. Worked example: new paper curate

(本 skill の典型的 invocation flow を 1 paper で例示)

**Input**: User uploads:
- `zenodo_18950974.pdf` (Paper #45 Open-Path Spinorial Transport...)
- `zenodo_relations.txt` (formal relations data)
- `readme.txt` (paper metadata)

**Skill A invocation**:

1. Read all 3 inputs + HANDOFF.md (current v7.24 baseline state)
2. Map zenodo_relations.txt → frontmatter:
   - supplements: [33, 35, 38, 40] from [2]
   - continues: [29, 31, 40] from [3]
   - requires: [29, 31, 33, 35, 38, 40] from [5]
   - references: [10, 13, 17, 22, 23, 26, 30, 32, 34, 36, 37, 41] from [4] + bibitem
3. Extract from PDF:
   - 9 concepts_first (three-mechanisms / spacetime-vs-internal-gauge dichotomy / etc.)
   - 2 equations_first (Eq. II.2-II.3 two-layer kernel)
   - 3 analogies_first (phase-matching reinterpretation / Wilson-vs-open-path / two-layer kernel)
   - 4 opens_tasks (directed-arc-length / dichotomy-resolution / Cartan cancellation / distinguishing observable)
4. Threads: C-29 (central) + C-3 + C-1 + C-22 (substantive)
5. Topics_invoked: gauge-theory + topology + spin (central) + 6 substantive + compton-scale-geometry (peripheral) = 10 topics
6. type: clarification (subtitle "(Structural Clarification Note)") + subtype: conceptual + is_foundational: false
7. AI-collaboration: NEW "interactive conversational tool" variant (lineage 第 12 instance candidate)
8. NEW patterns: subtitle parenthetical-suffix / triple-continuation / dual-relation-single-target / pedagogical-appendices-systematic-deployment / Methodological-honesty 7th sub-type / Move 9 'reframe' candidate / q-004 第 2 paper-level execution / readme-vs-paper-internal mixed-form 第 2 instance — total 8 NEW patterns
9. Create `context/papers/045.md` with comprehensive frontmatter
10. Update 10 topics applies_to (15 layer files)
11. Validators all-clear
12. Derived/ regenerate
13. HANDOFF v7.24 → v7.25 update
14. Package `0sm-skills-v7.25-baseline.tar.gz`

**Output**: 60-paper baseline maintained, 10 NEW v7.25 patterns articulated as modest, validator 第 10 instance all-clear.
